// firebase.js
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAMvhGXyGtcv5u0dk66vUuflN33PDl_-Es",
  authDomain: "restaurante-app-4b47b.firebaseapp.com",
  projectId: "restaurante-app-4b47b",
  storageBucket: "restaurante-app-4b47b.appspot.com",
  messagingSenderId: "219704872015",
  appId: "1:219704872015:web:aad6bafe8fbb752470ee3a",
  measurementId: "G-J8YSXD9RSW"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
