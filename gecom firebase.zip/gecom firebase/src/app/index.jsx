import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Image,
  StyleSheet,
  SafeAreaView,
  Alert,
  StatusBar,
  Modal,
} from 'react-native';
import { db } from './firebase';
import { collection, addDoc, Timestamp } from 'firebase/firestore';

const menuItems = [
  {
    id: '1',
    name: 'Classic Burger',
    description: 'Beef, lettuce, tomato, cheese',
    price: 22.5,
    image: 'https://i.imgur.com/5Aqgz7o.png',
    hasExtras: true,
    extras: ['Extra cheese', 'Bacon', 'Onion rings'],
  },
  {
    id: '2',
    name: 'Fries',
    description: 'Crispy golden fries',
    price: 9.5,
    image: 'https://i.imgur.com/N5uCbDu.png',
    hasExtras: false,
  },
];

const tables = ['Mesa 1', 'Mesa 2', 'Mesa 3'];

export default function App() {
  const [selectedTable, setSelectedTable] = useState(null);
  const [currentOrder, setCurrentOrder] = useState([]);
  const [activeTab, setActiveTab] = useState('Mesas');
  const [orderModalVisible, setOrderModalVisible] = useState(false);

  const handleAddToOrder = (item) => {
    const newItem = { ...item, id: Date.now().toString() };
    setCurrentOrder([...currentOrder, newItem]);
    Alert.alert('Adicionado', `${item.name} adicionado à comanda!`);
  };

  const sendOrder = async () => {
  try {
    await addDoc(collection(db, 'pedidos'), {
      mesa: selectedTable,
      itens: currentOrder,
      status: 'pendente',
      dataHora: Timestamp.now()
    });
    Alert.alert('Sucesso', 'Pedido enviado!');
    setCurrentOrder([]);
    setSelectedTable(null);
    setOrderModalVisible(false);
  } catch (error) {
    console.error(error);
    Alert.alert('Erro', 'Erro ao enviar pedido');
  }
};

  return (
    <SafeAreaView style={{ flex: 1, marginTop: StatusBar.currentHeight || 0 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
        <TouchableOpacity onPress={() => setActiveTab('Mesas')}>
          <Text style={{ fontSize: 20 }}>Mesas</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('Menu')}>
          <Text style={{ fontSize: 20 }}>Menu</Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'Mesas' ? (
        <ScrollView>
          {tables.map((table) => (
            <TouchableOpacity key={table} onPress={() => setSelectedTable(table)}>
              <Text style={{ fontSize: 18, padding: 10 }}>{table}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      ) : (
        <ScrollView>
          {menuItems.map((item) => (
            <TouchableOpacity key={item.id} onPress={() => handleAddToOrder(item)}>
              <View style={{ padding: 10, borderBottomWidth: 1, flexDirection: 'row' }}>
                <Image source={{ uri: item.image }} style={{ width: 60, height: 60 }} />
                <View style={{ marginLeft: 10 }}>
                  <Text style={{ fontSize: 18 }}>{item.name}</Text>
                  <Text>{item.description}</Text>
                  <Text>R$ {item.price.toFixed(2)}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {currentOrder.length > 0 && (
        <TouchableOpacity
          style={{ backgroundColor: '#27ae60', padding: 15 }}
          onPress={() => setOrderModalVisible(true)}>
          <Text style={{ color: 'white', textAlign: 'center', fontSize: 18 }}>
            Ver Comanda ({currentOrder.length})
          </Text>
        </TouchableOpacity>
      )}

      <Modal visible={orderModalVisible} animationType="slide">
        <View style={{ flex: 1, padding: 20 }}>
          <Text style={{ fontSize: 22 }}>Comanda - {selectedTable}</Text>
          <ScrollView>
            {currentOrder.map((item, index) => (
              <View key={index} style={{ padding: 10, borderBottomWidth: 1 }}>
                <Text>{item.name}</Text>
              </View>
            ))}
          </ScrollView>
          <TouchableOpacity style={{ backgroundColor: '#2980b9', padding: 15, marginTop: 20 }} onPress={sendOrder}>
            <Text style={{ color: 'white', textAlign: 'center', fontSize: 18 }}>Enviar Pedido</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ marginTop: 10 }} onPress={() => setOrderModalVisible(false)}>
            <Text style={{ textAlign: 'center', fontSize: 16 }}>Cancelar</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
