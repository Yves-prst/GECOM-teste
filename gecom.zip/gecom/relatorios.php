<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

// Dados da semana
$startOfWeek = date('Y-m-d', strtotime('monday this week'));
$endOfWeek = date('Y-m-d', strtotime('sunday this week'));

// Top 5 produtos da semana
$stmt = $pdo->prepare("
    SELECT 
        p.nome AS produto,
        SUM(v.quantidade) AS quantidade,
        SUM(v.quantidade * v.valor_unitario) AS total
    FROM vendas v
    LEFT JOIN produtos p ON v.produto_id = p.id
    WHERE DATE(v.criado_em) BETWEEN ? AND ?
    GROUP BY v.produto_id
    ORDER BY total DESC
    LIMIT 5
");
$stmt->execute([$startOfWeek, $endOfWeek]);
$weekData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Dados do mês
$startOfMonth = date('Y-m-01');
$endOfMonth = date('Y-m-t');

$stmt->execute([$startOfMonth, $endOfMonth]);
$monthData = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Relatórios - Sistema Administrativo</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div class="main-content">
    <div class="header">
        <h1><i class="fas fa-chart-bar"></i> Relatórios de Vendas</h1>
        <div class="header-actions">
            <select id="periodSelect" class="form-select">
                <option value="week">Esta Semana</option>
                <option value="month">Este Mês</option>
            </select>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-shopping-cart" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Total de Itens</h3>
                <div class="stat-value" id="totalItems"><?php echo array_sum(array_column($weekData, 'quantidade')); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-dollar-sign" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Receita Total</h3>
                <div class="stat-value" id="totalRevenue">
                    R$ <?php echo number_format(array_sum(array_column($weekData, 'total')), 2, ',', '.'); ?>
                </div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-box" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Produtos Diferentes</h3>
                <div class="stat-value" id="totalProducts"><?php echo count($weekData); ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-trophy" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Mais Vendido</h3>
                <div class="stat-value" id="topProduct"><?php echo $weekData[0]['produto'] ?? 'N/A'; ?></div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h3><i class="fas fa-bar-chart"></i> Top 5 Produtos - <span id="chartPeriod">Semana</span></h3></div>
        <div class="card-content"><canvas id="barChart"></canvas></div>
    </div>

    <div class="card">
        <div class="card-header"><h3><i class="fas fa-table"></i> Detalhamento de Vendas</h3></div>
        <div class="card-content">
            <div class="table-responsive">
                <table class="table" id="salesTable">
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Total (R$)</th>
                            <th>Participação</th>
                        </tr>
                    </thead>
                    <tbody id="salesTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
const weekData = <?php echo json_encode($weekData); ?>;
const monthData = <?php echo json_encode($monthData); ?>;
let currentPeriod = 'week';
let barChart;

document.addEventListener('DOMContentLoaded', function() {
    initChart();
    updateTable();
    document.getElementById('periodSelect').addEventListener('change', function() {
        currentPeriod = this.value;
        updateChart();
        updateTable();
        updateStats();
    });
});

function initChart() {
    const ctx = document.getElementById('barChart').getContext('2d');
    barChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: weekData.map(item => item.produto),
            datasets: [{
                label: 'Quantidade Vendida',
                data: weekData.map(item => item.quantidade),
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
}

function updateChart() {
    const data = currentPeriod === 'week' ? weekData : monthData;
    barChart.data.labels = data.map(item => item.produto);
    barChart.data.datasets[0].data = data.map(item => item.quantidade);
    barChart.update();
    document.getElementById('chartPeriod').textContent = currentPeriod === 'week' ? 'Semana' : 'Mês';
}

function updateTable() {
    const data = currentPeriod === 'week' ? weekData : monthData;
    const totalRevenue = data.reduce((sum, item) => sum + parseFloat(item.total), 0);
    const tbody = document.getElementById('salesTableBody');
    tbody.innerHTML = '';
    data.forEach(item => {
        const percentage = ((parseFloat(item.total) / totalRevenue) * 100).toFixed(1);
        tbody.innerHTML += `<tr>
            <td>${item.produto}</td>
            <td>${item.quantidade}</td>
            <td>R$ ${parseFloat(item.total).toFixed(2).replace('.', ',')}</td>
            <td>${percentage}%</td>
        </tr>`;
    });
}

function updateStats() {
    const data = currentPeriod === 'week' ? weekData : monthData;
    const totalItems = data.reduce((sum, item) => sum + parseInt(item.quantidade), 0);
    const totalRevenue = data.reduce((sum, item) => sum + parseFloat(item.total), 0);
    document.getElementById('totalItems').textContent = totalItems;
    document.getElementById('totalRevenue').textContent = 'R$ ' + totalRevenue.toFixed(2).replace('.', ',');
    document.getElementById('totalProducts').textContent = data.length;
    document.getElementById('topProduct').textContent = data[0]?.produto || 'N/A';
}
</script>
</body>
</html>
