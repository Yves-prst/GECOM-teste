<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

// Buscar categorias para o select
$stmt = $pdo->query("SELECT * FROM categorias ORDER BY nome");
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar produtos
$stmt = $pdo->query("
    SELECT p.*, c.nome as categoria_nome
    FROM produtos p
    LEFT JOIN categorias c ON p.categoria_id = c.id
    ORDER BY p.criado_em DESC
");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Produtos - Sistema Administrativo</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
.modal {
    display:none;
    position:fixed;
    top:0; left:0;
    width:100%;
    height:100%;
    background:rgba(0,0,0,0.5);
    justify-content:center;
    align-items:center;
    z-index:999;
}
.modal-content {
    background:#fff;
    width:90%;
    max-width:500px;
    border-radius:8px;
    overflow:hidden;
    display:flex;
    flex-direction:column;
}
.modal-header {
    padding:15px;
    background:#f5f5f5;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.modal-body {
    padding:20px;
}
.modal-close {
    background:none;
    border:none;
    font-size:20px;
    cursor:pointer;
}
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #28a745;
    color: white;
    padding: 10px 15px;
    border-radius: 5px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    opacity: 0;
    transition: all 0.3s;
    z-index: 1000;
}
.notification.show { opacity: 1; transform: translateY(0); }
.notification.error { background: #dc3545; }
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div class="main-content">
    <div class="header">
        <h1><i class="fas fa-box"></i> Gerenciar Produtos</h1>  
        <button class="btn btn-primary" onclick="openProductModal()">
            <i class="fas fa-plus"></i> Adicionar Produto
        </button>
    </div>

    <div class="card">
        <div class="card-content">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Preço</th>
                            <th>Status</th>
                            <th>Categoria</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="productList">
                        <?php foreach($products as $p): ?>
                        <tr>
                            <td><?=$p['id']?></td>
                            <td><?=htmlspecialchars($p['nome'])?></td>
                            <td>R$ <?=number_format($p['preco'],2,',','.')?></td>
                            <td><?=$p['status']?></td>
                            <td><?=$p['categoria_nome'] ?? 'Sem categoria'?></td>
                            <td>
                                <button class="btn-icon" onclick='editProduct(<?=json_encode($p)?>)'><i class="fas fa-edit"></i></button>
                                <button class="btn-icon btn-danger" onclick='deleteProduct(<?=$p['id']?>)'><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Produto -->
<div id="productModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Adicionar Produto</h3>
            <button class="modal-close" onclick="closeProductModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="productForm">
                <input type="hidden" id="productId">
                <div class="form-group">
                    <label>Nome</label>
                    <input type="text" id="productName" required>
                </div>
                <div class="form-group">
                    <label>Preço</label>
                    <input type="number" step="0.01" id="productPrice" required>
                </div>
                <div class="form-group">
                    <label>Categoria</label>
                    <select id="productCategory">
                        <option value="">Sem categoria</option>
                        <?php foreach($categories as $c): ?>
                        <option value="<?=$c['id']?>"><?=htmlspecialchars($c['nome'])?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select id="productStatus">
                        <option value="Ativo">Ativo</option>
                        <option value="Inativo">Inativo</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <button type="button" class="btn btn-secondary" onclick="closeProductModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Modal
function openProductModal(){ document.getElementById('productModal').style.display='flex'; }
function closeProductModal(){ document.getElementById('productModal').style.display='none'; document.getElementById('productForm').reset(); }

// Notificação
function showNotification(msg,type='success'){
    const n=document.createElement('div');
    n.className='notification'+(type==='error'?' error':'');
    n.textContent=msg;
    document.body.appendChild(n);
    setTimeout(()=>n.classList.add('show'),100);
    setTimeout(()=>{ n.classList.remove('show'); setTimeout(()=>n.remove(),300); },2500);
}

// CRUD
document.getElementById('productForm').addEventListener('submit',function(e){
    e.preventDefault();
    const data=new FormData();
    data.append('id',document.getElementById('productId').value);
    data.append('nome',document.getElementById('productName').value);
    data.append('preco',document.getElementById('productPrice').value);
    data.append('categoria_id',document.getElementById('productCategory').value);
    data.append('status',document.getElementById('productStatus').value);

    fetch('api/produtos.php',{method:'POST',body:data})
    .then(r=>r.json())
    .then(res=>{
        if(res.success){ showNotification(res.message); closeProductModal(); setTimeout(()=>location.reload(),300); }
        else showNotification(res.message,'error');
    })
    .catch(err=>showNotification('Erro de conexão','error'));
});

function editProduct(p){
    openProductModal();
    document.getElementById('modalTitle').textContent='Editar Produto';
    document.getElementById('productId').value=p.id;
    document.getElementById('productName').value=p.nome;
    document.getElementById('productPrice').value=p.preco;
    document.getElementById('productCategory').value=p.categoria_id ?? '';
    document.getElementById('productStatus').value=p.status;
}

function deleteProduct(id){
    if(confirm('Excluir este produto?')){
        const data=new FormData();
        data.append('delete_id',id);
        fetch('api/produtos.php',{method:'POST',body:data})
        .then(r=>r.json())
        .then(res=>{
            if(res.success){ showNotification(res.message); setTimeout(()=>location.reload(),300); }
            else showNotification(res.message,'error');
        });
    }
}

// Fechar modal clicando fora
window.addEventListener('click',e=>{
    if(e.target.id==='productModal') closeProductModal();
});
</script>
</body>
</html>
