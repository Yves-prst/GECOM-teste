"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, BarChart3, PieChart } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface SalesData {
  product: string
  quantity: number
  total: number
}

export function ReportsManager() {
  const [weekData, setWeekData] = useState<SalesData[]>([])
  const [monthData, setMonthData] = useState<SalesData[]>([])
  const [period, setPeriod] = useState<"week" | "month">("week")
  const { toast } = useToast()

  useEffect(() => {
    fetchReportsData()
  }, [])

  const fetchReportsData = async () => {
    try {
      const [weekResponse, monthResponse] = await Promise.all([fetch("/api/reports/week"), fetch("/api/reports/month")])

      const weekData = await weekResponse.json()
      const monthData = await monthResponse.json()

      setWeekData(weekData)
      setMonthData(monthData)
    } catch (error) {
      console.error("Erro ao buscar dados dos relatórios:", error)
    }
  }

  const generatePDF = async () => {
    try {
      const response = await fetch("/api/reports/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ period }),
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `relatorio-${period}-${new Date().toISOString().split("T")[0]}.pdf`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)

        toast({
          title: "PDF gerado!",
          description: "Relatório foi baixado com sucesso.",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao gerar PDF",
        variant: "destructive",
      })
    }
  }

  const currentData = period === "week" ? weekData : monthData

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Select value={period} onValueChange={(value: "week" | "month") => setPeriod(value)}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Esta Semana</SelectItem>
              <SelectItem value="month">Este Mês</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={generatePDF}>
          <Download className="h-4 w-4 mr-2" />
          Gerar PDF
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Top 5 Produtos - {period === "week" ? "Semana" : "Mês"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {currentData.slice(0, 5).map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">{item.product}</div>
                    <div className="text-sm text-muted-foreground">{item.quantity} unidades vendidas</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-600">R$ {item.total.toFixed(2)}</div>
                  </div>
                </div>
              ))}
              {currentData.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">Nenhum dado de vendas disponível</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Resumo de Vendas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {currentData.reduce((sum, item) => sum + item.quantity, 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">Total de Itens</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    R$ {currentData.reduce((sum, item) => sum + item.total, 0).toFixed(2)}
                  </div>
                  <div className="text-sm text-muted-foreground">Receita Total</div>
                </div>
              </div>

              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{currentData.length}</div>
                <div className="text-sm text-muted-foreground">Produtos Diferentes</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
