<?php
require_once '../config/database.php';
require_once '../config/auth.php';
requireLogin();
header('Content-Type: application/json');

try {
    if(isset($_POST['delete_id'])){
        $id = intval($_POST['delete_id']);
        $stmt = $pdo->prepare("DELETE FROM produtos WHERE id=?");
        $stmt->execute([$id]);
        echo json_encode(['success'=>true,'message'=>'Produto excluído com sucesso!']);
        exit;
    }

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $nome = trim($_POST['nome']);
    $preco = floatval($_POST['preco']);
    $status = $_POST['status'] ?? 'Ativo';
    $categoria_id = $_POST['categoria_id'] ?: null;

    if(empty($nome)) throw new Exception('Nome é obrigatório.');

    if($id>0){
        $stmt = $pdo->prepare("UPDATE produtos SET nome=?, preco=?, status=?, categoria_id=? WHERE id=?");
        $stmt->execute([$nome,$preco,$status,$categoria_id,$id]);
        echo json_encode(['success'=>true,'message'=>'Produto atualizado com sucesso!']);
    } else {
        $stmt = $pdo->prepare("INSERT INTO produtos (nome, preco, status, categoria_id, criado_em) VALUES (?,?,?,?,NOW())");
        $stmt->execute([$nome,$preco,$status,$categoria_id]);
        echo json_encode(['success'=>true,'message'=>'Produto criado com sucesso!']);
    }
} catch(Exception $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
