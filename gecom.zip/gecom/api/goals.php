<?php
require_once '../config/database.php';
require_once '../config/auth.php';
requireLogin();

// Recebe JSON
$data = json_decode(file_get_contents("php://input"), true);
if (!isset($data['target']) || !is_numeric($data['target'])) {
    echo json_encode(['success' => false, 'message' => 'Valor inválido']);
    exit;
}

$valor = floatval($data['target']);
$mes = date('n');
$ano = date('Y');

// Verifica se já existe meta para o mês
$stmt = $pdo->prepare("SELECT id FROM metas WHERE mes = ? AND ano = ?");
$stmt->execute([$mes, $ano]);
$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if($existing){
    $stmt = $pdo->prepare("UPDATE metas SET valor = ? WHERE id = ?");
    $stmt->execute([$valor, $existing['id']]);
    echo json_encode(['success' => true]);
} else {
    $stmt = $pdo->prepare("INSERT INTO metas (mes, ano, valor) VALUES (?, ?, ?)");
    $stmt->execute([$mes, $ano, $valor]);
    echo json_encode(['success' => true]);
}
