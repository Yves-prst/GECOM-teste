<?php
require_once '../config/database.php';
require_once '../config/auth.php';
requireLogin();
header('Content-Type: application/json');

try {
    if(isset($_POST['delete_id'])){
        $id=intval($_POST['delete_id']);
        $stmt=$pdo->prepare("DELETE FROM categorias WHERE id=?");
        $stmt->execute([$id]);
        echo json_encode(['success'=>true,'message'=>'Categoria excluída com sucesso!']);
        exit;
    }

    $id=isset($_POST['id'])?intval($_POST['id']):0;
    $nome=trim($_POST['nome']);
    if(empty($nome)) throw new Exception('Nome é obrigatório.');

    if($id>0){
        $stmt=$pdo->prepare("UPDATE categorias SET nome=? WHERE id=?");
        $stmt->execute([$nome,$id]);
        echo json_encode(['success'=>true,'message'=>'Categoria atualizada com sucesso!']);
    } else {
        $stmt=$pdo->prepare("INSERT INTO categorias (nome, criado_em) VALUES (?,NOW())");
        $stmt->execute([$nome]);
        echo json_encode(['success'=>true,'message'=>'Categoria criada com sucesso!']);
    }
} catch(Exception $e){
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
    