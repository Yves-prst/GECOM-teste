<?php
require_once 'config/database.php';

// Função para enviar resposta JSON
function enviarJson($dados)
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

$acao = $_REQUEST['acao'] ?? null;

// Criar mesa
if ($acao === 'criar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $capacidade = $_POST['capacidade'] ?? null;
    $status = $_POST['status'] ?? 'disponível';

    if (!$capacidade) {
        enviarJson(['erro' => 'Preencha a capacidade!']);
    }

    $stmt = $pdo->query("SELECT numero FROM mesas ORDER BY numero ASC");
    $numerosExistentes = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $novoNumero = 1;
    foreach ($numerosExistentes as $n) {
        if ((int)$n === $novoNumero) {
            $novoNumero++;
        } else {
            break;
        }
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO mesas (numero, capacidade, status) VALUES (:numero, :capacidade, :status)");
        $stmt->execute([
            ':numero' => $novoNumero,
            ':capacidade' => $capacidade,
            ':status' => $status
        ]);
        enviarJson(['sucesso' => 'Mesa criada com sucesso!']);
    } catch (PDOException $e) {
        enviarJson(['erro' => 'Erro ao criar mesa: ' . $e->getMessage()]);
    }
}

// Editar mesa
if ($acao === 'editar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $capacidade = $_POST['capacidade'] ?? null;
    $status = $_POST['status'] ?? null;

    if (!$id || !$capacidade || !$status) {
        enviarJson(['erro' => 'Preencha todos os campos!']);
    }

    try {
        $stmt = $pdo->prepare("UPDATE mesas SET capacidade = :capacidade, status = :status WHERE id = :id");
        $stmt->execute([
            ':id' => $id,
            ':capacidade' => $capacidade,
            ':status' => $status
        ]);
        enviarJson(['sucesso' => 'Mesa atualizada com sucesso!']);
    } catch (PDOException $e) {
        enviarJson(['erro' => 'Erro ao atualizar mesa: ' . $e->getMessage()]);
    }
}

// Excluir mesa
if ($acao === 'excluir' && isset($_GET['id'])) {
    $id = $_GET['id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM mesas WHERE id = ?");
        $stmt->execute([$id]);
        enviarJson(['sucesso' => 'Mesa excluída com sucesso!']);
    } catch (PDOException $e) {
        enviarJson(['erro' => 'Erro ao excluir mesa: ' . $e->getMessage()]);
    }
}

// Obter mesa específica
if ($acao === 'buscar' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM mesas WHERE id = ?");
    $stmt->execute([$id]);
    $mesa = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$mesa) {
        enviarJson(['erro' => 'Mesa não encontrada']);
    }
    enviarJson($mesa);
}

// Buscar todas as mesas
$stmt = $pdo->query("SELECT * FROM mesas ORDER BY numero ASC");
$mesas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<title>Gerenciar Mesas</title>
<link rel="stylesheet" href="assets/css/style.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
<style>
.stats-grid {
    display:flex;
    flex-wrap:wrap;
    gap:15px;
    margin-top:20px;
}

.tables-content {
    flex:1 1 220px; /* aumenta a largura mínima do card */
    background:#fdf2f2;
    padding:20px;
    border-radius:10px;
    min-width:200px;
    max-width:250px; /* largura maior que antes */
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.header-tables {
    display:flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom:10px;
}

.status-disponível,
.status-ocupada,
.status-reservada {
    display:flex;
    justify-content:center;
    align-items:center;
    padding:5px 12px;
    border-radius:5px;
    font-size:13px;
    font-weight:600;
    color:#fff;
    border:none;
    text-align:center; /* centraliza horizontalmente */
    min-width:80px; /* deixa botão mais largo */
}

.status-disponível { background:#6fcf97; }
.status-ocupada { background:#f28b82; }
.status-reservada { background:#fbbc04; }

.btn-icon { background:none; border:none; cursor:pointer; margin-right:5px; }
.icons-tables { margin-top:10px; }
</style>

</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div class="main-content">
    <div class="header">
        <h1><i class="fas fa-chair"></i> Gerenciar Mesas</h1>
        <button class="btn btn-primary" onclick="abrirModalMesa()"><i class="fas fa-plus"></i> Adicionar Mesa</button>
    </div>

    <div class="stats-grid">
        <?php foreach ($mesas as $mesa): ?>
        <div class="tables-content">
            <div class="header-tables">
                <h2>Mesa <?php echo htmlspecialchars($mesa['numero']); ?></h2>
                <button class="status-<?php echo htmlspecialchars($mesa['status']); ?>" disabled>
                    <?php echo ucfirst($mesa['status']); ?>
                </button>
            </div>
            <h3>Capacidade: <?php echo htmlspecialchars($mesa['capacidade']); ?> pessoa<?php echo $mesa['capacidade'] > 1 ? 's' : ''; ?></h3>
            <div class="icons-tables">
                <button class="btn-icon" title="Editar" onclick="editarMesa(<?php echo $mesa['id']; ?>)"><i class="fas fa-edit"></i></button>
                <button class="btn-icon btn-danger" title="Excluir" onclick="excluirMesa(<?php echo $mesa['id']; ?>)"><i class="fas fa-trash"></i></button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Modal -->
<div id="modalMesa" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="tituloModalMesa">Adicionar Mesa</h3>
            <button class="modal-close" onclick="fecharModalMesa()">&times;</button>
        </div>
        <form id="formMesa">
            <input type="hidden" id="mesaId" name="id" />
            <div class="form-group">
                <label for="mesaCapacidade">Capacidade (pessoas)</label>
                <input type="number" id="mesaCapacidade" name="capacidade" required min="1" step="1" />
            </div>
            <div class="form-group">
                <label for="mesaStatus">Status</label>
                <select id="mesaStatus" name="status" required>
                    <option value="disponível">Disponível</option>
                    <option value="ocupada">Ocupada</option>
                    <option value="reservada">Reservada</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Salvar</button>
                <button type="button" class="btn btn-secondary" onclick="fecharModalMesa()">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<script>
function abrirModalMesa() {
    document.getElementById('modalMesa').style.display = 'flex';
    document.getElementById('tituloModalMesa').textContent = 'Adicionar Mesa';
    document.getElementById('formMesa').reset();
    document.getElementById('mesaId').value = '';
}

function fecharModalMesa() {
    document.getElementById('modalMesa').style.display = 'none';
}

document.getElementById('formMesa').addEventListener('submit', function(e){
    e.preventDefault();
    const id = document.getElementById('mesaId').value;
    const capacidade = document.getElementById('mesaCapacidade').value;
    const status = document.getElementById('mesaStatus').value;

    const formData = new FormData();
    formData.append('capacidade', capacidade);
    formData.append('status', status);
    formData.append('acao', id ? 'editar' : 'criar');
    if(id) formData.append('id', id);

    fetch('mesas.php',{ method:'POST', body:formData })
    .then(res=>res.json())
    .then(data=>{
        if(data.sucesso){
            alert(data.sucesso);
            window.location.reload();
        }else{
            alert(data.erro || 'Erro desconhecido');
        }
    });
});

function editarMesa(id){
    fetch(`mesas.php?acao=buscar&id=${id}`)
    .then(res=>res.json())
    .then(mesa=>{
        if(mesa.erro){ alert(mesa.erro); return; }
        document.getElementById('mesaId').value = mesa.id;
        document.getElementById('mesaCapacidade').value = mesa.capacidade;
        document.getElementById('mesaStatus').value = mesa.status;
        document.getElementById('tituloModalMesa').textContent = 'Editar Mesa';
        abrirModalMesa();
    });
}

function excluirMesa(id){
    if(!confirm('Tem certeza que deseja excluir esta mesa?')) return;
    fetch(`mesas.php?acao=excluir&id=${id}`)
    .then(res=>res.json())
    .then(data=>{
        if(data.sucesso){ alert(data.sucesso); window.location.reload(); }
        else{ alert(data.erro || 'Erro desconhecido'); }
    });
}

window.onclick = function(event){
    const modal = document.getElementById('modalMesa');
    if(event.target == modal) fecharModalMesa();
}
</script>
</body>
</html>
