<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

// Buscar estatísticas
$today = date('Y-m-d');

// Total vendido hoje
$stmt = $pdo->prepare("SELECT COALESCE(SUM(total), 0) as total FROM pedidos WHERE DATE(criado_em) = ?");
$stmt->execute([$today]);
$totalToday = $stmt->fetchColumn();

// Comandas abertas
$stmt = $pdo->query("SELECT COUNT(*) FROM pedidos WHERE status = 'aberto'");
$openOrders = $stmt->fetchColumn();

// Comandas fechadas hoje
$stmt = $pdo->prepare("SELECT COUNT(*) FROM pedidos WHERE status = 'fechado' AND DATE(criado_em) = ?");
$stmt->execute([$today]);
$closedOrders = $stmt->fetchColumn();

// Funcionários em turno
$stmt = $pdo->query("
    SELECT f.nome, f.cargo 
    FROM turnos_funcionarios tf
    JOIN funcionarios f ON tf.funcionario_id = f.id
    WHERE tf.hora_saida IS NULL
");
$onShift = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Meta atual
$currentMonth = date('n');
$currentYear = date('Y');
$stmt = $pdo->prepare("SELECT * FROM metas WHERE mes = ? AND ano = ?");
$stmt->execute([$currentMonth, $currentYear]);
$goal = $stmt->fetch();

// Vendas do mês atual para a meta
$stmt = $pdo->prepare("SELECT COALESCE(SUM(total),0) as total FROM pedidos WHERE MONTH(criado_em) = ? AND YEAR(criado_em) = ?");
$stmt->execute([$currentMonth, $currentYear]);
$currentSales = $stmt->fetchColumn();

// Produtos recentes
$stmt = $pdo->query("
    SELECT p.*, c.nome as categoria_nome
    FROM produtos p
    LEFT JOIN categorias c ON p.categoria_id = c.id
    ORDER BY p.criado_em DESC
    LIMIT 5
");
$recentProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Destaques recentes
$stmt = $pdo->query("SELECT * FROM destaques ORDER BY data DESC LIMIT 5");
$highlights = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Sistema Administrativo</title>
<link rel="stylesheet" href="assets/css/style.css?v=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
/* Barra de progresso da meta */
.goal-card .progress-bar {
    width: 100%;
    background-color: #e0e0e0;
    border-radius: 20px;
    overflow: hidden;
    height: 20px;
    margin: 10px 0;
}

.goal-card .progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #4caf50, #81c784);
    width: 0;
    border-radius: 20px 0 0 20px;
    transition: width 1s ease-in-out;
}

/* Modal */
.modal {
    display: none;
    position: fixed;
    z-index: 999;
    left: 0; top: 0;
    width: 100%; height: 100%;
    background-color: rgba(0,0,0,0.6);
    justify-content: center;
    align-items: center;
}

.modal.active {
    display: flex;
}

.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    width: 300px;
    position: relative;
}

.modal-content .close {
    position: absolute;
    right: 10px; top: 10px;
    font-size: 20px;
    cursor: pointer;
}

.modal-content form input {
    width: 100%;
    padding: 8px;
    margin: 10px 0;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.modal-content form button {
    width: 100%;
}
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div class="main-content">
    <div class="header">
        <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
        <div class="user-info">Bem-vindo, <?=htmlspecialchars($_SESSION['username'])?></div>
    </div>

    <!-- Estatísticas -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-dollar-sign" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Total Vendido Hoje</h3>
                <div class="stat-value">
                    R$ <?=number_format($totalToday,2,',','.')?>
                </div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-clock" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Comandas Abertas</h3>
                <div class="stat-value"><?=$openOrders?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-check-circle" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Comandas Fechadas</h3>
                <div class="stat-value"><?=$closedOrders?></div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-user-clock" style="color:white;"></i></div>
            <div class="stat-content">
                <h3>Em Turno</h3>
                <div class="stat-value"><?=count($onShift)?></div>
                <div class="stat-details">
                    <?php if(!empty($onShift)): ?>
                        <?php foreach($onShift as $emp): ?>
                            <small><?=htmlspecialchars($emp['nome'])?> (<?=ucfirst($emp['cargo'])?>)</small>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <small>Nenhum funcionário em turno</small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Meta Mensal -->
    <div class="card goal-card">
        <div class="card-header">
            <h2><i class="fas fa-bullseye"></i> Meta Mensal</h2>
            <button class="btn btn-primary" onclick="openGoalModal()">
                <i class="fas fa-bullseye"></i> Definir Meta
            </button>
        </div>
        <div class="card-content">
            <?php if($goal): 
                $percent = $currentSales / $goal['valor'] * 100;
                if($percent > 100) $percent = 100;
            ?>
                <p>R$ <?=number_format($currentSales,2,',','.')?> / R$ <?=number_format($goal['valor'],2,',','.')?></p>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?=$percent?>%"></div>
                </div>
                <small><?=$percent?>% da meta atingida</small>
            <?php else: ?>
                <p>Nenhuma meta definida para este mês.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Destaques -->
    <div class="card">
        <div class="card-header"><h2><i class="fas fa-star"></i> Destaques Recentes</h2></div>
        <div class="card-content">
            <?php if(empty($highlights)): ?>
                <p>Nenhum destaque disponível.</p>
            <?php else: ?>
                <ul>
                    <?php foreach($highlights as $d): ?>
                        <li>
                            <strong><?=htmlspecialchars($d['titulo'])?></strong>
                            (<?=htmlspecialchars($d['tipo'])?>) - R$ <?=number_format($d['valor'],2,',','.')?>
                            <br><?=htmlspecialchars($d['descricao'])?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <!-- Produtos Recentes -->
    <div class="card">
        <div class="card-header">
            <h2>Produtos Recentes</h2>
            <a href="produtos.php" class="btn btn-secondary">Ver Todos</a>
        </div>
        <div class="card-content">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Preço</th>
                        <th>Status</th>
                        <th>Categoria</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($recentProducts as $p): ?>
                        <tr>
                            <td><?=$p['id']?></td>
                            <td><?=htmlspecialchars($p['nome'])?></td>
                            <td>R$ <?=number_format($p['preco'],2,',','.')?></td>
                            <td><?=$p['status']?></td>
                            <td><?=$p['categoria_nome'] ?? 'Sem categoria'?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Modal para definir meta -->
<div class="modal" id="goalModal">
    <div class="modal-content">
        <span class="close" onclick="closeGoalModal()">&times;</span>
        <h3>Definir Meta Mensal</h3>
        <form id="goalForm">
            <input type="number" id="goalTarget" placeholder="Valor da meta em R$" step="0.01" required>
            <button type="submit" class="btn btn-primary">Salvar Meta</button>
        </form>
    </div>
</div>

<script src="assets/js/dashboard.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const progressFill = document.querySelector(".progress-fill");
    if(progressFill) {
        const width = progressFill.style.width;
        progressFill.style.width = "0%";
        setTimeout(() => progressFill.style.width = width, 100);
    }
});
</script>
</body>
</html>
