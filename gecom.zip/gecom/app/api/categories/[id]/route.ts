import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    initializeDatabase()

    const { name, description } = await request.json()
    const id = Number.parseInt(params.id)

    db.prepare(`
      UPDATE categories 
      SET name = ?, description = ? 
      WHERE id = ?
    `).run(name, description || null, id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Categories PUT error:", error)
    return NextResponse.json({ error: "Erro ao atualizar categoria" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    initializeDatabase()

    const id = Number.parseInt(params.id)

    // Remove category reference from products
    db.prepare("UPDATE products SET category_id = NULL WHERE category_id = ?").run(id)

    // Delete category
    db.prepare("DELETE FROM categories WHERE id = ?").run(id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Categories DELETE error:", error)
    return NextResponse.json({ error: "Erro ao excluir categoria" }, { status: 500 })
  }
}
