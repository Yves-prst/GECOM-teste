import { NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function GET() {
  try {
    initializeDatabase()

    const today = new Date().toISOString().split("T")[0]

    // Total sales today
    const totalSalesToday = db
      .prepare(`
      SELECT COALESCE(SUM(total_price), 0) as total 
      FROM sales 
      WHERE DATE(sale_date) = ?
    `)
      .get(today) as { total: number }

    // Open orders
    const openOrders = db
      .prepare(`
      SELECT COUNT(*) as count 
      FROM orders 
      WHERE status = 'open'
    `)
      .get() as { count: number }

    // Closed orders today
    const closedOrders = db
      .prepare(`
      SELECT COUNT(*) as count 
      FROM orders 
      WHERE status = 'closed' AND DATE(closed_at) = ?
    `)
      .get(today) as { count: number }

    // Active employees (mock data for now)
    const activeEmployees = 10

    return NextResponse.json({
      totalSalesToday: totalSalesToday.total,
      openOrders: openOrders.count,
      closedOrders: closedOrders.count,
      activeEmployees,
    })
  } catch (error) {
    console.error("Stats error:", error)
    return NextResponse.json({ error: "Erro ao buscar estatísticas" }, { status: 500 })
  }
}
