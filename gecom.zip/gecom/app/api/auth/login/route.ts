import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"
import { createSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    initializeDatabase()

    const { username, password } = await request.json()

    // Check user credentials
    const user = db.prepare("SELECT * FROM users WHERE username = ? AND password = ?").get(username, password)

    if (!user) {
      return NextResponse.json({ error: "Credenciais inválidas" }, { status: 401 })
    }

    await createSession(username)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
