import { NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function GET() {
  try {
    initializeDatabase()

    // Get recent highlights
    const highlights = db
      .prepare(`
      SELECT * FROM highlights 
      ORDER BY date DESC 
      LIMIT 10
    `)
      .all()

    // If no highlights exist, create some sample ones
    if (highlights.length === 0) {
      const sampleHighlights = [
        {
          title: "Meta Mensal Atingida",
          description: "Parabéns! A meta de vendas deste mês foi atingida com sucesso.",
          value: 2500.0,
          type: "goal",
        },
        {
          title: "Produto Mais Vendido",
          description: 'O produto "Hambúrguer Especial" foi o mais vendido esta semana.',
          value: 450.0,
          type: "product",
        },
        {
          title: "Melhor Dia de Vendas",
          description: "Ontem foi registrado o melhor dia de vendas do mês.",
          value: 890.5,
          type: "sale",
        },
      ]

      for (const highlight of sampleHighlights) {
        db.prepare(`
          INSERT INTO highlights (title, description, value, type) 
          VALUES (?, ?, ?, ?)
        `).run(highlight.title, highlight.description, highlight.value, highlight.type)
      }

      // Fetch again after inserting samples
      return NextResponse.json(
        db
          .prepare(`
        SELECT * FROM highlights 
        ORDER BY date DESC 
        LIMIT 10
      `)
          .all(),
      )
    }

    return NextResponse.json(highlights)
  } catch (error) {
    console.error("Highlights error:", error)
    return NextResponse.json({ error: "Erro ao buscar destaques" }, { status: 500 })
  }
}
