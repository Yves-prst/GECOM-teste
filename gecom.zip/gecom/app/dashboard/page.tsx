import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { DashboardStats } from "@/components/dashboard-stats"
import { GoalsSection } from "@/components/goals-section"
import { ProductsPreview } from "@/components/products-preview"
import { HighlightsSection } from "@/components/highlights-section"

export default async function DashboardPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Bem-vindo, {session.username}</p>
      </div>

      <DashboardStats />
      <GoalsSection />
      <HighlightsSection />
      <ProductsPreview />
    </div>
  )
}
