<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

// Processar AJAX para salvar/excluir categoria e adicionais
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    try {
        // SALVAR/EDITAR CATEGORIA
        if (isset($_POST['action']) && $_POST['action'] === 'save_category') {
            $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
            $nome = trim($_POST['nome']);
            $descricao = trim($_POST['descricao']);

            if (empty($nome)) throw new Exception('O nome da categoria é obrigatório.');

            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE categorias SET nome=?, descricao=? WHERE id=?");
                $stmt->execute([$nome, $descricao, $id]);
                echo json_encode(['success'=>true,'message'=>'Categoria atualizada!']);
            } else {
                $stmt = $pdo->prepare("INSERT INTO categorias (nome, descricao) VALUES (?, ?)");
                $stmt->execute([$nome,$descricao]);
                echo json_encode(['success'=>true,'message'=>'Categoria criada!']);
            }
            exit;
        }

        // EXCLUIR CATEGORIA
        if (isset($_POST['delete_id'])) {
            $stmt = $pdo->prepare("DELETE FROM categorias WHERE id=?");
            $stmt->execute([intval($_POST['delete_id'])]);
            echo json_encode(['success'=>true,'message'=>'Categoria excluída!']);
            exit;
        }

        // ADICIONAIS
        if (isset($_POST['action']) && $_POST['action']==='get_addons') {
            $catId = intval($_POST['category_id']);
            $stmt = $pdo->prepare("SELECT * FROM categoria_adicionais WHERE categoria_id=? ORDER BY nome");
            $stmt->execute([$catId]);
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            exit;
        }

        if (isset($_POST['action']) && $_POST['action']==='save_addon') {
            $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
            $catId = intval($_POST['categoria_id']);
            $nome = trim($_POST['nome']);
            $preco = floatval($_POST['preco']);
            if ($id>0){
                $stmt=$pdo->prepare("UPDATE categoria_adicionais SET nome=?, preco=? WHERE id=?");
                $stmt->execute([$nome,$preco,$id]);
                echo json_encode(['success'=>true,'message'=>'Adicional atualizado!']);
            } else {
                $stmt=$pdo->prepare("INSERT INTO categoria_adicionais (categoria_id,nome,preco) VALUES (?,?,?)");
                $stmt->execute([$catId,$nome,$preco]);
                echo json_encode(['success'=>true,'message'=>'Adicional criado!']);
            }
            exit;
        }

        if (isset($_POST['action']) && $_POST['action']==='delete_addon') {
            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("DELETE FROM categoria_adicionais WHERE id=?");
            $stmt->execute([$id]);
            echo json_encode(['success'=>true,'message'=>'Adicional excluído!']);
            exit;
        }

    } catch (Exception $e) {
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
        exit;
    }
}

// Buscar categorias com contagem de produtos
$stmt = $pdo->query("
    SELECT c.*, COUNT(p.id) AS product_count 
    FROM categorias c
    LEFT JOIN produtos p ON p.categoria_id=c.id
    GROUP BY c.id
    ORDER BY c.criado_em DESC
");
$categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Categorias - Sistema Administrativo</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
.modal {
    display:none;
    position:fixed;
    top:0;left:0;width:100%;height:100%;
    background:rgba(0,0,0,0.5);
    justify-content:center;align-items:center;z-index:999;
}
.modal-content {
    background:#fff;width:90%;max-width:700px;
    border-radius:8px;overflow:hidden;display:flex;flex-direction:column;
}
.modal-header {
    padding:15px;background:#f5f5f5;
    display:flex;justify-content:space-between;align-items:center;
}
.modal-body { padding:20px; }
.modal-close { background:none;border:none;font-size:20px;cursor:pointer; }
.notification { position:fixed; top:20px; right:20px; background:#28a745; color:white; padding:10px 15px; border-radius:5px; box-shadow:0 2px 8px rgba(0,0,0,0.2); opacity:0; transition: all 0.3s; z-index:1000; }
.notification.show { opacity:1; transform:translateY(0); }
.notification.error { background:#dc3545; }
.btn-info{background:#17a2b8;color:#fff;padding:5px 10px;border-radius:4px;border:none;cursor:pointer;}
.btn-info:hover{background:#138496;}
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div class="main-content">
    <div class="header">
        <h1><i class="fas fa-folder-open"></i> Gerenciar Categorias</h1>
        <button class="btn btn-primary" onclick="openCategoryModal()">
            <i class="fas fa-plus"></i> Adicionar Categoria
        </button>
    </div>

    <div class="card">
        <div class="card-content">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th>Produtos</th>
                            <th>Adicionais</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="categoryList">
                        <?php foreach($categorias as $c): ?>
                        <tr>
                            <td><?=$c['id']?></td>
                            <td><?=htmlspecialchars($c['nome'])?></td>
                            <td><?=htmlspecialchars($c['descricao'] ?? '-')?></td>
                            <td><?=$c['product_count']?></td>
                            <td><button class="btn-info" onclick="manageAddons(<?=$c['id']?>,'<?=htmlspecialchars($c['nome'])?>')"><i class="fas fa-list"></i> Gerenciar</button></td>
                            <td>
                                <button class="btn-icon" onclick='editCategory(<?=json_encode($c)?>)'><i class="fas fa-edit"></i></button>
                                <button class="btn-icon btn-danger" onclick='deleteCategory(<?=$c['id']?>)'><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Categoria -->
<div id="categoryModal" class="modal">
<div class="modal-content">
    <div class="modal-header">
        <h3 id="modalTitle">Adicionar Categoria</h3>
        <button class="modal-close" onclick="closeCategoryModal()">&times;</button>
    </div>
    <div class="modal-body">
        <form id="categoryForm">
            <input type="hidden" id="categoryId">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" id="categoryName" required>
            </div>
            <div class="form-group">
                <label>Descrição</label>
                <textarea id="categoryDescription" rows="3"></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Salvar</button>
                <button type="button" class="btn btn-secondary" onclick="closeCategoryModal()">Cancelar</button>
            </div>
        </form>
    </div>
</div>
</div>

<!-- Modal Adicionais -->
<div id="addonsModal" class="modal">
<div class="modal-content">
    <div class="modal-header">
        <h3 id="addonsModalTitle">Adicionais</h3>
        <button class="modal-close" onclick="closeAddonsModal()">&times;</button>
    </div>
    <div class="modal-body">
        <div class="header">
            <h4>Adicionais da categoria: <span id="categoryNameTitle"></span></h4>
            <button class="btn btn-primary" onclick="openAddonModal()"><i class="fas fa-plus"></i> Adicionar Adicional</button>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Nome</th><th>Preço</th><th>Ações</th></tr></thead>
                <tbody id="addonsList"></tbody>
            </table>
        </div>
    </div>
</div>
</div>

<!-- Modal Adicional -->
<div id="addonModal" class="modal">
<div class="modal-content">
    <div class="modal-header">
        <h3 id="addonModalTitle">Adicionar Adicional</h3>
        <button class="modal-close" onclick="closeAddonModal()">&times;</button>
    </div>
    <div class="modal-body">
        <form id="addonForm">
            <input type="hidden" id="addonId">
            <input type="hidden" id="addonCategoryId">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" id="addonName" required>
            </div>
            <div class="form-group">
                <label>Preço</label>
                <input type="number" id="addonPrice" step="0.01" min="0" value="0" required>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Salvar</button>
                <button type="button" class="btn btn-secondary" onclick="closeAddonModal()">Cancelar</button>
            </div>
        </form>
    </div>
</div>
</div>

<script>
function openCategoryModal(){ document.getElementById('categoryModal').style.display='flex'; }
function closeCategoryModal(){ document.getElementById('categoryModal').style.display='none'; document.getElementById('categoryForm').reset(); }

function showNotification(msg,type='success'){
    const n=document.createElement('div'); n.className='notification'+(type==='error'?' error':''); n.textContent=msg;
    document.body.appendChild(n);
    setTimeout(()=>n.classList.add('show'),100);
    setTimeout(()=>{ n.classList.remove('show'); setTimeout(()=>n.remove(),300); },2500);
}

// CATEGORIA CRUD
document.getElementById('categoryForm').addEventListener('submit',function(e){
    e.preventDefault();
    const data=new FormData();
    data.append('action','save_category');
    data.append('id',document.getElementById('categoryId').value);
    data.append('nome',document.getElementById('categoryName').value);
    data.append('descricao',document.getElementById('categoryDescription').value);

    fetch('categorias.php',{method:'POST',body:data})
    .then(r=>r.json())
    .then(res=>{ if(res.success){ showNotification(res.message); closeCategoryModal(); setTimeout(()=>location.reload(),300);} else showNotification(res.message,'error'); })
    .catch(()=>showNotification('Erro de conexão','error'));
});

function editCategory(c){
    openCategoryModal();
    document.getElementById('modalTitle').textContent='Editar Categoria';
    document.getElementById('categoryId').value=c.id;
    document.getElementById('categoryName').value=c.nome;
    document.getElementById('categoryDescription').value=c.descricao;
}

function deleteCategory(id){
    if(confirm('Excluir esta categoria?')){
        const data=new FormData();
        data.append('delete_id',id);
        fetch('categorias.php',{method:'POST',body:data})
        .then(r=>r.json())
        .then(res=>{ if(res.success){ showNotification(res.message); setTimeout(()=>location.reload(),300);} else showNotification(res.message,'error'); });
    }
}

// ADICIONAIS
let currentCategoryId=null;
function manageAddons(catId,name){
    currentCategoryId=catId;
    document.getElementById('categoryNameTitle').textContent=name;
    document.getElementById('addonsModalTitle').textContent='Adicionais: '+name;
    document.getElementById('addonsModal').style.display='flex';
    loadAddons(catId);
}

function closeAddonsModal(){ document.getElementById('addonsModal').style.display='none'; currentCategoryId=null; }

function loadAddons(catId){
    const data=new FormData();
    data.append('action','get_addons'); data.append('category_id',catId);
    fetch('categorias.php',{method:'POST',body:data})
    .then(r=>r.json())
    .then(addons=>{
        const tbody=document.getElementById('addonsList'); tbody.innerHTML='';
        if(addons.length===0){ tbody.innerHTML='<tr><td colspan="3" class="text-center">Nenhum adicional</td></tr>'; return; }
        addons.forEach(a=>{
            const tr=document.createElement('tr');
            tr.innerHTML=`<td>${a.nome}</td><td>R$ ${parseFloat(a.preco).toFixed(2)}</td>
            <td>
                <button class="btn-icon" onclick="editAddon(${a.id},'${a.nome.replace(/'/g,"\\'")}',${a.preco})"><i class="fas fa-edit"></i></button>
                <button class="btn-icon btn-danger" onclick="deleteAddon(${a.id})"><i class="fas fa-trash"></i></button>
            </td>`;
            tbody.appendChild(tr);
        });
    });
}

function openAddonModal(id=null,nome='',preco=0){
    const modal=document.getElementById('addonModal');
    document.getElementById('addonId').value=id||'';
    document.getElementById('addonCategoryId').value=currentCategoryId;
    document.getElementById('addonName').value=nome;
    document.getElementById('addonPrice').value=preco;
    document.getElementById('addonModalTitle').textContent=id?'Editar Adicional':'Adicionar Adicional';
    modal.style.display='flex';
}
function closeAddonModal(){ document.getElementById('addonModal').style.display='none'; document.getElementById('addonForm').reset(); }
function editAddon(id,nome,preco){ openAddonModal(id,nome,preco); }
function deleteAddon(id){
    if(confirm('Excluir este adicional?')){
        const data=new FormData();
        data.append('action','delete_addon'); data.append('id',id);
        fetch('categorias.php',{method:'POST',body:data})
        .then(r=>r.json())
        .then(res=>{ if(res.success){ showNotification(res.message); loadAddons(currentCategoryId);} else showNotification(res.message,'error'); });
    }
}

document.getElementById('addonForm').addEventListener('submit',function(e){
    e.preventDefault();
    const data=new FormData();
    data.append('action','save_addon');
    data.append('id',document.getElementById('addonId').value);
    data.append('categoria_id',document.getElementById('addonCategoryId').value);
    data.append('nome',document.getElementById('addonName').value);
    data.append('preco',document.getElementById('addonPrice').value);
    fetch('categorias.php',{method:'POST',body:data})
    .then(r=>r.json())
    .then(res=>{ if(res.success){ showNotification(res.message); closeAddonModal(); loadAddons(currentCategoryId);} else showNotification(res.message,'error'); });
});

// Fechar modais clicando fora
window.addEventListener('click',e=>{
    ['categoryModal','addonsModal','addonModal'].forEach(id=>{ if(e.target.id===id) document.getElementById(id).style.display='none'; });
});
</script>
</body>
</html>
