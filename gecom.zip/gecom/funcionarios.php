<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? 0;
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $cpf = $_POST['cpf'] ?? '';
    $telefone = $_POST['telefone'] ?? '';
    $cargo = $_POST['cargo'] ?? '';
    $status = $_POST['status'] ?? 'ativo';

    try {
        if ($action === 'save') {
            if (empty($nome) || empty($email) || empty($cpf) || empty($cargo)) {
                throw new Exception('Preencha todos os campos obrigatórios');
            }

            // Validar CPF
            if (!validaCPF($cpf)) {
                throw new Exception('CPF inválido');
            }

            if ($id > 0) {
                // Atualizar funcionário
                $stmt = $pdo->prepare("UPDATE funcionarios SET nome = ?, email = ?, cpf = ?, telefone = ?, cargo = ?, status = ?, atualizado_em = NOW() WHERE id = ?");
                $stmt->execute([$nome, $email, $cpf, $telefone, $cargo, $status, $id]);
                $_SESSION['success_message'] = 'Funcionário atualizado com sucesso!';
            } else {
                // Criar novo funcionário
                $stmt = $pdo->prepare("INSERT INTO funcionarios (nome, email, cpf, telefone, cargo, status) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$nome, $email, $cpf, $telefone, $cargo, $status]);
            }
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM funcionarios WHERE id = ?");
            $stmt->execute([$id]);
        } elseif ($action === 'generate_pin') {
            $pin = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
            $stmt = $pdo->prepare("UPDATE funcionarios SET codigo_pin = ? WHERE id = ?");
            $stmt->execute([$pin, $id]);
            $_SESSION['success_message'] = 'PIN gerado com sucesso: ' . $pin;
        }
    } catch (PDOException $e) {
        $_SESSION['error_message'] = 'Erro no banco de dados: ' . $e->getMessage();
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }

    header('Location: funcionarios.php');
    exit;
}

// Função para validar CPF
function validaCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) != 11) return false;
    if (preg_match('/(\d)\1{10}/', $cpf)) return false;

    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) return false;
    }
    return true;
}

// Buscar funcionários
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? 'all';

$query = "SELECT f.*, 
          (SELECT COUNT(*) FROM turnos_funcionarios WHERE funcionario_id = f.id AND hora_saida IS NULL) AS em_turno
          FROM funcionarios f";

$params = [];
$conditions = [];

if (!empty($search)) {
    $conditions[] = "(f.nome LIKE ? OR f.email LIKE ? OR f.cpf LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($status_filter !== 'all') {
    $conditions[] = "f.status = ?";
    $params[] = $status_filter;
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " ORDER BY f.status, f.nome";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$funcionarios = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Funcionários</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-users"></i> Gerenciar Funcionários</h1>
            <div class="header-actions">
                <form method="get" class="search-form">
                    <input style="height: 35px; width: 200px; border-radius: 5px; padding-left: 10px;" type="text" name="search" placeholder="Pesquisar..." value="<?= htmlspecialchars($search) ?>">
                    <button style="height: 35px; width: 40px; border-radius: 5px; transition: 0.4s" type="submit"><i class="fas fa-search"></i></button>
                </form>
                <button class="btn btn-primary" onclick="openModal()">
                    <i class="fas fa-plus"></i> Novo Funcionário
                </button>
            </div>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Filtros -->
        <div class="filters">
            <a href="?status=all" class="filter-btn <?= $status_filter === 'all' ? 'active' : '' ?>">Todos</a>
            <a href="?status=ativo" class="filter-btn <?= $status_filter === 'ativo' ? 'active' : '' ?>">Ativos</a>
            <a href="?status=inativo" class="filter-btn <?= $status_filter === 'inativo' ? 'active' : '' ?>">Inativos</a>
            <a href="?status=folga" class="filter-btn <?= $status_filter === 'folga' ? 'active' : '' ?>">Folga</a>
        </div>

        <!-- Lista de Funcionários -->
        <div class="card">
            <div class="card-content">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>CPF</th>
                                <th>Cargo</th>
                                <th>Status</th>
                                <th>Turno</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($funcionarios as $f): ?>
                                <tr>
                                    <td><?= htmlspecialchars($f['nome']) ?></td>
                                    <td><?= htmlspecialchars($f['email']) ?></td>
                                    <td class="cpf"><?= htmlspecialchars($f['cpf']) ?></td>
                                    <td><?= ucfirst($f['cargo']) ?></td>
                                    <td>
                                        <span class="badge badge-<?= 
                                            $f['status'] === 'ativo' ? 'success' : 
                                            ($f['status'] === 'folga' ? 'warning' : 'secondary') 
                                        ?>">
                                            <?= ucfirst($f['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= $f['em_turno'] ? '<span class="badge badge-success">Em turno</span>' : '<span class="badge badge-secondary">Fora</span>' ?>
                                    </td>
                                    <td class="actions">
                                        <button class="btn-icon" onclick="editFuncionario(<?= $f['id'] ?>)"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon btn-danger" onclick="confirmDelete(<?= $f['id'] ?>)"><i class="fas fa-trash"></i></button>
                                        <?php if ($f['status'] === 'ativo'): ?>
                                            <button class="btn-icon btn-info" onclick="generatePin(<?= $f['id'] ?>)" title="Gerar PIN"><i class="fas fa-key"></i></button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div id="funcionarioModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Adicionar Funcionário</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <form method="post" id="funcionarioForm">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" id="funcionarioId" value="0">
                
                <div class="form-group">
                    <label for="nome">Nome Completo *</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="cpf">CPF *</label>
                    <input type="text" id="cpf" name="cpf" class="cpf-input" required>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="text" id="telefone" name="telefone" class="phone-input">
                </div>
                <div class="form-group">
                    <label for="cargo">Cargo *</label>
                    <select id="cargo" name="cargo" required>
                        <option value="garcom">Garçom</option>
                        <option value="caixa">Caixa</option>
                        <option value="cozinha">Cozinha</option>
                        <option value="gerente">Gerente</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status *</label>
                    <select id="status" name="status" required>
                        <option value="ativo">Ativo</option>
                        <option value="inativo">Inativo</option>
                        <option value="folga">Folga</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // Abrir modal para adicionar funcionário
    function openModal() {
        document.getElementById('funcionarioModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Adicionar Funcionário';
        document.getElementById('funcionarioForm').reset();
        document.getElementById('funcionarioId').value = 0;
    }

    // Fechar modal
    function closeModal() {
        document.getElementById('funcionarioModal').style.display = 'none';
    }

    // Editar funcionário
    function editFuncionario(id) {
        fetch(`api/get_funcionario.php?id=${id}`)
            .then(response => response.json())
            .then(data => {
                if (data && !data.error) {
                    document.getElementById('modalTitle').textContent = 'Editar Funcionário';
                    document.getElementById('funcionarioId').value = data.id;
                    document.getElementById('nome').value = data.nome;
                    document.getElementById('email').value = data.email;
                    document.getElementById('cpf').value = data.cpf;
                    document.getElementById('telefone').value = data.telefone;
                    document.getElementById('cargo').value = data.cargo;
                    document.getElementById('status').value = data.status;
                    document.getElementById('funcionarioModal').style.display = 'block';
                } else {
                    Swal.fire('Erro', data.error || 'Falha ao carregar os dados', 'error');
                }
            });
    }

    // Fechar modal clicando fora
    window.onclick = function(event) {
        const modal = document.getElementById('funcionarioModal');
        if (event.target == modal) closeModal();
    }

    // Confirmar delete
    function confirmDelete(id) {
        Swal.fire({
            title: 'Tem certeza?',
            text: "Não será possível reverter!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sim, deletar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                const form = document.createElement('form');
                form.method = 'post';
                form.innerHTML = `<input type="hidden" name="action" value="delete">
                                  <input type="hidden" name="id" value="${id}">`;
                document.body.appendChild(form);
                form.submit();
            }
        });
    }

    // Gerar PIN
    function generatePin(id) {
        const form = document.createElement('form');
        form.method = 'post';
        form.innerHTML = `<input type="hidden" name="action" value="generate_pin">
                          <input type="hidden" name="id" value="${id}">`;
        document.body.appendChild(form);
        form.submit();
    }
    </script>
</body>
</html>
