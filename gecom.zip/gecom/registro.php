<?php
require_once 'config/database.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // 2. Validação
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Preencha todos os campos.';
    } elseif (strlen($username) < 3) {
        $error = 'O usuário deve ter pelo menos 3 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'E-mail inválido.';
    } elseif (strlen($password) < 6) {
        $error = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($password !== $confirm_password) {
        $error = 'As senhas não conferem.';
    } else {
        try {
            // 3. Verifica se o usuário ou e-mail já existem
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE nome_usuario = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->fetchColumn() > 0) {
                $error = 'Usuário ou E-mail já cadastrado.';
            } else {
                // 4. Cria a hash da senha
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // 5. Insere o novo usuário no banco de dados
                $stmt = $pdo->prepare("INSERT INTO usuarios (nome_usuario, senha, email) VALUES (?, ?, ?)");
                $stmt->execute([$username, $password_hash, $email]);

                $success = 'Cadastro realizado com sucesso! Você pode fazer login agora.';
            }
        } catch (PDOException $e) {
            // Caso haja algum erro no banco de dados
            $error = 'Erro ao cadastrar: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - Sistema Administrativo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Estilos adicionais para o alerta de sucesso/erro */
        .alert {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h1>Criar Conta</h1>
                <p>Preencha os dados abaixo para se cadastrar</p>
            </div>
            
            <form method="POST" class="login-form">
                
                <?php if ($success): ?>
                    <div class="alert success">
                        <i class="fas fa-check-circle"></i>
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                    <a href="index.php" class="btn btn-primary" style="display: block; text-align: center;">Fazer Login</a>
                <?php else: ?>
                    
                    <?php if ($error): ?>
                        <div class="alert error">
                            <i class="fas fa-exclamation-circle"></i>
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="username">Usuário</label>
                        <input type="text" id="username" name="username" placeholder="Nome de usuário" required value="<?php echo htmlspecialchars($username ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" placeholder="Seu melhor e-mail" required value="<?php echo htmlspecialchars($email ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="password">Senha</label>
                        <input type="password" id="password" name="password" placeholder="Mínimo 6 caracteres" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirmar Senha</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirme sua senha" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i>
                        Cadastrar
                    </button>

                    <div class="login-info">
                        <p>Já tem uma conta? <a href="index.php">Fazer Login</a></p>
                    </div>
                <?php endif; ?>

            </form>
        </div>
    </div>
</body>
</html>