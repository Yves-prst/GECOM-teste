<?php
require_once '../config/auth.php';
logout();
?>
