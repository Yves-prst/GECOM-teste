<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireLogin();

// --- LÓGICA DE ADICIONAIS (Tratamento de requisições AJAX para Add-ons) ---

// Função para buscar adicionais de uma categoria
function getCategoryAddons($pdo, $categoryId) {
    $stmt = $pdo->prepare("SELECT * FROM category_addons WHERE category_id = ? ORDER BY name");
    $stmt->execute([$categoryId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Processar operações de CRUD para Adicionais
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    
    try {
        switch ($action) {
            case 'get_addons':
                if (!isset($_POST['category_id'])) {
                    echo json_encode(['error' => 'ID da categoria não fornecido.']);
                    exit;
                }
                $categoryId = intval($_POST['category_id']);
                echo json_encode(getCategoryAddons($pdo, $categoryId));
                exit;
                
            case 'save_addon':
                $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
                $categoryId = intval($_POST['category_id']);
                $name = trim($_POST['name']);
                // Converte vírgula para ponto e garante float
                $price = floatval(str_replace(',', '.', $_POST['price'])); 
                
                if (empty($name) || $categoryId <= 0) {
                    throw new Exception('Nome e Categoria são obrigatórios.');
                }
                
                if ($id > 0) {
                    // Atualizar adicional
                    $stmt = $pdo->prepare("UPDATE category_addons SET name = ?, price = ? WHERE id = ? AND category_id = ?");
                    $stmt->execute([$name, $price, $id, $categoryId]);
                    echo json_encode(['success' => true]);
                } else {
                    // Criar adicional
                    $stmt = $pdo->prepare("INSERT INTO category_addons (category_id, name, price) VALUES (?, ?, ?)");
                    $stmt->execute([$categoryId, $name, $price]);
                    echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
                }
                exit;
                
            case 'delete_addon':
                $id = intval($_POST['id'] ?? 0);
                if ($id <= 0) {
                     throw new Exception('ID do adicional inválido.');
                }
                $stmt = $pdo->prepare("DELETE FROM category_addons WHERE id = ?");
                $stmt->execute([$id]);
                echo json_encode(['success' => true]);
                exit;
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Erro interno do servidor: ' . $e->getMessage()]);
        exit;
    }
}


// --- LÓGICA DE CATEGORIAS (para a tabela principal) ---

// Buscar categorias (usado para a tabela)
try {
    // Busca categorias e conta produtos associados
    $stmt = $pdo->query("
        SELECT c.*, COUNT(p.id) as product_count
        FROM categorias c
        LEFT JOIN produtos p ON c.id = p.categoria_id
        GROUP BY c.id
        ORDER BY c.created_at DESC
    ");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Em caso de erro (ex: tabela não existe), usar array vazio
    $categories = [];
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categorias - Sistema Administrativo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="header">
            <h1>Gerenciar Categorias</h1>
            <button class="btn btn-primary" onclick="openCategoryModal()">
                <i class="fas fa-plus"></i> Adicionar Categoria
            </button>
        </div>
        
        <div class="card">
            <table class="data-table" id="categoriesTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Produtos Associados</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                    <tr data-category='<?= json_encode($category) ?>'>
                        <td><?= htmlspecialchars($category['id']) ?></td>
                        <td><?= htmlspecialchars($category['name']) ?></td>
                        <td><?= htmlspecialchars($category['description'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($category['product_count']) ?></td>
                        <td>
                            <button class="btn-icon btn-icon-info" onclick="openAddonsModal(<?= $category['id'] ?>, '<?= htmlspecialchars(addslashes($category['name'])) ?>')">
                                <i class="fas fa-list-ul"></i> Adicionais
                            </button>
                            <button class="btn-icon" onclick="editCategory(JSON.parse(this.closest('tr').dataset.category))">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-icon btn-icon-danger" onclick="deleteCategory(<?= $category['id'] ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="categoryModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Adicionar Categoria</h3>
                <button class="modal-close" onclick="closeCategoryModal()">&times;</button>
            </div>
            <form id="categoryForm">
                <input type="hidden" id="categoryId" name="id">
                <div class="form-group">
                    <label for="categoryName">Nome</label>
                    <input type="text" id="categoryName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="categoryDescription">Descrição (Opcional)</label>
                    <textarea id="categoryDescription" name="description"></textarea>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <button type="button" class="btn btn-secondary" onclick="closeCategoryModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <div id="addonsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="addonsModalTitle">Adicionais de Categoria</h3>
                <button class="modal-close" onclick="closeAddonsModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p>Gerencie adicionais para a categoria: <strong id="currentCategoryName"></strong></p>
                <div class="form-actions">
                    <button class="btn btn-primary" onclick="openAddonModal(null)">
                        <i class="fas fa-plus"></i> Novo Adicional
                    </button>
                </div>
                
                <table class="data-table addons-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Preço (R$)</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="addonsTableBody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div id="addonModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="addonModalTitle">Adicionar Adicional</h3>
                <button class="modal-close" onclick="closeAddonModal()">&times;</button>
            </div>
            <form id="addonForm">
                <input type="hidden" id="addonId" name="id">
                <input type="hidden" id="addonCategoryId" name="category_id">
                
                <div class="form-group">
                    <label for="addonName">Nome do Adicional</label>
                    <input type="text" id="addonName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="addonPrice">Preço (R$)</label>
                    <input type="number" id="addonPrice" name="price" step="0.01" required>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar Adicional</button>
                    <button type="button" class="btn btn-secondary" onclick="closeAddonModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="assets/js/categories.js"></script>
    <script>
        // Variável global para rastrear a categoria sendo editada
        let currentCategoryId = null;

        // --- Funções de Adicionais (Comunicação com o próprio categorias.php via AJAX) ---

        function openAddonsModal(categoryId, categoryName) {
            currentCategoryId = categoryId;
            document.getElementById('currentCategoryName').textContent = categoryName;
            document.getElementById('addonsModalTitle').textContent = `Adicionais: ${categoryName}`;
            document.getElementById('addonsModal').classList.add('active');
            document.getElementById('addonsModal').style.display = 'flex';
            loadCategoryAddons(categoryId);
        }

        function closeAddonsModal() {
            document.getElementById('addonsModal').classList.remove('active');
            document.getElementById('addonsModal').style.display = 'none';
            document.getElementById('addonsTableBody').innerHTML = '';
            currentCategoryId = null;
        }
        
        function openAddonModal(addon) {
            // Fechar modal de Adicionais para evitar sobreposição (opcional, mas recomendado)
            document.getElementById('addonsModal').style.display = 'none';

            document.getElementById('addonForm').reset();
            document.getElementById('addonCategoryId').value = currentCategoryId;

            if (addon) {
                document.getElementById('addonModalTitle').textContent = 'Editar Adicional';
                document.getElementById('addonId').value = addon.id;
                document.getElementById('addonName').value = addon.name;
                // Formata para string com 2 casas decimais para o input type="number"
                document.getElementById('addonPrice').value = parseFloat(addon.price).toFixed(2);
            } else {
                document.getElementById('addonModalTitle').textContent = 'Adicionar Novo Adicional';
                document.getElementById('addonId').value = '';
            }

            document.getElementById('addonModal').classList.add('active');
            document.getElementById('addonModal').style.display = 'flex';
        }

        function closeAddonModal() {
            document.getElementById('addonModal').classList.remove('active');
            document.getElementById('addonModal').style.display = 'none';
            document.getElementById('addonForm').reset();

            // Reabrir o modal de Adicionais após fechar o de Adicional
            if (currentCategoryId) {
                document.getElementById('addonsModal').style.display = 'flex';
            }
        }

        async function loadCategoryAddons(categoryId) {
            const tbody = document.getElementById('addonsTableBody');
            tbody.innerHTML = '<tr><td colspan="4" style="text-align: center;">Carregando...</td></tr>';
            
            try {
                const formData = new FormData();
                formData.append('action', 'get_addons');
                formData.append('category_id', categoryId);

                const response = await fetch('categorias.php', {
                    method: 'POST',
                    body: formData
                });
                
                const addons = await response.json();

                tbody.innerHTML = '';
                if (addons.length === 0) {
                     tbody.innerHTML = '<tr><td colspan="4" style="text-align: center;">Nenhum adicional cadastrado.</td></tr>';
                     return;
                }

                addons.forEach(addon => {
                    const row = document.createElement('tr');
                    // Escapa a string do nome para o onclick
                    const addonNameEscaped = addon.name.replace(/'/g, "\\'");
                    row.innerHTML = `
                        <td>${addon.id}</td>
                        <td>${addon.name}</td>
                        <td>R$ ${parseFloat(addon.price).toFixed(2).replace('.', ',')}</td>
                        <td>
                            <button class="btn-icon" onclick="openAddonModal({id: ${addon.id}, name: '${addonNameEscaped}', price: ${addon.price}})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-icon btn-icon-danger" onclick="deleteAddon(${addon.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });

            } catch (error) {
                console.error('Erro ao carregar adicionais:', error);
                tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: red;">Erro ao carregar adicionais.</td></tr>';
            }
        }
        
        async function deleteAddon(id) {
            if (!confirm('Tem certeza que deseja excluir este adicional?')) {
                return;
            }

            try {
                const formData = new FormData();
                formData.append('action', 'delete_addon');
                formData.append('id', id);

                const response = await fetch('categorias.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();

                if (result.success) {
                    // Recarregar a lista de adicionais
                    loadCategoryAddons(currentCategoryId);
                } else {
                    alert('Erro ao excluir adicional: ' + (result.error || 'Erro desconhecido.'));
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao excluir adicional.');
            }
        }

        document.getElementById('addonForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'save_addon');
            
            try {
                const response = await fetch('categorias.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();

                if (data.success) {
                    closeAddonModal();
                    loadCategoryAddons(currentCategoryId);
                } else {
                    alert('Erro ao salvar adicional: ' + (data.error || 'Erro desconhecido.'));
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao salvar adicional.');
            }
        });
        
        // --- Funções de Modal Comuns ---
        // Fechar modais ao clicar fora deles
        window.addEventListener('click', function(event) {
            const categoryModal = document.getElementById('categoryModal');
            const addonsModal = document.getElementById('addonsModal');
            const addonModal = document.getElementById('addonModal');
            
            if (event.target === categoryModal) {
                // assume que closeCategoryModal está no categories.js
                closeCategoryModal(); 
            }
            
            if (event.target === addonsModal) {
                closeAddonsModal();
            }
            
            if (event.target === addonModal) {
                closeAddonModal();
                // Reabre o modal de adicionais se o de adicional for fechado
                if (currentCategoryId) {
                     document.getElementById('addonsModal').style.display = 'flex';
                }
            }
        });
    </script>
</body>
</html>