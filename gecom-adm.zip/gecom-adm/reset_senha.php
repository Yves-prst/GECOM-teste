<?php
require_once 'config/database.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = trim($_POST['token'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if ($token === '') $errors[] = 'Informe o código.';
    if (strlen($password) < 6) $errors[] = 'A senha precisa ter pelo menos 6 caracteres.';
    if ($password !== $confirm) $errors[] = 'As senhas não conferem.';

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id, reset_expires FROM users WHERE reset_token = ?");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $errors[] = 'Código inválido.';
        } elseif (strtotime($user['reset_expires']) < time()) {
            $errors[] = 'Código expirado.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?");
            $stmt->execute([$hash, $user['id']]);
            $success = 'Senha redefinida com sucesso. Agora você pode fazer login.';
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Redefinir senha</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-container">
  <div class="login-box">
    <h2>Redefinir senha</h2>

    <?php if($success): ?>
      <div class="alert success"><?=$success?></div>
      <a href="index.php">Ir para o login</a>
    <?php else: ?>
      <?php if($errors): ?><div class="alert error"><ul><?php foreach($errors as $e) echo "<li>$e</li>"; ?></ul></div><?php endif; ?>

      <form method="post">
        <label>Código</label>
        <input type="text" name="token" required>

        <label>Nova senha</label>
        <input type="password" name="password" required>

        <label>Confirmar senha</label>
        <input type="password" name="confirm" required>

        <button class="btn btn-primary" type="submit">Redefinir</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
