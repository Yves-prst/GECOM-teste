<?php
// generate_backup_codes.php
session_start();
require_once 'config/database.php'; // $pdo

// proteção: usuário logado
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$user_id = $_SESSION['user_id'];

// Função para gerar código legível
function gen_code($len = 8) {
    // evita caracteres ambíguos
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $s = '';
    for ($i=0;$i<$len;$i++) { $s .= $chars[random_int(0, strlen($chars)-1)]; }
    return $s;
}

// Ao gerar: apagamos códigos antigos (opcional)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate'])) {

    // remover códigos antigos (opcional)
    $stmt = $pdo->prepare("DELETE FROM backup_codes WHERE user_id = ?");
    $stmt->execute([$user_id]);

    $codes = [];
    $num = 10;
    for ($i=0;$i<$num;$i++) {
        $plain = gen_code(8);
        $hash = password_hash($plain, PASSWORD_DEFAULT);
        // define expires_at se quiser (ex: 180 dias)
        $expires = date('Y-m-d H:i:s', time() + 60*60*24*180);
        $stmt = $pdo->prepare("INSERT INTO backup_codes (user_id, code_hash, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $hash, $expires]);
        $codes[] = $plain;
    }

    // mostrar códigos para salvar (apenas uma vez)
    $_SESSION['backup_codes_plain'] = $codes; // temporário só pra exibir
    header('Location: generate_backup_codes.php?show=1');
    exit;
}

// Mostrar códigos (se vier da geração)
$show = isset($_GET['show']);
$codes_plain = $_SESSION['backup_codes_plain'] ?? null;
if ($show && $codes_plain) {
    // após mostrar, limpe a sessão para evitar exposição futura
    unset($_SESSION['backup_codes_plain']);
}
?>
<!doctype html>
<html lang="pt-BR">
<head><meta charset="utf-8"><title>Gerar Backup Codes</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
<div class="login-container"><div class="login-box">
  <h2>Códigos de Recuperação</h2>
  <?php if(!$show): ?>
    <p>Gere 10 códigos de recuperação. Salve-os em lugar seguro (print/gestor de senhas). Cada código pode ser usado 1 vez.</p>
    <form method="post">
      <button class="btn btn-primary" name="generate" type="submit">Gerar códigos</button>
    </form>
  <?php else: ?>
    <p><strong>Salve estes códigos agora — serão mostrados apenas uma vez.</strong></p>
    <div class="backup-codes">
      <?php foreach($codes_plain as $c): ?>
        <div class="code-item"><?=htmlspecialchars($c)?></div>
      <?php endforeach; ?>
    </div>
    <p>Depois de salvar, clique em "Concluído".</p>
    <a href="profile.php" class="btn">Concluído</a>
  <?php endif; ?>
  <div style="margin-top:10px;"><a href="profile.php">Voltar</a></div>
</div></div>
</body></html>
