<?php
session_start();
require_once __DIR__ . '/database.php'; 

function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

function requerLogin() {
    if (!estaLogado()) {
        header('Location: index.php');
        exit();
    }
}

// FUNÇÃO login()
function login($username, $password) {
    global $pdo; 
    
    $stmt = $pdo->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        return true;
    }
    
    return false;
}

function fazerLogout() {
    session_destroy();
    header('Location: ../index.php');
    exit();
}

function isAdmin() {
    return isset($_SESSION['perfil']) && $_SESSION['perfil'] === 'admin';
}

function requerAdmin() {
    requerLogin(); // Primeiro verifica se está logado
    
    if (!isAdmin()) {
        // Redireciona para o dashboard se não for admin
        header('Location: dashboard.php');
        exit();
    }
}
?>