<?php
// require_once '../config/database.php'; // Manter esta linha
// require_once '../config/auth.php';     // Manter esta linha
// requireAdmin();                         // Manter esta linha

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'ID do funcionário não fornecido']);
    exit;
}

$id = $_GET['id'];
// Tradução: employees -> funcionarios
$stmt = $pdo->prepare("SELECT * FROM funcionarios WHERE id = ?");
$stmt->execute([$id]);
// Tradução: employee -> funcionario
$funcionario = $stmt->fetch();

if (!$funcionario) {
    echo json_encode(['error' => 'Funcionário não encontrado']);
    exit;
}

// Tradução de nomes de colunas
echo json_encode([
    'id' => $funcionario['id'],
    'name' => $funcionario['nome'],        // name -> nome
    'email' => $funcionario['email'],
    'cpf' => $funcionario['cpf'],
    'phone' => $funcionario['telefone'],   // phone -> telefone
    'position' => $funcionario['cargo'],   // position -> cargo
    'status' => $funcionario['status'],
    'pin_code' => $funcionario['codigo_pin'], // pin_code -> codigo_pin
    'created_at' => $funcionario['criado_em'], // created_at -> criado_em
    'updated_at' => $funcionario['atualizado_em'] // updated_at -> atualizado_em
]);