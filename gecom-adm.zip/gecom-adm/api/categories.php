<?php
// require_once '../config/database.php'; // Manter esta linha
// require_once '../config/auth.php';     // Manter esta linha

header('Content-Type: application/json');

// if (!isLoggedIn()) { // Manter esta linha
//     http_response_code(401);
//     echo json_encode(['error' => 'Não autorizado']);
//     exit();
// }

$method = $_SERVER['REQUEST_METHOD'];

try {
    // $pdo = getPdoConnection(); // Assumindo uma função de conexão no database.php

    switch ($method) {
        case 'GET':
            // Tradução: categories -> categorias, products -> produtos, category_id -> categoria_id
            $stmt = $pdo->query("
                SELECT c.*, COUNT(p.id) as product_count 
                FROM categorias c 
                LEFT JOIN produtos p ON c.id = p.categoria_id 
                GROUP BY c.id 
                ORDER BY c.criado_em DESC
            ");
            echo json_encode($stmt->fetchAll());
            break;
            
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Tradução: categories -> categorias, name -> nome, description -> descricao
            $stmt = $pdo->prepare("
                INSERT INTO categorias (nome, descricao) 
                VALUES (?, ?)
            ");
            $stmt->execute([
                $data['name'], // Manter 'name' no JSON de entrada, pois o JS usa este nome
                $data['description'] ?: null // Manter 'description' no JSON de entrada
            ]);
            
            echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
            break;
            
        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Tradução: categories -> categorias, name -> nome, description -> descricao
            $stmt = $pdo->prepare("
                UPDATE categorias 
                SET nome = ?, descricao = ? 
                WHERE id = ?
            ");
            $stmt->execute([
                $data['name'],
                $data['description'] ?: null,
                $data['id']
            ]);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'DELETE':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Tradução: products -> produtos, category_id -> categoria_id
            // Remover referência da categoria nos produtos
            $stmt = $pdo->prepare("UPDATE produtos SET categoria_id = NULL WHERE categoria_id = ?");
            $stmt->execute([$data['id']]);
            
            // Tradução: categories -> categorias
            // Deletar categoria
            $stmt = $pdo->prepare("DELETE FROM categorias WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            echo json_encode(['success' => true]);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    // Erro corrigido: Tradução da mensagem de erro
    echo json_encode(['error' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
// Não é necessário a tag de fechamento ?> em arquivos PHP