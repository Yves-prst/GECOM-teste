<?php
// require_once '../config/database.php'; // Manter esta linha
// require_once '../config/auth.php';     // Manter esta linha

header('Content-Type: application/json');

// if (!isLoggedIn()) { // Manter esta linha
//     http_response_code(401);
//     echo json_encode(['error' => 'Não autorizado']);
//     exit();
// }

$method = $_SERVER['REQUEST_METHOD'];

try {
    // $pdo = getPdoConnection(); // Assumindo uma função de conexão no database.php

    switch ($method) {
        case 'GET':
            // Tradução: products -> produtos, categories -> categorias, category_id -> categoria_id, name -> nome, created_at -> criado_em
            $stmt = $pdo->query("
                SELECT p.*, c.nome as category_name 
                FROM produtos p 
                LEFT JOIN categorias c ON p.categoria_id = c.id 
                ORDER BY p.criado_em DESC
            ");
            echo json_encode($stmt->fetchAll());
            break;
            
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Tradução: products -> produtos, name -> nome, price -> preco, category_id -> categoria_id
            $stmt = $pdo->prepare("
                INSERT INTO produtos (nome, preco, status, categoria_id) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $data['name'],
                $data['price'],
                $data['status'],
                $data['category_id'] ?: null
            ]);
            
            echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
            break;
            
        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Tradução: products -> produtos, name -> nome, price -> preco, category_id -> categoria_id
            $stmt = $pdo->prepare("
                UPDATE produtos 
                SET nome = ?, preco = ?, status = ?, categoria_id = ? 
                WHERE id = ?
            ");
            $stmt->execute([
                $data['name'],
                $data['price'],
                $data['status'],
                $data['category_id'] ?: null,
                $data['id']
            ]);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'DELETE':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Tradução: products -> produtos
            $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
            $stmt->execute([$data['id']]);
            
            echo json_encode(['success' => true]);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor: ' . $e->getMessage()]);
}