<?php
// require_once '../config/database.php'; // Manter esta linha
// require_once '../config/auth.php';     // Manter esta linha

// if (!isLoggedIn()) { // Manter esta linha
//     header('Location: ../index.php');
//     exit();
// }

$period = $_GET['period'] ?? 'week';

// Obter dados baseado no período
if ($period === 'week') {
    $startDate = date('Y-m-d', strtotime('monday this week'));
    $endDate = date('Y-m-d', strtotime('sunday this week'));
    $title = 'Relatório Semanal de Vendas';
} else {
    $startDate = date('Y-m-01');
    $endDate = date('Y-m-t');
    $title = 'Relatório Mensal de Vendas';
}

// Tradução: sales -> vendas, product_name -> nome_produto, quantity -> quantidade, total_price -> preco_total, sale_date -> data_venda
$stmt = $pdo->prepare("
    SELECT 
        nome_produto as product,
        SUM(quantidade) as quantity,
        SUM(preco_total) as total
    FROM vendas 
    WHERE DATE(data_venda) BETWEEN ? AND ?
    GROUP BY nome_produto
    ORDER BY total DESC
");
$stmt->execute([$startDate, $endDate]);
$data = $stmt->fetchAll();

// Se não houver dados, usa dados de exemplo (Mantido, mas ajustado para nomes em português)
if (empty($data)) {
    $data = [
        ['product' => 'Hambúrguer Especial', 'quantity' => 25, 'total' => 375.00],
        ['product' => 'Refrigerante', 'quantity' => 45, 'total' => 135.00],
        ['product' => 'Batata Frita', 'quantity' => 15, 'total' => 120.00],
    ];
}

$totalRevenue = array_sum(array_column($data, 'total'));
$totalQuantity = array_sum(array_column($data, 'quantity'));

// O restante do código HTML para o PDF (Mantido, já traduzido e com formatação brasileira)
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?></title>
    <style>
        /* Estilos CSS (Mantidos, mas garantindo que o PDF saia limpo) */
        body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
        h1 { color: #4CAF50; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; color: #555; }
        .total-row { background-color: #d9edf7; }
        .summary { margin-top: 30px; padding: 15px; border: 1px solid #ccc; border-radius: 5px; }
        .summary h3 { margin-top: 0; color: #555; }
    </style>
</head>
<body>
    <h1><?php echo $title; ?></h1>
    <p>Período: <?php echo date('d/m/Y', strtotime($startDate)); ?> a <?php echo date('d/m/Y', strtotime($endDate)); ?></p>

    <table>
        <thead>
            <tr>
                <th>Produto</th>
                <th>Quant. Vendida</th>
                <th>Receita (R$)</th>
                <th>% da Receita Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>R$ <?php echo number_format($item['total'], 2, ',', '.'); ?></td>
                    <td><?php echo number_format(($item['total'] / $totalRevenue) * 100, 1, ',', '.'); ?>%</td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td><strong>TOTAL</strong></td>
                <td><strong><?php echo $totalQuantity; ?></strong></td>
                <td><strong>R$ <?php echo number_format($totalRevenue, 2, ',', '.'); ?></strong></td>
                <td><strong>100,0%</strong></td>
            </tr>
        </tbody>
    </table>
    
    <div class="summary">
        <h3>Resumo do Período</h3>
        <p><strong>Total de produtos diferentes:</strong> <?php echo count($data); ?></p>
        <p><strong>Total de itens vendidos:</strong> <?php echo $totalQuantity; ?></p>
        <p><strong>Receita total:</strong> R$ <?php echo number_format($totalRevenue, 2, ',', '.'); ?></p>
        <p><strong>Produto mais vendido:</strong> <?php echo $data[0]['product'] ?? 'N/A'; ?></p>
        <p><strong>Ticket médio:</strong> R$ <?php echo $totalQuantity > 0 ? number_format($totalRevenue / $totalQuantity, 2, ',', '.') : '0,00'; ?></p>
    </div>
</body>
</html>