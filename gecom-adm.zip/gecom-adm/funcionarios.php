<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

// Função para validar CPF
function validaCPF($cpf) {
    // Remove caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', (string) $cpf);
    
    // Verifica se o número de dígitos é 11
    if (strlen($cpf) != 11) return false;
    
    // Verifica se todos os dígitos são iguais (inválido)
    if (preg_match('/(\d)\1{10}/', $cpf)) return false;
    
    // Cálculo para verificar o primeiro dígito verificador
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) return false;
    }
    
    return true;
}


// Processar formulário (salvar/atualizar/deletar)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? 0;
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $cpf = $_POST['cpf'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $position = $_POST['position'] ?? '';
    $status = $_POST['status'] ?? 'ativo';
    $pin_code = $_POST['pin_code'] ?? null;
    
    // Limpar CPF para armazenamento/validação
    $cpf_limpo = preg_replace('/[^0-9]/', '', $cpf); 

    try {
        if ($action === 'save') {
            if (empty($name) || empty($email) || empty($cpf_limpo) || empty($position)) {
                throw new Exception('Preencha todos os campos obrigatórios');
            }

            // Validar CPF
            if (!validaCPF($cpf_limpo)) {
                throw new Exception('CPF inválido');
            }
            
            // Verifica se o CPF/Email já existe (excluindo o atual na edição)
            $sql_check = "SELECT COUNT(*) FROM employees WHERE (cpf = ? OR email = ?) " . ($id > 0 ? "AND id != ?" : "");
            $params_check = [$cpf_limpo, $email];
            if ($id > 0) {
                $params_check[] = $id;
            }
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute($params_check);
            if ($stmt_check->fetchColumn() > 0) {
                throw new Exception('CPF ou E-mail já cadastrado.');
            }

            if ($id > 0) {
                // Atualizar funcionário
                $stmt = $pdo->prepare("UPDATE employees SET name = ?, email = ?, cpf = ?, phone = ?, position = ?, status = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$name, $email, $cpf_limpo, $phone, $position, $status, $id]);
                $_SESSION['success_message'] = 'Funcionário atualizado com sucesso!';
            } else {
                // Criar funcionário
                if (empty($pin_code) || strlen($pin_code) !== 4) {
                     throw new Exception('O PIN de acesso deve ter 4 dígitos.');
                }
                
                // Hash do PIN de 4 dígitos
                $pin_hash = password_hash($pin_code, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("INSERT INTO employees (name, email, cpf, phone, position, status, pin_code) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $email, $cpf_limpo, $phone, $position, $status, $pin_hash]);
                $_SESSION['success_message'] = 'Funcionário adicionado com sucesso!';
            }
            
            header('Location: funcionarios.php');
            exit;
            
        } elseif ($action === 'delete') {
             if ($id <= 0) {
                 throw new Exception('ID inválido para exclusão.');
             }
             $stmt = $pdo->prepare("DELETE FROM employees WHERE id = ?");
             $stmt->execute([$id]);
             $_SESSION['success_message'] = 'Funcionário excluído com sucesso!';
             
             header('Location: funcionarios.php');
             exit;
        }

    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
        // Manter o erro na sessão para ser exibido após o redirecionamento (caso fosse redirecionar)
        // Como não redirecionamos em caso de erro, a mensagem é exibida diretamente
    }
}

// Buscar lista de funcionários
$stmt = $pdo->query("SELECT * FROM employees ORDER BY name");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

$message = '';
if (isset($_SESSION['success_message'])) {
    $message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    $message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funcionários - Sistema Administrativo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <h1>Gerenciar Funcionários</h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Adicionar Funcionário
            </button>
        </div>
        
        <?php if ($message): ?>
            <div class="alert <?= strpos($message, 'sucesso') !== false ? 'success' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>CPF</th>
                        <th>Telefone</th>
                        <th>Cargo</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employees as $employee): ?>
                    <tr>
                        <td><?= htmlspecialchars($employee['name']) ?></td>
                        <td><?= htmlspecialchars($employee['email']) ?></td>
                        <td><?= htmlspecialchars(substr($employee['cpf'], 0, 3)) . '...'. htmlspecialchars(substr($employee['cpf'], -3)) ?></td>
                        <td><?= htmlspecialchars($employee['phone'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($employee['position']) ?></td>
                        <td><span class="status-badge status-<?= $employee['status'] === 'ativo' ? 'success' : 'danger' ?>"><?= ucfirst($employee['status']) ?></span></td>
                        <td>
                            <button class="btn-icon" onclick="editEmployee(<?= $employee['id'] ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-icon btn-icon-danger" onclick="deleteEmployee(<?= $employee['id'] ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="employeeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Adicionar Funcionário</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <form id="employeeForm" method="POST" action="funcionarios.php">
                <input type="hidden" id="employeeId" name="id" value="0">
                <input type="hidden" name="action" value="save">
                
                <div class="form-group">
                    <label for="employeeName">Nome</label>
                    <input type="text" id="employeeName" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="employeeEmail">E-mail</label>
                    <input type="email" id="employeeEmail" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="employeeCpf">CPF</label>
                    <input type="text" id="employeeCpf" name="cpf" required data-inputmask="'mask': '999.999.999-99'">
                </div>
                
                <div class="form-group">
                    <label for="employeePhone">Telefone</label>
                    <input type="tel" id="employeePhone" name="phone" data-inputmask="'mask': '(99) 99999-9999'">
                </div>
                
                <div class="form-group">
                    <label for="employeePosition">Cargo</label>
                    <input type="text" id="employeePosition" name="position" required>
                </div>

                <div class="form-group">
                    <label for="employeeStatus">Status</label>
                    <select id="employeeStatus" name="status" required>
                        <option value="ativo">Ativo</option>
                        <option value="inativo">Inativo</option>
                    </select>
                </div>

                <div class="form-group" id="pinGroup">
                    <label for="employeePin">PIN de Acesso (4 dígitos)</label>
                    <input type="password" id="employeePin" name="pin_code" required minlength="4" maxlength="4">
                    <small class="form-text text-muted">Apenas para criação de novo funcionário. Não é necessário para edição.</small>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Função para aplicar as máscaras
        function applyMasks() {
            // Verifica se o InputMask está carregado antes de usar
            if (typeof $.fn.inputmask === 'function') {
                $('#employeeCpf').inputmask();
                $('#employeePhone').inputmask();
            }
        }

        // Função para carregar dados do funcionário para edição
        function editEmployee(id) {
            // Busca os dados do funcionário via API
            fetch(`api/get_employee.php?id=${id}`)
                .then(res => {
                    if (!res.ok) throw new Error('Falha ao carregar');
                    return res.json();
                })
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                        return;
                    }

                    document.getElementById('employeeId').value = data.id;
                    document.getElementById('employeeName').value = data.name;
                    document.getElementById('employeeEmail').value = data.email;
                    // A API deve retornar o CPF formatado ou o InputMask cuidará
                    document.getElementById('employeeCpf').value = data.cpf; 
                    document.getElementById('employeePhone').value = data.phone;
                    document.getElementById('employeePosition').value = data.position;
                    document.getElementById('employeeStatus').value = data.status;
                    
                    document.getElementById('modalTitle').textContent = 'Editar Funcionário';
                    
                    // Esconder o campo de PIN na edição e remover o 'required'
                    document.getElementById('pinGroup').style.display = 'none';
                    document.getElementById('employeePin').removeAttribute('required');

                    openModal();
                })
                .catch(() => alert('Erro ao carregar dados do funcionário.'));
        }

        // Função para deletar funcionário
        function deleteEmployee(id) {
            if (!confirm('Tem certeza que deseja excluir este funcionário? Esta ação é irreversível.')) {
                return;
            }

            // Submete um formulário via POST para a exclusão
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'funcionarios.php';

            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            form.appendChild(actionInput);

            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = id;
            form.appendChild(idInput);
                        
            document.body.appendChild(form);
            form.submit();
        }

        // Abrir modal
        function openModal() {
            document.getElementById('employeeModal').style.display = 'block';
            applyMasks();
            // Garante que para "Adicionar" o campo PIN esteja visível
            if (document.getElementById('employeeId').value === '0') {
                 document.getElementById('pinGroup').style.display = 'block';
                 document.getElementById('employeePin').setAttribute('required', 'required');
            }
        }

        // Fechar modal
        function closeModal() {
            document.getElementById('employeeModal').style.display = 'none';
            document.getElementById('employeeForm').reset();
            document.getElementById('employeeId').value = '0';
            document.getElementById('modalTitle').textContent = 'Adicionar Funcionário';
            
            // Mostrar o campo de PIN e adicionar o 'required' para nova adição
            document.getElementById('pinGroup').style.display = 'block';
            document.getElementById('employeePin').setAttribute('required', 'required');
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('employeeModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Inicializar máscaras após o DOM carregar
        document.addEventListener('DOMContentLoaded', applyMasks);
    </script>
</body>
</html>