<?php
require_once 'config/database.php';
require_once 'config/auth.php';
requireAdmin();

// Função para salvar configurações
function saveSetting($pdo, $name, $value)
{
    $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
    $stmt->execute([$name, $value, $value]);
}

// Função para carregar configurações
function loadSettings($pdo)
{
    $stmt = $pdo->query("SELECT name, value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    return $settings;
}

$settings = loadSettings($pdo);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Informações do Estabelecimento
        saveSetting($pdo, 'nome_estabelecimento', trim($_POST['nome'] ?? ''));
        saveSetting($pdo, 'endereco_estabelecimento', trim($_POST['endereco'] ?? ''));
        saveSetting($pdo, 'telefone_estabelecimento', trim($_POST['telefone'] ?? ''));

        // Configurações do Sistema
        // Converto vírgula para ponto para salvar no formato float, se necessário
        $taxa_servico = str_replace(',', '.', $_POST['taxa_servico'] ?? 0);
        saveSetting($pdo, 'taxa_servico', floatval($taxa_servico));
        saveSetting($pdo, 'horario_abertura', trim($_POST['abertura'] ?? ''));
        saveSetting($pdo, 'horario_fechamento', trim($_POST['fechamento'] ?? ''));

        $settings = loadSettings($pdo); // Recarregar após salvar
        $_SESSION['success_message'] = 'Configurações salvas com sucesso!';
        header('Location: configuracoes.php');
        exit();

    } catch (Exception $e) {
        $message = 'Erro ao salvar: ' . $e->getMessage();
        // Não redirecionar em caso de erro para mostrar a mensagem
    }
}

// Limpar mensagem de sucesso da sessão
if (isset($_SESSION['success_message'])) {
    $message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
} elseif (isset($_SESSION['error_message'])) {
    $message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Configurações - Sistema Administrativo</title>
</head>

<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">

        <div class="header">
            <h1>Configurações</h1>
        </div>

        <?php if ($message): ?>
            <div class="alert <?= strpos($message, 'sucesso') !== false ? 'success' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="form-grid" id="form-config">

            <form method="POST" class="card info-system">
                <h2>Informações do Estabelecimento</h2>

                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($settings['nome_estabelecimento'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label for="endereco">Endereço</label>
                    <input type="text" id="endereco" name="endereco" value="<?= htmlspecialchars($settings['endereco_estabelecimento'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="tel" id="telefone" name="telefone" value="<?= htmlspecialchars($settings['telefone_estabelecimento'] ?? '') ?>">
                </div>

                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">Salvar Informações</button>
                </div>
            </form>

            <form method="POST" class="card config-system">
                <h2>Configurações do Sistema</h2>

                <div class="form-group">
                    <label for="taxa_servico">Taxa de Serviço (%)</label>
                    <input type="number" id="taxa_servico" name="taxa_servico" step="0.01" value="<?= number_format(floatval($settings['taxa_servico'] ?? 0), 2, '.', '') ?>" placeholder="Ex: 10.00">
                </div>

                <div class="form-group">
                    <label for="abertura">Horário de Abertura</label>
                    <input type="time" id="abertura" name="abertura" value="<?= htmlspecialchars($settings['horario_abertura'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label for="fechamento">Horário de Fechamento</label>
                    <input type="time" id="fechamento" name="fechamento" value="<?= htmlspecialchars($settings['horario_fechamento'] ?? '') ?>">
                </div>

                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">Salvar Configurações</button>
                </div>
            </form>
        </div>

    </div>
</body>

</html>