<?php
require_once 'config/database.php';
require_once 'config/auth.php';

requireLogin(); // <--- AQUI ESTÁ O ERRO

// Buscar estatísticas
$today = date('Y-m-d');

// Total vendido hoje
$stmt = $pdo->prepare("SELECT COALESCE(SUM(total_price), 0) as total FROM sales WHERE DATE(sale_date) = ?");
$stmt->execute([$today]);
$totalToday = $stmt->fetchColumn();

// Comandas abertas
$stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'open'");
$openOrders = $stmt->fetchColumn();

// Comandas fechadas hoje
$stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE status = 'closed' AND DATE(closed_at) = ?");
$stmt->execute([$today]);
$closedOrders = $stmt->fetchColumn();

// Funcionários em turno
// Supondo a tabela employee_shifts existe e o status de turno é controlado lá.
try {
    $stmt = $pdo->query("
        SELECT e.name, e.position 
        FROM employees e
        LEFT JOIN employee_shifts s ON e.id = s.employee_id
        WHERE s.end_time IS NULL OR s.end_time IS NULL AND DATE(s.start_time) = CURDATE()
        GROUP BY e.id
    ");
    $onShift = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Tratar o erro se a tabela 'employee_shifts' não existir
    $onShift = [];
}

// Meta atual
$currentMonth = date('n');
$currentYear = date('Y');
$stmt = $pdo->prepare("SELECT * FROM goals WHERE month = ? AND year = ?");
$stmt->execute([$currentMonth, $currentYear]);
$currentGoal = $stmt->fetch(PDO::FETCH_ASSOC);

$goalTarget = $currentGoal['target'] ?? 0;
// Calcular o total vendido no mês atual
$startOfMonth = date('Y-m-01');
$endOfMonth = date('Y-m-t');
$stmt = $pdo->prepare("SELECT COALESCE(SUM(total_price), 0) as total FROM sales WHERE DATE(sale_date) BETWEEN ? AND ?");
$stmt->execute([$startOfMonth, $endOfMonth]);
$monthlySales = $stmt->fetchColumn();

// Top 5 produtos mais vendidos
// Assumindo a tabela de produtos como 'produtos' e sales como 'sales'
try {
    $stmt = $pdo->query("
        SELECT p.id, p.name, SUM(s.quantity) as total_quantity
        FROM produtos p 
        JOIN sales s ON p.id = s.product_id 
        WHERE DATE(s.sale_date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY p.id, p.name
        ORDER BY total_quantity DESC
        LIMIT 5
    ");
    $topProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $topProducts = [];
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema Administrativo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="header">
            <h1>Dashboard</h1>
            <button class="btn btn-secondary" onclick="toggleValue()">
                <i id="eyeIcon" class="fas fa-eye"></i> Esconder/Mostrar Valores
            </button>
        </div>

        <div class="stats-grid">
            
            <div class="stat-card">
                <div class="stat-info">
                    <p class="stat-label">Venda Total Hoje</p>
                    <h2 class="stat-value"><span id="totalValue">R$ <?php echo number_format($totalToday, 2, ',', '.'); ?></span></h2>
                </div>
                <div class="stat-icon"><i class="fas fa-coins"></i></div>
            </div>

            <div class="stat-card">
                <div class="stat-info">
                    <p class="stat-label">Comandas Abertas</p>
                    <h2 class="stat-value"><?php echo $openOrders; ?></h2>
                </div>
                <div class="stat-icon"><i class="fas fa-bell"></i></div>
            </div>

            <div class="stat-card">
                <div class="stat-info">
                    <p class="stat-label">Comandas Fechadas Hoje</p>
                    <h2 class="stat-value"><?php echo $closedOrders; ?></h2>
                </div>
                <div class="stat-icon"><i class="fas fa-receipt"></i></div>
            </div>

            <div class="stat-card">
                <div class="stat-info">
                    <p class="stat-label">Meta Mensal (R$)</p>
                    <h2 class="stat-value goal-value">R$ <?php echo number_format($goalTarget, 2, ',', '.'); ?></h2>
                    <p class="stat-sub-label">Alcançado: R$ <?php echo number_format($monthlySales, 2, ',', '.'); ?></p>
                    <?php 
                        $progress = $goalTarget > 0 ? min(100, ($monthlySales / $goalTarget) * 100) : 0;
                    ?>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $progress; ?>%;"></div>
                        <span class="progress-text"><?php echo round($progress, 1); ?>%</span>
                    </div>
                </div>
                <div class="stat-icon" onclick="openGoalModal()"><i class="fas fa-bullseye"></i></div>
            </div>
        </div>

        <div class="card-grid">
            <div class="card highlights-card">
                <div class="card-header">
                    <h3>Funcionários em Turno</h3>
                    <i class="fas fa-users-cog"></i>
                </div>
                <div class="card-content">
                    <?php if (!empty($onShift)): ?>
                        <?php foreach ($onShift as $employee): ?>
                            <div class="highlight-item">
                                <span class="highlight-title"><?php echo htmlspecialchars($employee['name']); ?></span>
                                <span class="highlight-value"><?php echo htmlspecialchars($employee['position']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Nenhum funcionário em turno.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card highlights-card">
                <div class="card-header">
                    <h3>Top 5 Produtos (Últimos 7 Dias)</h3>
                    <i class="fas fa-box-open"></i>
                </div>
                <div class="card-content">
                    <table class="simple-table">
                        <thead>
                            <tr>
                                <th>Produto</th>
                                <th class="text-right">Qtd. Vendida</th>
                                <th class="text-right">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($topProducts)): ?>
                                <?php foreach ($topProducts as $product): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                                        <td class="text-right"><?php echo $product['total_quantity']; ?></td>
                                        <td class="text-right">
                                            <a href="produtos.php?edit=<?php echo $product['id']; ?>" class="btn-icon">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" style="text-align: center;">Nenhuma venda nos últimos 7 dias.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="goalModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Definir Meta Mensal</h3>
                    <button class="modal-close" onclick="closeGoalModal()">&times;</button>
                </div>
                <form id="goalForm">
                    <div class="form-group">
                        <label for="goalTarget">Valor da Meta (R$)</label>
                        <input type="number" id="goalTarget" step="0.01" placeholder="2000.00" value="<?php echo htmlspecialchars($goalTarget); ?>" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Definir Meta</button>
                        <button type="button" class="btn btn-secondary" onclick="closeGoalModal()">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="assets/js/dashboard.js"></script>
</body>
</html>