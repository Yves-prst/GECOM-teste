CREATE DATABASE  IF NOT EXISTS `sistema_administracao_restaurante` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `sistema_administracao_restaurante`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_administracao_restaurante
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Tabela `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Doces','Doces em geral','2025-07-24 00:20:23'),(2,'Lanches','Hambúrguers, sanduíches e similares','2025-07-24 03:34:55'),(3,'Bebidas','Refrigerantes, sucos e bebidas em geral','2025-07-24 03:34:55'),(4,'Sobremesas','Doces, sorvetes e sobremesas','2025-07-24 03:34:55'),(5,'Acompanhamentos','Batatas, saladas e acompanhamentos','2025-07-24 03:34:55');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `adicionais_categoria`
--

DROP TABLE IF EXISTS `adicionais_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adicionais_categoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `categoria_id` int NOT NULL,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) DEFAULT '0.00',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_categoria_id` (`categoria_id`),
  CONSTRAINT `adicionais_categoria_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `adicionais_categoria`
--

LOCK TABLES `adicionais_categoria` WRITE;
/*!40000 ALTER TABLE `adicionais_categoria` DISABLE KEYS */;
INSERT INTO `adicionais_categoria` VALUES (9,3,'Gelo',0.00,'2025-09-01 23:39:46','2025-09-01 23:39:46'),(12,2,'Cheddar',2.50,'2025-09-01 23:41:47','2025-09-01 23:41:47');
/*!40000 ALTER TABLE `adicionais_categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `turnos_funcionario`
--

DROP TABLE IF EXISTS `turnos_funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turnos_funcionario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `funcionario_id` int NOT NULL,
  `hora_inicio` datetime NOT NULL,
  `hora_fim` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `funcionario_id` (`funcionario_id`),
  CONSTRAINT `turnos_funcionario_ibfk_1` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `turnos_funcionario`
--

LOCK TABLES `turnos_funcionario` WRITE;
/*!40000 ALTER TABLE `turnos_funcionario` DISABLE KEYS */;
/*!40000 ALTER TABLE `turnos_funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `cargo` enum('garcom','caixa','cozinha','gerente') NOT NULL,
  `codigo_pin` varchar(6) DEFAULT NULL,
  `status` enum('ativo','inativo','folga') DEFAULT 'ativo',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `funcionarios`
--

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
INSERT INTO `funcionarios` VALUES (3,'asudfhrgidsayfhg','yves@gmail.com','15053852960','1231243124124','cozinha',NULL,'ativo','2025-07-28 23:08:14','2025-07-28 23:08:14');
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `metas`
--

DROP TABLE IF EXISTS `metas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alvo` decimal(10,2) NOT NULL,
  `valor_atual` decimal(10,2) DEFAULT '0.00',
  `mes` int NOT NULL,
  `ano` int NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_month_year` (`mes`,`ano`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `metas`
--

LOCK TABLES `metas` WRITE;
/*!40000 ALTER TABLE `metas` DISABLE KEYS */;
INSERT INTO `metas` VALUES (1,200.00,0.00,7,2025,'2025-07-24 00:19:46'),(2,2000.00,0.00,8,2025,'2025-08-05 06:26:56'),(3,20000.00,0.00,9,2025,'2025-09-24 21:49:42');
/*!40000 ALTER TABLE `metas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `pedidos_mesa` (Antiga mesa_orders)
--

DROP TABLE IF EXISTS `pedidos_mesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos_mesa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mesa_id` int NOT NULL,
  `pedido_id` int NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `mesa_id` (`mesa_id`),
  KEY `pedido_id` (`pedido_id`),
  CONSTRAINT `pedidos_mesa_ibfk_1` FOREIGN KEY (`mesa_id`) REFERENCES `mesas` (`id`),
  CONSTRAINT `pedidos_mesa_ibfk_2` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `pedidos_mesa`
--

LOCK TABLES `pedidos_mesa` WRITE;
/*!40000 ALTER TABLE `pedidos_mesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos_mesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `mesas`
--

DROP TABLE IF EXISTS `mesas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mesas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero` int NOT NULL,
  `capacidade` int NOT NULL DEFAULT '1',
  `status` enum('disponivel','ocupada','reservada') DEFAULT 'disponivel',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `mesas`
--

LOCK TABLES `mesas` WRITE;
/*!40000 ALTER TABLE `mesas` DISABLE KEYS */;
INSERT INTO `mesas` VALUES (19,1,1,'ocupada'),(20,2,3,'ocupada'),(21,3,3,'reservada'),(22,4,6,'disponivel'),(23,5,5,'disponivel');
/*!40000 ALTER TABLE `mesas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `pedidos` (Antiga orders)
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('aberto','fechado') DEFAULT 'aberto',
  `total` decimal(10,2) DEFAULT '0.00',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fechado_em` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,'aberto',500.00,'2025-08-17 07:45:25',NULL),(2,'aberto',14.00,'2025-08-17 08:08:55',NULL),(3,'aberto',25.00,'2025-08-17 08:34:36',NULL),(4,'aberto',25.00,'2025-08-17 08:52:49',NULL),(5,'aberto',25.00,'2025-08-17 08:54:46',NULL),(6,'aberto',25.00,'2025-08-17 08:55:25',NULL),(7,'aberto',5.00,'2025-08-17 08:57:07',NULL),(8,'aberto',25.00,'2025-08-17 09:09:21',NULL),(9,'aberto',6.00,'2025-08-17 09:10:17',NULL),(10,'aberto',24.00,'2025-08-17 10:28:05',NULL),(11,'aberto',50.00,'2025-08-19 02:03:34',NULL);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `status` enum('Ativo','Inativo') DEFAULT 'Ativo',
  `categoria_id` int DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `categoria_id` (`categoria_id`),
  CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Morango do Amo',25.00,'Ativo',1,'2025-07-24 00:20:36'),(2,'Hambúrguer Especial',14.00,'Ativo',2,'2025-07-24 03:34:55'),(3,'Pizza Margherita',18.50,'Ativo',2,'2025-07-24 03:34:55'),(4,'Refrigerante Lata',3.00,'Ativo',3,'2025-07-24 03:34:55'),(5,'Batata Frita Grande',8.00,'Ativo',5,'2025-07-24 03:34:55'),(6,'Sorvete Chocolate',5.00,'Ativo',4,'2025-07-24 03:34:55'),(7,'Suco Natural',4.50,'Ativo',3,'2025-07-24 03:34:55'),(8,'Hambúrguer Simples',12.00,'Ativo',2,'2025-07-24 03:34:55'),(9,'Torta de Limão',6.00,'Ativo',4,'2025-07-24 03:34:55'),(10,'Uva do amor',15.00,'Ativo',1,'2025-08-19 02:06:24'),(11,'X Eggs',14.90,'Ativo',2,'2025-08-19 02:09:15');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `vendas` (Antiga sales)
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `produto_id` int DEFAULT NULL,
  `nome_produto` varchar(100) NOT NULL,
  `quantidade` int NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  `preco_total` decimal(10,2) NOT NULL,
  `data_venda` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `produto_id` (`produto_id`),
  CONSTRAINT `vendas_ibfk_1` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `vendas` (Correção do preço unitário para $25.00 na linha 1)
--

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
INSERT INTO `vendas` VALUES (1,1,'Morango do Amor',2,25.00,50.00,'2025-08-17 07:45:25'),(2,2,'Hambúrguer Especial',1,14.00,14.00,'2025-08-17 08:08:55'),(3,1,'Morango do Amor',1,25.00,25.00,'2025-08-17 08:34:36'),(4,1,'Morango do Amor',1,25.00,25.00,'2025-08-17 08:52:49'),(5,1,'Morango do Amor',1,25.00,25.00,'2025-08-17 08:54:46'),(6,1,'Morango do Amor',1,25.00,25.00,'2025-08-17 08:55:25'),(7,6,'Sorvete Chocolate',1,5.00,5.00,'2025-08-17 08:57:07'),(8,1,'Morango do Amor',1,25.00,25.00,'2025-08-17 09:09:21'),(9,9,'Torta de Limão',1,6.00,6.00,'2025-08-17 09:10:17'),(10,5,'Batata Frita Grande',3,8.00,24.00,'2025-08-17 10:28:05'),(11,1,'Morango do Amor',2,25.00,50.00,'2025-08-19 02:03:34');
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Tabela `usuarios` (Antiga users)
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `perfil` enum('administrador','usuario') NOT NULL DEFAULT 'usuario',
  `email` varchar(150) DEFAULT NULL,
  `token_reset` varchar(255) DEFAULT NULL,
  `reset_expira` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome_usuario` (`nome_usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dados para a tabela `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2y$10$VOsjClGjPiD5c/ttQSJvp.LjYgt9dcI.anw5uG1qNTuOaqABjbPx2','2025-07-24 00:19:37','usuario',NULL,'6cceae3770','2025-10-14 23:35:56');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;