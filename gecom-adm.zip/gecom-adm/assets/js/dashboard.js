// Funcionalidade do Dashboard
let isValueHidden = false;

function toggleValue() {
  const valueElement = document.getElementById("totalValue");
  const iconElement = document.getElementById("eyeIcon");

  if (isValueHidden) {
    valueElement.style.filter = "none";
    iconElement.className = "fas fa-eye";
    isValueHidden = false;
  } else {
    valueElement.style.filter = "blur(5px)";
    iconElement.className = "fas fa-eye-slash";
    isValueHidden = true;
  }
}

// Modal de Metas
function openGoalModal() {
  document.getElementById("goalModal").classList.add("active");
  document.getElementById("goalModal").style.display = "flex";
}

function closeGoalModal() {
  document.getElementById("goalModal").classList.remove("active");
  document.getElementById("goalModal").style.display = "none";
  document.getElementById("goalForm").reset();
}

// Submissão do Formulário de Metas
document.getElementById("goalForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const target = document.getElementById("goalTarget").value;

  try {
    // Rota de API alterada: api/goals.php -> api/metas.php
    const response = await fetch("api/metas.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ target: Number.parseFloat(target) }),
    });

    const result = await response.json();

    if (result.success) {
      console.log("Meta definida com sucesso!");
      closeGoalModal();
      showNotification("Meta mensal salva com sucesso!", "success"); // Adicionado notificação visual
      setTimeout(() => location.reload(), 500); // Tempo para ver a notificação
    } else {
      showNotification(result.error || "Erro ao definir meta.", "error"); // Adicionado notificação visual
      console.error("Erro ao definir meta:", result.error);
    }
  } catch (error) {
    showNotification("Erro de comunicação com o servidor.", "error");
    console.error("Erro na requisição:", error);
  }
});

// Função de Notificação (Copiada para garantir que o dashboard.js a tenha, caso não haja um arquivo utils.js)
function showNotification(message, type = "info") {
  const notification = document.createElement("div");
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
        <i class="fas fa-${type === "success" ? "check-circle" : "exclamation-circle"}"></i>
        ${message}
    `;

  if (!document.querySelector(".notification-styles")) {
    const style = document.createElement("style");
    style.className = "notification-styles";
    style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
                gap: 10px;
                z-index: 10000;
                transform: translateX(400px);
                transition: transform 0.3s ease;
                max-width: 300px;
            }
            .notification.show {
                transform: translateX(0);
            }
            .notification-success {
                border-left: 4px solid #28a745;
                color: #155724;
            }
            .notification-error {
                border-left: 4px solid #dc3545;
                color: #721c24;
            }
            .notification i {
                font-size: 18px;
            }
        `;
    document.head.appendChild(style);
  }

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.classList.add("show");
  }, 100);

  setTimeout(() => {
    notification.classList.remove("show");
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 500); 
  }, 3000); 
}


// Atualiza a dashboard
async function refreshStats() {
  try {
    // Rota de API assumida (precisará de api/stats.php para funcionar)
    const response = await fetch("api/stats.php"); 
    const stats = await response.json();

    // Atualiza estatísticas (assumindo que o HTML da dashboard.php usa estes seletores)
    document.querySelector(".stat-card:nth-child(1) .stat-value span").textContent =
      `R$ ${stats.totalToday.toFixed(2).replace(".", ",")}`;
    document.querySelector(".stat-card:nth-child(2) .stat-value").textContent = stats.openOrders;
    // ... continuar atualizando os outros cards
    
  } catch (error) {
    // Não mostra notificação de erro em auto-refresh
    console.error("Erro ao atualizar estatísticas:", error); 
  }
}

// Inicializa dashboard
document.addEventListener("DOMContentLoaded", () => {
  // Chamada inicial para carregar os dados
  refreshStats();
  // Auto-refresh a cada 30 segundos
  setInterval(refreshStats, 30000);
});