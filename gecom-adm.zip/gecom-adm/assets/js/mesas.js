// Funções de Modal para Mesas
function openMesaModal() {
    document.getElementById('mesaModal').classList.add('active');
    document.getElementById('mesaId').value = '';
    // A propriedade 'mesaNumero' foi removida, a nota de remoção no código foi mantida como comentário para orientação
    // document.getElementById('mesaNumero').value = ''; 
    document.getElementById('mesaCapacidade').value = '';
    document.getElementById('mesaStatus').value = 'disponivel';
    document.getElementById('modalMesaTitle').textContent = 'Adicionar Mesa';
}

function closeMesaModal() {
    document.getElementById('mesaModal').classList.remove('active');
    // Adicionado reset do formulário
    document.getElementById('mesaForm').reset(); 
}

function editMesa(id) {
    // Rota da API mantida como mesas.php, pois o front-end está buscando os dados no mesmo arquivo.
    fetch(`mesas.php?action=get&id=${id}`) 
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                // Mensagem traduzida
                alert(data.error); 
                return;
            }
            document.getElementById('mesaId').value = data.id;
            // Tradução de coluna: 'capacidade' e 'status' já são português
            document.getElementById('mesaCapacidade').value = data.capacidade;
            document.getElementById('mesaStatus').value = data.status;
            // Assumindo que o campo 'numero' ainda existe para fins de exibição
            document.getElementById('modalMesaTitle').textContent = 'Editar Mesa ' + data.numero; 
            document.getElementById('mesaModal').classList.add('active');
        }).catch(() => alert('Erro ao carregar mesa.'));
}

document.getElementById('mesaForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const id = document.getElementById('mesaId').value;
    const capacidade = document.getElementById('mesaCapacidade').value;
    const status = document.getElementById('mesaStatus').value;
    // A propriedade 'numero' não é enviada, pois é definida pelo backend na criação
    const action = id ? 'edit' : 'create';

    // Os dados são enviados como form-urlencoded para o mesas.php
    let body = `capacidade=${encodeURIComponent(capacidade)}&status=${encodeURIComponent(status)}`;
    if (id) {
        body += `&id=${encodeURIComponent(id)}`;
    }

    fetch(`mesas.php?action=${action}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body
    })
        .then(res => res.text())
        .then(msg => {
            // Mensagens do servidor devem ser tratadas aqui (assumindo que mesas.php retorna texto)
            alert(msg); 
            closeMesaModal();
            // Necessário recarregar para ver a alteração
            location.reload(); 
        })
        .catch(() => alert('Erro ao salvar mesa.'));
});

function deleteMesa(id) {
    // Mensagem traduzida
    if (!confirm('Deseja realmente excluir esta mesa?')) return; 

    fetch(`mesas.php?action=delete&id=${id}`)
        .then(res => res.text())
        .then(msg => {
            alert(msg);
            location.reload();
        })
        .catch(() => alert('Erro ao excluir mesa.'));
}