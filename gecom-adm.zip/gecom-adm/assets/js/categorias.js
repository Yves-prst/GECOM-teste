// Gerenciamento de Categorias
let editingCategoryId = null;

function openCategoryModal() {
  document.getElementById("categoryModal").classList.add("active");
  document.getElementById("categoryModal").style.display = "flex";
  document.getElementById("modalTitle").textContent = "Adicionar Categoria";
  editingCategoryId = null;
}

function closeCategoryModal() {
  document.getElementById("categoryModal").classList.remove("active");
  document.getElementById("categoryModal").style.display = "none";
  document.getElementById("categoryForm").reset();
  document.getElementById("categoryId").value = "";
  editingCategoryId = null;
}

function editCategory(category) {
  document.getElementById("categoryModal").classList.add("active");
  document.getElementById("categoryModal").style.display = "flex";
  document.getElementById("modalTitle").textContent = "Editar Categoria";

  document.getElementById("categoryId").value = category.id;
  document.getElementById("categoryName").value = category.name;
  document.getElementById("categoryDescription").value = category.description || "";

  editingCategoryId = category.id;
}

async function deleteCategory(id) {
  if (
    // Mensagem de confirmação traduzida
    !confirm("Tem certeza que deseja excluir esta categoria? Todos os produtos desta categoria ficarão sem categoria.")
  ) {
    return;
  }

  try {
    // Rota de API alterada: api/categories.php -> api/categorias.php
    const response = await fetch("api/categorias.php", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id: id }),
    });

    const result = await response.json();

    if (result.success) {
      showNotification("Categoria excluída com sucesso!", "success");
      // Atualiza a lista após a exclusão
      setTimeout(() => location.reload(), 500);
    } else {
      showNotification(result.error || "Erro ao excluir categoria.", "error");
    }
  } catch (error) {
    showNotification("Erro de comunicação com o servidor.", "error");
  }
}

// Lógica de Submissão do Formulário (POST/PUT)
document.getElementById("categoryForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("categoryId").value;
  const name = document.getElementById("categoryName").value;
  const description = document.getElementById("categoryDescription").value;

  const data = {
    id: id,
    name: name,
    description: description,
  };

  try {
    // Rota de API alterada: api/categories.php -> api/categorias.php
    const response = await fetch("api/categorias.php", {
      method: id ? "PUT" : "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (result.success) {
      closeCategoryModal();
      showNotification(`Categoria ${id ? 'atualizada' : 'adicionada'} com sucesso!`, "success");
      // Atualiza a lista após a submissão
      setTimeout(() => location.reload(), 500);
    } else {
      showNotification(result.error || "Erro ao salvar categoria.", "error");
    }
  } catch (error) {
    showNotification("Erro de comunicação com o servidor.", "error");
  }
});


// Função de Notificação (Mantida, pois já estava funcional)
function showNotification(message, type = "info") {
  const notification = document.createElement("div");
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
        <i class="fas fa-${type === "success" ? "check-circle" : "exclamation-circle"}"></i>
        ${message}
    `;

  // Adiciona estilos de notificação se não existirem
  if (!document.querySelector(".notification-styles")) {
    const style = document.createElement("style");
    style.className = "notification-styles";
    style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
                gap: 10px;
                z-index: 10000;
                transform: translateX(400px);
                transition: transform 0.3s ease;
                max-width: 300px;
            }
            .notification.show {
                transform: translateX(0);
            }
            .notification-success {
                border-left: 4px solid #28a745;
                color: #155724;
            }
            .notification-error {
                border-left: 4px solid #dc3545;
                color: #721c24;
            }
            .notification i {
                font-size: 18px;
            }
        `;
    document.head.appendChild(style);
  }

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.classList.add("show");
  }, 100);

  setTimeout(() => {
    notification.classList.remove("show");
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 500); // Aumentei o tempo para 500ms para uma transição mais suave
  }, 3000); // 3 segundos
}