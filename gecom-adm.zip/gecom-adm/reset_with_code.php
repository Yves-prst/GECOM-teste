<?php
// reset_with_code.php
session_start();
require_once 'config/database.php'; // $pdo

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if ($code === '') $errors[] = 'Informe o código.';
    if (strlen($password) < 6) $errors[] = 'Senha precisa ter ao menos 6 caracteres.';
    if ($password !== $password_confirm) $errors[] = 'As senhas não conferem.';

    if (empty($errors)) {
        // Buscar por todos os códigos (não sabemos user_id) — seleciona candidatos não usados e não expirados
        $stmt = $pdo->prepare("SELECT id, user_id, code_hash, used, expires_at FROM backup_codes WHERE used = 0");
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $found = null;
        foreach ($rows as $r) {
            // checar expiração
            if ($r['expires_at'] && strtotime($r['expires_at']) < time()) continue;
            if (password_verify($code, $r['code_hash'])) {
                $found = $r;
                break;
            }
        }

        if (!$found) {
            $errors[] = 'Código inválido ou expirado.';
            // opcional: logar tentativas e rate-limit
        } else {
            // atualiza senha do usuário
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hash, $found['user_id']]);

            // marca o código como usado
            $stmt = $pdo->prepare("UPDATE backup_codes SET used = 1 WHERE id = ?");
            $stmt->execute([$found['id']]);

            $success = 'Senha redefinida com sucesso. Agora você pode entrar.';
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><title>Redefinir com código</title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="login-container"><div class="login-box">
  <h2>Redefinir senha com código</h2>

  <?php if($success): ?>
    <div class="alert success"><?=htmlspecialchars($success)?></div>
    <a href="index.php">Ir para login</a>
  <?php else: ?>
    <?php if(!empty($errors)) echo '<div class="alert error"><ul><li>'.implode('</li><li>',$errors).'</li></ul></div>'; ?>

    <form method="post">
      <label>Código de recuperação</label>
      <input type="text" name="code" required>

      <label>Nova senha</label>
      <input type="password" name="password" required>

      <label>Confirmar senha</label>
      <input type="password" name="password_confirm" required>

      <button class="btn btn-primary" type="submit">Redefinir</button>
    </form>
  <?php endif; ?>
  <div style="margin-top:12px;"><a href="index.php">Voltar</a></div>
</div></div>
</body></html>
