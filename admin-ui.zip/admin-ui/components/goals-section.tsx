"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"

interface Goal {
  id: number
  target: number
  current: number
  month: string
  year: number
}

export function GoalsSection() {
  const [goal, setGoal] = useState<Goal | null>(null)
  const [newTarget, setNewTarget] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    fetchCurrentGoal()
  }, [])

  const fetchCurrentGoal = async () => {
    try {
      const response = await fetch("/api/goals/current")
      if (response.ok) {
        const data = await response.json()
        setGoal(data)
      }
    } catch (error) {
      console.error("Erro ao buscar meta:", error)
    }
  }

  const handleSetGoal = async () => {
    try {
      const response = await fetch("/api/goals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: Number.parseFloat(newTarget) }),
      })

      if (response.ok) {
        toast({
          title: "Meta definida com sucesso!",
          description: `Meta de R$ ${newTarget} foi definida para este mês.`,
        })
        setIsOpen(false)
        setNewTarget("")
        fetchCurrentGoal()
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao definir meta",
        variant: "destructive",
      })
    }
  }

  const progressPercentage = goal ? Math.min((goal.current / goal.target) * 100, 100) : 0

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Meta Mensal de Vendas</CardTitle>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>Definir Meta</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Definir Meta Mensal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="target">Valor da Meta (R$)</Label>
                <Input
                  id="target"
                  type="number"
                  step="0.01"
                  placeholder="2000.00"
                  value={newTarget}
                  onChange={(e) => setNewTarget(e.target.value)}
                />
              </div>
              <Button onClick={handleSetGoal} className="w-full">
                Definir Meta
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {goal ? (
          <div className="space-y-4">
            <div className="text-lg font-medium">
              R$ {goal.current.toFixed(2)} / R$ {goal.target.toFixed(2)}
            </div>
            <div className="space-y-2">
              <Progress value={progressPercentage} className="h-3" />
              <div className="text-sm text-muted-foreground">{progressPercentage.toFixed(1)}% da meta atingida</div>
            </div>
          </div>
        ) : (
          <div className="text-muted-foreground">Nenhuma meta definida para este mês</div>
        )}
      </CardContent>
    </Card>
  )
}
