"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Calendar } from "lucide-react"

interface Highlight {
  id: number
  title: string
  description: string
  value: number
  date: string
  type: "sale" | "goal" | "product"
}

export function HighlightsSection() {
  const [highlights, setHighlights] = useState<Highlight[]>([])

  useEffect(() => {
    fetchHighlights()
  }, [])

  const fetchHighlights = async () => {
    try {
      const response = await fetch("/api/highlights")
      const data = await response.json()
      setHighlights(data)
    } catch (error) {
      console.error("Erro ao buscar destaques:", error)
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "sale":
        return "bg-green-100 text-green-800"
      case "goal":
        return "bg-blue-100 text-blue-800"
      case "product":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "sale":
        return "Venda"
      case "goal":
        return "Meta"
      case "product":
        return "Produto"
      default:
        return "Geral"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Destaques Recentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {highlights.map((highlight) => (
            <div key={highlight.id} className="flex items-start justify-between p-4 border rounded-lg">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge className={getTypeColor(highlight.type)}>{getTypeLabel(highlight.type)}</Badge>
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {new Date(highlight.date).toLocaleDateString("pt-BR")}
                  </span>
                </div>
                <h4 className="font-medium">{highlight.title}</h4>
                <p className="text-sm text-muted-foreground">{highlight.description}</p>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-green-600">R$ {highlight.value.toFixed(2)}</div>
              </div>
            </div>
          ))}
          {highlights.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">Nenhum destaque disponível</div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
