<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css?v=1.1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <title>Mesas - Sistema Administrativo</title>
</head>

<body>

    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-chair"></i> Gerenciar Mesas</h1>
            <div class="header-actions">
                <button class="btn btn-primary" onclick="openProductModal()">
                    <i class="fas fa-plus"></i>
                    Adicionar Mesa
                </button>
            </div>
        </div>

        <!-- Resumo -->
        <div class="stats-grid">

            <div class="tables-content">
                <div class="stat-content">

                    <div class="header-tables">
                        <h2>Mesa 1</h2>
                        <button style="background-color: #28a745;">Livre</button>
                    </div>

                    <h3>Capacidade: 4 pessoas</h3>

                    <div class="icons-tables">

                        <button class="btn-icon" onclick="">
                            <i class="fas fa-edit"></i>
                        </button>
                        
                        <button class="btn-icon btn-danger" onclick="">
                            <i class="fas fa-trash"></i>
                        </button>

                    </div>

                </div>
            </div>

            <div class="tables-content">
                <div class="stat-content">

                    <div class="header-tables">
                        <h2>Mesa 2</h2>
                        <button style="background-color: #dd1f01ff;">Ocupada</button>
                    </div>

                    <h3>Capacidade: 1 pessoas</h3>

                    <div class="icons-tables">

                        <button class="btn-icon" onclick="">
                            <i class="fas fa-edit"></i>
                        </button>

                        <button class="btn-icon btn-danger" onclick="">
                            <i class="fas fa-trash"></i>
                        </button>

                    </div>


                </div>
            </div>

            <div class="tables-content">
                <div class="stat-content">

                    <div class="header-tables">
                        <h2>Mesa 3</h2>
                        <button style="background-color: #064aa4ff;">Reservada</button>
                    </div>

                    <h3>Capacidade: 6 pessoas</h3>

                    <div class="icons-tables">

                        <button class="btn-icon" onclick="">
                            <i class="fas fa-edit"></i>
                        </button>
                        
                        <button class="btn-icon btn-danger" onclick="">
                            <i class="fas fa-trash"></i>
                        </button>

                    </div>

                </div>
            </div>

            <div class="tables-content">
                <div class="stat-content">

                    <div class="header-tables">
                        <h2>Mesa 4</h2>
                        <button style="background-color: #28a745;">Livre</button>
                    </div>

                    <h3>Capacidade: 2 pessoas</h3>

                    <div class="icons-tables">

                        <button class="btn-icon" onclick="">
                            <i class="fas fa-edit"></i>
                        </button>
                        
                        <button class="btn-icon btn-danger" onclick="">
                            <i class="fas fa-trash"></i>
                        </button>

                    </div>
                    
                </div>
            </div>

        </div>

</body>

</html>