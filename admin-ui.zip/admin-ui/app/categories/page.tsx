import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { CategoriesManager } from "@/components/categories-manager"

export default async function CategoriesPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Gerenciar Categorias</h1>
      <CategoriesManager />
    </div>
  )
}
