import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    initializeDatabase()

    const { name, price, status, category_id } = await request.json()
    const id = Number.parseInt(params.id)

    db.prepare(`
      UPDATE products 
      SET name = ?, price = ?, status = ?, category_id = ? 
      WHERE id = ?
    `).run(name, price, status, category_id || null, id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Products PUT error:", error)
    return NextResponse.json({ error: "Erro ao atualizar produto" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    initializeDatabase()

    const id = Number.parseInt(params.id)

    db.prepare("DELETE FROM products WHERE id = ?").run(id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Products DELETE error:", error)
    return NextResponse.json({ error: "Erro ao excluir produto" }, { status: 500 })
  }
}
