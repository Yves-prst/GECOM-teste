import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    initializeDatabase()

    const { searchParams } = new URL(request.url)
    const limit = searchParams.get("limit")

    let query = `
      SELECT p.*, c.name as category_name 
      FROM products p 
      LEFT JOIN categories c ON p.category_id = c.id 
      ORDER BY p.created_at DESC
    `

    if (limit) {
      query += ` LIMIT ${Number.parseInt(limit)}`
    }

    const products = db.prepare(query).all()

    return NextResponse.json(products)
  } catch (error) {
    console.error("Products GET error:", error)
    return NextResponse.json({ error: "Erro ao buscar produtos" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    initializeDatabase()

    const { name, price, status, category_id } = await request.json()

    const result = db
      .prepare(`
      INSERT INTO products (name, price, status, category_id) 
      VALUES (?, ?, ?, ?)
    `)
      .run(name, price, status, category_id || null)

    return NextResponse.json({ id: result.lastInsertRowid, success: true })
  } catch (error) {
    console.error("Products POST error:", error)
    return NextResponse.json({ error: "Erro ao criar produto" }, { status: 500 })
  }
}
