import { NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function GET() {
  try {
    initializeDatabase()

    const now = new Date()
    const month = now.getMonth() + 1
    const year = now.getFullYear()

    // Get current month goal
    const goal = db
      .prepare(`
      SELECT * FROM goals WHERE month = ? AND year = ?
    `)
      .get(month, year)

    if (!goal) {
      return NextResponse.json(null)
    }

    // Calculate current sales for the month
    const currentSales = db
      .prepare(`
      SELECT COALESCE(SUM(total_price), 0) as total 
      FROM sales 
      WHERE strftime('%m', sale_date) = ? AND strftime('%Y', sale_date) = ?
    `)
      .get(month.toString().padStart(2, "0"), year.toString()) as { total: number }

    return NextResponse.json({
      ...goal,
      current: currentSales.total,
    })
  } catch (error) {
    console.error("Current goal error:", error)
    return NextResponse.json({ error: "Erro ao buscar meta atual" }, { status: 500 })
  }
}
