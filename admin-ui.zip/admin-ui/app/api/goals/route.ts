import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    initializeDatabase()

    const { target } = await request.json()
    const now = new Date()
    const month = now.getMonth() + 1
    const year = now.getFullYear()

    // Check if goal already exists for current month
    const existingGoal = db
      .prepare(`
      SELECT id FROM goals WHERE month = ? AND year = ?
    `)
      .get(month, year)

    if (existingGoal) {
      // Update existing goal
      db.prepare(`
        UPDATE goals SET target = ? WHERE month = ? AND year = ?
      `).run(target, month, year)
    } else {
      // Create new goal
      db.prepare(`
        INSERT INTO goals (target, month, year) VALUES (?, ?, ?)
      `).run(target, month, year)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Goals POST error:", error)
    return NextResponse.json({ error: "Erro ao definir meta" }, { status: 500 })
  }
}
