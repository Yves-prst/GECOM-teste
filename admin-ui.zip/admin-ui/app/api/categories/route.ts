import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function GET() {
  try {
    initializeDatabase()

    const categories = db
      .prepare(`
      SELECT c.*, COUNT(p.id) as product_count 
      FROM categories c 
      LEFT JOIN products p ON c.id = p.category_id 
      GROUP BY c.id 
      ORDER BY c.created_at DESC
    `)
      .all()

    return NextResponse.json(categories)
  } catch (error) {
    console.error("Categories GET error:", error)
    return NextResponse.json({ error: "Erro ao buscar categorias" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    initializeDatabase()

    const { name, description } = await request.json()

    const result = db
      .prepare(`
      INSERT INTO categories (name, description) 
      VALUES (?, ?)
    `)
      .run(name, description || null)

    return NextResponse.json({ id: result.lastInsertRowid, success: true })
  } catch (error) {
    console.error("Categories POST error:", error)
    return NextResponse.json({ error: "Erro ao criar categoria" }, { status: 500 })
  }
}
