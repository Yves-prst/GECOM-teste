import { NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function GET() {
  try {
    initializeDatabase()

    const now = new Date()
    const month = now.getMonth() + 1
    const year = now.getFullYear()

    const monthData = db
      .prepare(`
      SELECT 
        product_name as product,
        SUM(quantity) as quantity,
        SUM(total_price) as total
      FROM sales 
      WHERE strftime('%m', sale_date) = ? AND strftime('%Y', sale_date) = ?
      GROUP BY product_name
      ORDER BY total DESC
    `)
      .all(month.toString().padStart(2, "0"), year.toString())

    // If no data, create sample data
    if (monthData.length === 0) {
      const sampleData = [
        { product: "Hambúrguer Especial", quantity: 120, total: 1800.0 },
        { product: "Pizza Margherita", quantity: 85, total: 1275.0 },
        { product: "Refrigerante", quantity: 200, total: 600.0 },
        { product: "Batata Frita", quantity: 150, total: 600.0 },
        { product: "Sorvete", quantity: 90, total: 450.0 },
      ]

      return NextResponse.json(sampleData)
    }

    return NextResponse.json(monthData)
  } catch (error) {
    console.error("Month report error:", error)
    return NextResponse.json({ error: "Erro ao buscar relatório mensal" }, { status: 500 })
  }
}
