import { type NextRequest, NextResponse } from "next/server"
import db, { initializeDatabase } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    initializeDatabase()

    const { period } = await request.json()

    // Get data based on period
    let data: any[] = []
    let title = ""

    if (period === "week") {
      const now = new Date()
      const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()))
      const endOfWeek = new Date(now.setDate(now.getDate() - now.getDay() + 6))

      data = db
        .prepare(`
        SELECT 
          product_name as product,
          SUM(quantity) as quantity,
          SUM(total_price) as total
        FROM sales 
        WHERE DATE(sale_date) BETWEEN ? AND ?
        GROUP BY product_name
        ORDER BY total DESC
      `)
        .all(startOfWeek.toISOString().split("T")[0], endOfWeek.toISOString().split("T")[0])

      title = "Relatório Semanal de Vendas"
    } else {
      const now = new Date()
      const month = now.getMonth() + 1
      const year = now.getFullYear()

      data = db
        .prepare(`
        SELECT 
          product_name as product,
          SUM(quantity) as quantity,
          SUM(total_price) as total
        FROM sales 
        WHERE strftime('%m', sale_date) = ? AND strftime('%Y', sale_date) = ?
        GROUP BY product_name
        ORDER BY total DESC
      `)
        .all(month.toString().padStart(2, "0"), year.toString())

      title = "Relatório Mensal de Vendas"
    }

    // If no data, use sample data
    if (data.length === 0) {
      data = [
        { product: "Hambúrguer Especial", quantity: 25, total: 375.0 },
        { product: "Pizza Margherita", quantity: 18, total: 270.0 },
        { product: "Refrigerante", quantity: 45, total: 135.0 },
        { product: "Batata Frita", quantity: 30, total: 120.0 },
        { product: "Sorvete", quantity: 20, total: 100.0 },
      ]
    }

    // Generate simple PDF content (HTML to be converted to PDF)
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${title}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; }
          h1 { color: #333; text-align: center; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
          th { background-color: #f2f2f2; }
          .total { font-weight: bold; background-color: #f9f9f9; }
        </style>
      </head>
      <body>
        <h1>${title}</h1>
        <p>Gerado em: ${new Date().toLocaleDateString("pt-BR")}</p>
        
        <table>
          <thead>
            <tr>
              <th>Produto</th>
              <th>Quantidade</th>
              <th>Total (R$)</th>
            </tr>
          </thead>
          <tbody>
            ${data
              .map(
                (item) => `
              <tr>
                <td>${item.product}</td>
                <td>${item.quantity}</td>
                <td>R$ ${item.total.toFixed(2)}</td>
              </tr>
            `,
              )
              .join("")}
            <tr class="total">
              <td><strong>TOTAL</strong></td>
              <td><strong>${data.reduce((sum, item) => sum + item.quantity, 0)}</strong></td>
              <td><strong>R$ ${data.reduce((sum, item) => sum + item.total, 0).toFixed(2)}</strong></td>
            </tr>
          </tbody>
        </table>
      </body>
      </html>
    `

    // For now, return the HTML content as a simple text file
    // In a real implementation, you would use a library like puppeteer to generate actual PDF
    return new NextResponse(htmlContent, {
      headers: {
        "Content-Type": "text/html",
        "Content-Disposition": `attachment; filename="relatorio-${period}-${new Date().toISOString().split("T")[0]}.html"`,
      },
    })
  } catch (error) {
    console.error("PDF generation error:", error)
    return NextResponse.json({ error: "Erro ao gerar PDF" }, { status: 500 })
  }
}
