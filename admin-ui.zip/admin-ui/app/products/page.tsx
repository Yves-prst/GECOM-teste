import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { ProductsManager } from "@/components/products-manager"

export default async function ProductsPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Gerenciar Produtos</h1>
      <ProductsManager />
    </div>
  )
}
