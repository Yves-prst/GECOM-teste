import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
  timeout: 10000,
});

// Mesas
export const fetchTables = () => api.get('/mesas');
export const updateTableStatus = (id, status) => api.put(`/mesas/${id}/status`, { status });

// Categorias
export const fetchCategories = () => api.get('/categories');

// Produtos
export const fetchProducts = () => api.get('/products-with-addons');
export const fetchProductsByCategory = (categoryId) => api.get(`/products/by-category/${categoryId}`);

// Pedidos
export const createOrder = (mesaId, items) => api.post('/orders', { mesaId, items });
export const fetchOpenOrder = (tableId) => api.get(`/orders/open/${tableId}`);
export const updateOrder = (orderId, items) => api.put(`/orders/${orderId}`, { items });
export const closeTableAndOrder = (mesaId, paymentMethod) => api.post(`/mesas/${mesaId}/close-order`, { paymentMethod });

// SSE para atualizações em tempo real
const setupSSEListener = (endpoint, callback) => {
  let eventSource;
  
  try {
    eventSource = new EventSource(`${api.defaults.baseURL}${endpoint}/sse`);
    
    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        callback(data);
      } catch (error) {
        console.error('Erro ao processar mensagem SSE:', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('SSE Error:', error);
      eventSource.close();
    };
  } catch (error) {
    console.error('Erro ao criar EventSource:', error);
  }

  return () => {
    if (eventSource) {
      eventSource.close();
    }
  };
};

export const listenForTablesUpdates = (callback) => setupSSEListener('/mesas', callback);
export const listenForProductsUpdates = (callback) => setupSSEListener('/products', callback);
export const listenForCategoriesUpdates = (callback) => setupSSEListener('/categories', callback);

export default api;
