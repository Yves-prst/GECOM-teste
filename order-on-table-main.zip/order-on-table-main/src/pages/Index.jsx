import { useState, useEffect } from "react";
import { TableCard } from "@/components/TableCard";
import { OrderDetailsModal } from "@/components/OrderDetailsModal";
import { EditOrderModal } from "@/components/EditOrderModal";
import { MenuSection } from "@/components/MenuSection";
import { AddItemModal } from "@/components/AddItemModal";
import { CurrentOrderPanel } from "@/components/CurrentOrderPanel";
import { toast } from "sonner";
import { UtensilsCrossed, Menu as MenuIcon } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  fetchTables,
  fetchCategories,
  fetchProducts,
  fetchOpenOrder,
  createOrder,
  updateOrder,
  closeTableAndOrder,
  updateTableStatus,
  listenForTablesUpdates,
  listenForProductsUpdates,
  listenForCategoriesUpdates,
} from "@/services/api";

const Index = () => {
  // Estados principais
  const [tables, setTables] = useState([]);
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Estados de seleção
  const [selectedTable, setSelectedTable] = useState(null);
  const [currentOrder, setCurrentOrder] = useState([]);
  const [activeTab, setActiveTab] = useState("tables");

  // Estados de modais
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  const [showEditOrder, setShowEditOrder] = useState(false);
  const [showAddItem, setShowAddItem] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  // Estados de pedido existente
  const [existingOrder, setExistingOrder] = useState(null);
  const [existingOrderData, setExistingOrderData] = useState(null);

  // Carrega dados iniciais
  useEffect(() => {
    loadData();
    setupRealtimeUpdates();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [tablesRes, categoriesRes, productsRes] = await Promise.all([
        fetchTables(),
        fetchCategories(),
        fetchProducts(),
      ]);

      const processedProducts = productsRes.data.map((product) => ({
        ...product,
        price: Number(product.price) || 0,
        allExtras: (product.allExtras || []).map((extra) => ({
          ...extra,
          price: Number(extra.price) || 0,
        })),
      }));

      setTables(tablesRes.data);
      setCategories(categoriesRes.data);
      setProducts(processedProducts);
      setLoading(false);
    } catch (err) {
      console.error("Erro ao carregar dados:", err);
      toast.error("Erro ao carregar dados do servidor");
      setLoading(false);
    }
  };

  const setupRealtimeUpdates = () => {
    const unsubscribeTables = listenForTablesUpdates((data) => {
      setTables(data);
    });

    const unsubscribeProducts = listenForProductsUpdates((data) => {
      const processedProducts = data.map((product) => ({
        ...product,
        price: Number(product.price) || 0,
        allExtras: (product.allExtras || []).map((extra) => ({
          ...extra,
          price: Number(extra.price) || 0,
        })),
      }));
      setProducts(processedProducts);
    });

    const unsubscribeCategories = listenForCategoriesUpdates((data) => {
      setCategories(data);
    });

    return () => {
      unsubscribeTables();
      unsubscribeProducts();
      unsubscribeCategories();
    };
  };

  // Handler para clicar em mesa
  const handleTableClick = async (table) => {
    setSelectedTable(table);

    // Se mesa está ocupada, buscar pedido aberto
    if (table.status === "ocupada") {
      try {
        const response = await fetchOpenOrder(table.id);
        if (response.data && response.data.order) {
          setExistingOrder(response.data.order);
          setExistingOrderData(response.data);
          setShowOrderDetails(true);
        }
      } catch (error) {
        console.error("Erro ao buscar pedido:", error);
        toast.error("Erro ao buscar pedido da mesa");
      }
    } else if (table.status === "disponivel") {
      setCurrentOrder([]);
      setActiveTab("menu");
      toast.success(`Mesa ${table.numero} selecionada`);
    } else {
      toast.info(`Mesa ${table.numero} está reservada`);
    }
  };

  // Handler para adicionar item
  const handleAddItem = (product) => {
    setSelectedProduct(product);
    setShowAddItem(true);
  };

  // Handler para confirmar adição de item
  const handleConfirmAddItem = (itemData) => {
    setCurrentOrder((prev) => [...prev, itemData]);
  };

  // Handler para remover item
  const handleRemoveItem = (index) => {
    setCurrentOrder((prev) => prev.filter((_, i) => i !== index));
  };

  // Handler para limpar pedido
  const handleClearOrder = () => {
    setCurrentOrder([]);
    toast.info("Pedido limpo");
  };

  // Handler para enviar pedido
  const handleSendOrder = async () => {
    if (!selectedTable || currentOrder.length === 0) {
      toast.error("Adicione itens ao pedido!");
      return;
    }

    try {
      const items = currentOrder.map((item) => ({
        product_id: item.product.id,
        product_name: item.product.name,
        quantity: item.quantity,
        unit_price: item.product.price,
        extras: item.extras.map((e) => ({
          id: e.id,
          name: e.name,
          price: e.price,
        })),
      }));

      await createOrder(selectedTable.id, items);
      
      toast.success("Pedido enviado com sucesso!");
      setCurrentOrder([]);
      setSelectedTable(null);
      setActiveTab("tables");
      
      // Recarregar mesas
      const tablesRes = await fetchTables();
      setTables(tablesRes.data);
    } catch (error) {
      console.error("Erro ao enviar pedido:", error);
      toast.error("Erro ao enviar pedido");
    }
  };

  // Handler para fechar pedido
  const handleCloseOrder = async () => {
    if (!selectedTable || !existingOrder) return;

    try {
      await closeTableAndOrder(selectedTable.id, "Dinheiro");
      
      toast.success(`Pedido #${existingOrder.id} fechado! Mesa ${selectedTable.numero} liberada.`);
      
      setShowOrderDetails(false);
      setSelectedTable(null);
      setExistingOrder(null);
      setExistingOrderData(null);
      
      // Recarregar mesas
      const tablesRes = await fetchTables();
      setTables(tablesRes.data);
    } catch (error) {
      console.error("Erro ao fechar pedido:", error);
      toast.error("Erro ao fechar pedido");
    }
  };

  // Handler para editar pedido
  const handleEditOrder = () => {
    setShowOrderDetails(false);
    setShowEditOrder(true);
  };

  // Handler para salvar edição de pedido
  const handleSaveOrderEdit = async (items) => {
    if (!existingOrder) return;

    try {
      await updateOrder(existingOrder.id, items);
      
      toast.success("Pedido atualizado com sucesso!");
      
      // Recarregar pedido
      const response = await fetchOpenOrder(selectedTable.id);
      if (response.data && response.data.order) {
        setExistingOrder(response.data.order);
        setExistingOrderData(response.data);
      }
      
      setShowEditOrder(false);
      setShowOrderDetails(true);
    } catch (error) {
      console.error("Erro ao atualizar pedido:", error);
      toast.error("Erro ao atualizar pedido");
    }
  };

  // Calcular estatísticas
  const availableCount = tables.filter((t) => t.status === "disponivel").length;
  const occupiedCount = tables.filter((t) => t.status === "ocupada").length;
  const reservedCount = tables.filter((t) => t.status === "reservada").length;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-sm sticky top-0 z-20">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-primary rounded-lg">
              <UtensilsCrossed className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                Sistema de Mesas
              </h1>
              <p className="text-muted-foreground">
                Gerenciamento de pedidos e mesas
              </p>
            </div>
          </div>

          {/* Status Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-status-available-bg border-2 border-status-available-border rounded-lg p-4">
              <div className="text-sm font-medium text-muted-foreground">
                Disponíveis
              </div>
              <div className="text-3xl font-bold text-status-available">
                {availableCount}
              </div>
            </div>
            <div className="bg-status-occupied-bg border-2 border-status-occupied-border rounded-lg p-4">
              <div className="text-sm font-medium text-muted-foreground">
                Ocupadas
              </div>
              <div className="text-3xl font-bold text-status-occupied">
                {occupiedCount}
              </div>
            </div>
            <div className="bg-status-reserved-bg border-2 border-status-reserved-border rounded-lg p-4">
              <div className="text-sm font-medium text-muted-foreground">
                Reservadas
              </div>
              <div className="text-3xl font-bold text-status-reserved">
                {reservedCount}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-6">
            <TabsTrigger value="tables">Mesas</TabsTrigger>
            <TabsTrigger value="menu">Cardápio</TabsTrigger>
          </TabsList>

          {/* Mesas Tab */}
          <TabsContent value="tables" className="mt-0">
            <h2 className="text-2xl font-bold mb-6">Mesas</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {tables.map((table) => (
                <TableCard
                  key={table.id}
                  table={{
                    ...table,
                    number: table.numero,
                    guests: table.capacidade,
                  }}
                  onClick={() => handleTableClick(table)}
                />
              ))}
            </div>
          </TabsContent>

          {/* Cardápio Tab */}
          <TabsContent value="menu" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <h2 className="text-2xl font-bold mb-6">Cardápio</h2>
                <MenuSection
                  categories={categories}
                  products={products}
                  selectedTable={selectedTable}
                  onAddItem={handleAddItem}
                />
              </div>
              <div className="lg:col-span-1">
                <div className="sticky top-24">
                  <CurrentOrderPanel
                    selectedTable={selectedTable}
                    currentOrder={currentOrder}
                    onRemoveItem={handleRemoveItem}
                    onClearOrder={handleClearOrder}
                    onSendOrder={handleSendOrder}
                  />
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Order Details Modal */}
      <OrderDetailsModal
        open={showOrderDetails}
        onOpenChange={setShowOrderDetails}
        table={selectedTable ? { ...selectedTable, number: selectedTable.numero } : null}
        order={existingOrderData}
        onCloseOrder={handleCloseOrder}
        onEditOrder={handleEditOrder}
      />

      {/* Edit Order Modal */}
      <EditOrderModal
        open={showEditOrder}
        onOpenChange={setShowEditOrder}
        table={selectedTable ? { ...selectedTable, number: selectedTable.numero } : null}
        order={existingOrderData}
        onSaveOrder={handleSaveOrderEdit}
      />

      {/* Add Item Modal */}
      <AddItemModal
        open={showAddItem}
        onOpenChange={setShowAddItem}
        product={selectedProduct}
        onConfirm={handleConfirmAddItem}
      />
    </div>
  );
};

export default Index;
