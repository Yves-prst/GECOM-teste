import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users } from "lucide-react";
import { cn } from "@/lib/utils";

const statusConfig = {
  available: {
    label: "Disponível",
    bgClass: "bg-status-available-bg border-status-available-border",
    badgeClass: "bg-status-available text-white",
  },
  occupied: {
    label: "Ocupada",
    bgClass: "bg-status-occupied-bg border-status-occupied-border",
    badgeClass: "bg-status-occupied text-white",
  },
  reserved: {
    label: "Reservada",
    bgClass: "bg-status-reserved-bg border-status-reserved-border",
    badgeClass: "bg-status-reserved text-white",
  },
};

export const TableCard = ({ table, onClick }) => {
  const config = statusConfig[table.status];

  return (
    <Card
      onClick={onClick}
      className={cn(
        "cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg border-2 p-6",
        config.bgClass
      )}
    >
      <div className="flex flex-col items-center gap-3">
        <div className="text-2xl font-bold text-foreground">
          Mesa {table.number}
        </div>
        
        <Badge className={cn("text-xs font-semibold", config.badgeClass)}>
          {config.label}
        </Badge>

        {table.guests && table.guests > 0 && (
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{table.guests} pessoas</span>
          </div>
        )}
      </div>
    </Card>
  );
};
