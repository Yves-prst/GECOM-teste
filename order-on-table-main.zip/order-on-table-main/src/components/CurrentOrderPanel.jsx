import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Trash2, Send, X } from "lucide-react";
import { toast } from "sonner";

export const CurrentOrderPanel = ({ 
  selectedTable, 
  currentOrder, 
  onRemoveItem,
  onClearOrder,
  onSendOrder
}) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  const calculateTotal = () => {
    return currentOrder.reduce((sum, item) => {
      const basePrice = item.product.price * item.quantity;
      const extrasPrice = item.extras.reduce(
        (extraSum, extra) => extraSum + extra.price * item.quantity,
        0
      );
      return sum + basePrice + extrasPrice;
    }, 0);
  };

  const handleSendOrder = async () => {
    if (currentOrder.length === 0) {
      toast.error("Adicione itens ao pedido!");
      return;
    }
    
    await onSendOrder();
  };

  if (!selectedTable) {
    return (
      <Card className="p-6 h-full flex items-center justify-center">
        <p className="text-center text-muted-foreground">
          Selecione uma mesa para visualizar o pedido
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-4 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-bold text-lg">Pedido Atual</h3>
          <Badge className="mt-1">Mesa {selectedTable.numero}</Badge>
        </div>
        {currentOrder.length > 0 && (
          <Button
            size="sm"
            variant="ghost"
            onClick={onClearOrder}
            className="text-destructive hover:text-destructive"
          >
            <X className="h-4 w-4 mr-1" />
            Limpar
          </Button>
        )}
      </div>

      <Separator className="mb-4" />

      <div className="flex-1 overflow-y-auto space-y-3">
        {currentOrder.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Nenhum item adicionado
          </div>
        ) : (
          currentOrder.map((item, index) => (
            <div
              key={index}
              className="p-3 bg-muted rounded-lg flex items-start justify-between gap-2"
            >
              <div className="flex-1">
                <div className="font-semibold">
                  {item.quantity}x {item.product.name}
                </div>
                {item.extras.length > 0 && (
                  <div className="text-sm text-muted-foreground mt-1">
                    + {item.extras.map((e) => e.name).join(", ")}
                  </div>
                )}
                <div className="text-sm font-medium mt-1">
                  {formatCurrency(item.product.price * item.quantity + 
                    item.extras.reduce((sum, e) => sum + e.price * item.quantity, 0))}
                </div>
              </div>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => onRemoveItem(index)}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))
        )}
      </div>

      <Separator className="my-4" />

      <div className="space-y-4">
        <div className="flex justify-between items-center text-lg font-bold">
          <span>Total</span>
          <span className="text-2xl">{formatCurrency(calculateTotal())}</span>
        </div>

        <Button
          onClick={handleSendOrder}
          disabled={currentOrder.length === 0}
          className="w-full gap-2"
          size="lg"
        >
          <Send className="h-5 w-5" />
          Enviar Pedido
        </Button>
      </div>
    </Card>
  );
};
