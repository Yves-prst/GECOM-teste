import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, Plus } from "lucide-react";
import { toast } from "sonner";

export const MenuSection = ({ 
  categories, 
  products, 
  selectedTable,
  onAddItem
}) => {
  const [expandedCategories, setExpandedCategories] = useState({});
  const [searchText, setSearchText] = useState("");

  const toggleCategory = (categoryId) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [categoryId]: !prev[categoryId],
    }));
  };

  const getProductsByCategory = (categoryId) => {
    return products.filter(
      (p) => 
        p.category_id === categoryId && 
        p.status === "Ativo" &&
        (searchText === "" || p.name.toLowerCase().includes(searchText.toLowerCase()))
    );
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  const handleAddProduct = (product) => {
    if (!selectedTable) {
      toast.error("Selecione uma mesa primeiro!");
      return;
    }
    
    onAddItem(product);
    toast.success(`${product.name} adicionado ao pedido!`);
  };

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="sticky top-0 bg-background z-10 pb-4">
        <input
          type="text"
          placeholder="Buscar produto..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      {/* No table selected warning */}
      {!selectedTable && (
        <Card className="p-6 bg-muted border-2 border-dashed">
          <p className="text-center text-muted-foreground">
            Selecione uma mesa para fazer um pedido
          </p>
        </Card>
      )}

      {/* Categories */}
      <div className="space-y-3">
        {categories.map((category) => {
          const categoryProducts = getProductsByCategory(category.id);
          const isExpanded = expandedCategories[category.id];

          if (categoryProducts.length === 0 && searchText !== "") {
            return null;
          }

          return (
            <Card key={category.id} className="overflow-hidden">
              <button
                onClick={() => toggleCategory(category.id)}
                className="w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  {isExpanded ? (
                    <ChevronDown className="h-5 w-5 text-primary" />
                  ) : (
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  )}
                  <div className="text-left">
                    <h3 className="font-bold text-lg">{category.name}</h3>
                    {category.description && (
                      <p className="text-sm text-muted-foreground">
                        {category.description}
                      </p>
                    )}
                  </div>
                </div>
                <Badge variant="secondary">{categoryProducts.length}</Badge>
              </button>

              {isExpanded && (
                <div className="border-t divide-y bg-muted/20">
                  {categoryProducts.map((product) => (
                    <div
                      key={product.id}
                      className="p-4 flex items-center justify-between hover:bg-background/50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="font-semibold">{product.name}</div>
                        <div className="text-sm font-medium text-primary">
                          {formatCurrency(product.price)}
                        </div>
                        {product.allExtras && product.allExtras.length > 0 && (
                          <div className="text-xs text-muted-foreground mt-1">
                            Extras disponíveis: {product.allExtras.length}
                          </div>
                        )}
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleAddProduct(product)}
                        disabled={!selectedTable}
                        className="gap-2"
                      >
                        <Plus className="h-4 w-4" />
                        Adicionar
                      </Button>
                    </div>
                  ))}
                  {categoryProducts.length === 0 && (
                    <div className="p-4 text-center text-muted-foreground">
                      Nenhum produto nesta categoria
                    </div>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};
