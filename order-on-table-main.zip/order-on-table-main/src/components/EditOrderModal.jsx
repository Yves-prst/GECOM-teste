import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Plus, Minus, Save, Trash2, X } from "lucide-react";
import { useState, useEffect } from "react";

export const EditOrderModal = ({
  open,
  onOpenChange,
  table,
  order,
  onSaveOrder,
}) => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (order && order.items) {
      // Adaptar estrutura do backend MySQL
      const adaptedItems = order.items.map((item, index) => ({
        id: item.id || index,
        name: item.product_name,
        quantity: item.quantity,
        price: item.unit_price,
        extras: item.extras || [],
      }));
      setItems(adaptedItems);
    }
  }, [order]);

  if (!table || !order) return null;

  const updateQuantity = (id, delta) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.max(1, item.quantity + delta) }
          : item
      )
    );
  };

  const removeItem = (id) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const calculateTotal = () => {
    return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  const handleSave = () => {
    onSaveOrder(items);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            Editar Pedido - Mesa {table.number}
          </DialogTitle>
          <DialogDescription>
            Pedido #{order.id} • Ajuste quantidades ou remova itens
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {items.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Nenhum item no pedido
            </div>
          ) : (
            <div className="space-y-3">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-3 p-3 bg-muted rounded-lg"
                >
                  <div className="flex-1">
                    <div className="font-semibold">{item.name}</div>
                    {item.extras && item.extras.length > 0 && (
                      <div className="text-sm text-muted-foreground mt-1">
                        Extras: {item.extras.join(", ")}
                      </div>
                    )}
                    <div className="text-sm font-medium mt-1">
                      {formatCurrency(item.price)} cada
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => updateQuantity(item.id, -1)}
                      disabled={item.quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Input
                      type="number"
                      value={item.quantity}
                      readOnly
                      className="w-16 text-center"
                    />
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => updateQuantity(item.id, 1)}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="font-semibold text-right w-24">
                    {formatCurrency(item.price * item.quantity)}
                  </div>

                  <Button
                    size="icon"
                    variant="destructive"
                    onClick={() => removeItem(item.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          <Separator />

          <div className="flex justify-between items-center text-lg font-bold">
            <span>Total</span>
            <span className="text-2xl">{formatCurrency(calculateTotal())}</span>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="gap-2"
          >
            <X className="h-4 w-4" />
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            disabled={items.length === 0}
            className="gap-2"
          >
            <Save className="h-4 w-4" />
            Salvar Alterações
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
