import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Edit, X, DollarSign } from "lucide-react";

export const OrderDetailsModal = ({
  open,
  onOpenChange,
  table,
  order,
  onCloseOrder,
  onEditOrder,
}) => {
  if (!table || !order) return null;

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  // Adaptar estrutura para backend MySQL
  const orderData = order.order || order;
  const items = order.items || [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            Pedido - Mesa {table.number}
          </DialogTitle>
          <DialogDescription>
            Pedido #{orderData.id} • {new Date(orderData.created_at).toLocaleString("pt-BR")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-3">
            {items.map((item, index) => (
              <div
                key={index}
                className="flex justify-between items-start p-3 bg-muted rounded-lg"
              >
                <div className="flex-1">
                  <div className="font-semibold">
                    {item.quantity}x {item.product_name}
                  </div>
                  {item.extras && item.extras.length > 0 && (
                    <div className="text-sm text-muted-foreground mt-1">
                      Extras: {item.extras.map(e => e.name).join(", ")}
                    </div>
                  )}
                </div>
                <div className="font-semibold text-right">
                  {formatCurrency(item.total_price)}
                </div>
              </div>
            ))}
          </div>

          <Separator />

          <div className="flex justify-between items-center text-lg font-bold">
            <span>Total</span>
            <span className="text-2xl">{formatCurrency(orderData.total || 0)}</span>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="gap-2"
          >
            <X className="h-4 w-4" />
            Cancelar
          </Button>
          <Button
            variant="secondary"
            onClick={onEditOrder}
            className="gap-2"
          >
            <Edit className="h-4 w-4" />
            Editar Pedido
          </Button>
          <Button
            onClick={onCloseOrder}
            className="gap-2 bg-status-available hover:bg-status-available/90"
          >
            <DollarSign className="h-4 w-4" />
            Fechar Pedido
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
