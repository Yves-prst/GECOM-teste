import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Image,
  StyleSheet,
  SafeAreaView,
  Alert,
  StatusBar,
  Modal,
} from 'react-native';

const menuItems = [
  {
    id: '1',
    name: 'Classic Burger',
    price: 12.99,
    category: 'mains',
    description: 'Beef patty with lettuce, tomato, and cheese',
    image: 'https://via.placeholder.com/100x100/4CAF50/FFFFFF?text=Burger',
    quickExtras: [
      { id: 'e1', name: 'Extra Cheese', price: 2.00 },
      { id: 'e2', name: 'Bacon', price: 3.50 },
    ],
    allExtras: [
      { id: 'e1', name: 'Extra Cheese', price: 2.00 },
      { id: 'e2', name: 'Bacon', price: 3.50 },
      { id: 'e3', name: 'Avocado', price: 2.50 },
      { id: 'e15', name: 'Extra Pickles', price: 0.50 },
      { id: 'e16', name: 'Onion Rings', price: 3.00 },
    ]
  },
  {
    id: '2',
    name: 'Caesar Salad',
    price: 8.99,
    category: 'salads',
    description: 'Fresh romaine with parmesan and croutons',
    image: 'https://via.placeholder.com/100x100/8BC34A/FFFFFF?text=Salad',
    quickExtras: [
      { id: 'e4', name: 'Grilled Chicken', price: 4.00 },
    ],
    allExtras: [
      { id: 'e4', name: 'Grilled Chicken', price: 4.00 },
      { id: 'e5', name: 'Extra Parmesan', price: 1.50 },
      { id: 'e17', name: 'Croutons', price: 1.00 },
    ]
  },
  {
    id: '3',
    name: 'Margherita Pizza',
    price: 14.99,
    category: 'mains',
    description: 'Fresh mozzarella, tomato sauce, and basil',
    image: 'https://via.placeholder.com/100x100/FF9800/FFFFFF?text=Pizza',
    quickExtras: [
      { id: 'e6', name: 'Extra Mozzarella', price: 3.00 },
      { id: 'e7', name: 'Pepperoni', price: 2.50 },
    ],
    allExtras: [
      { id: 'e6', name: 'Extra Mozzarella', price: 3.00 },
      { id: 'e7', name: 'Pepperoni', price: 2.50 },
      { id: 'e8', name: 'Mushrooms', price: 2.00 },
      { id: 'e18', name: 'Olives', price: 1.50 },
      { id: 'e19', name: 'Bell Peppers', price: 2.00 },
    ]
  },
  {
    id: '4',
    name: 'Coca Cola',
    price: 2.99,
    category: 'drinks',
    description: 'Classic soft drink',
    image: 'https://via.placeholder.com/100x100/2196F3/FFFFFF?text=Drink',
    quickExtras: [],
    allExtras: [
      { id: 'e9', name: 'Extra Ice', price: 0.00 },
      { id: 'e10', name: 'Lemon Slice', price: 0.50 },
    ]
  },
  {
    id: '5',
    name: 'Chocolate Cake',
    price: 6.99,
    category: 'desserts',
    description: 'Rich chocolate cake with frosting',
    image: 'https://via.placeholder.com/100x100/795548/FFFFFF?text=Cake',
    quickExtras: [
      { id: 'e11', name: 'Ice Cream', price: 2.00 },
    ],
    allExtras: [
      { id: 'e11', name: 'Ice Cream', price: 2.00 },
      { id: 'e12', name: 'Whipped Cream', price: 1.00 },
      { id: 'e20', name: 'Strawberries', price: 2.50 },
    ]
  },
  {
    id: '6',
    name: 'Fish & Chips',
    price: 15.99,
    category: 'mains',
    description: 'Beer battered fish with crispy fries',
    image: 'https://via.placeholder.com/100x100/607D8B/FFFFFF?text=Fish',
    quickExtras: [
      { id: 'e13', name: 'Tartar Sauce', price: 1.00 },
    ],
    allExtras: [
      { id: 'e13', name: 'Tartar Sauce', price: 1.00 },
      { id: 'e14', name: 'Mushy Peas', price: 2.50 },
      { id: 'e21', name: 'Lemon Wedge', price: 0.50 },
    ]
  },
];

const tables = [
  { id: '1', number: 1, status: 'available', guests: 0 },
  { id: '2', number: 2, status: 'occupied', guests: 4 },
  { id: '3', number: 3, status: 'available', guests: 0 },
  { id: '4', number: 4, status: 'occupied', guests: 2 },
  { id: '5', number: 5, status: 'reserved', guests: 6 },
  { id: '6', number: 6, status: 'available', guests: 0 },
];

const categories = [
  { id: 'mains', name: 'Pratos Principais', icon: '🍽️' },
  { id: 'salads', name: 'Saladas', icon: '🥗' },
  { id: 'drinks', name: 'Bebidas', icon: '🥤' },
  { id: 'desserts', name: 'Sobremesas', icon: '🍰' },
];

const App = () => {
  const [selectedTable, setSelectedTable] = useState(null);
  const [currentOrder, setCurrentOrder] = useState([]);
  const [activeTab, setActiveTab] = useState('tables');
  const [expandedCategories, setExpandedCategories] = useState({});
  const [quickExtras, setQuickExtras] = useState({});
  const [showOrderModal, setShowOrderModal] = useState(false);
  
  // Estados para o modal iFood
  const [showItemModal, setShowItemModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedExtras, setSelectedExtras] = useState([]);
  const [itemQuantity, setItemQuantity] = useState(1);
  const [editingOrderItem, setEditingOrderItem] = useState(null);

  // Função para abrir modal iFood
  const openItemModal = (item, orderItem = null) => {
    setSelectedItem(item);
    if (orderItem) {
      // Editando item existente
      setEditingOrderItem(orderItem);
      setSelectedExtras(orderItem.extras);
      setItemQuantity(orderItem.quantity);
    } else {
      // Novo item
      setEditingOrderItem(null);
      setSelectedExtras([]);
      setItemQuantity(1);
    }
    setShowItemModal(true);
  };

  const closeItemModal = () => {
    setShowItemModal(false);
    setSelectedItem(null);
    setSelectedExtras([]);
    setItemQuantity(1);
    setEditingOrderItem(null);
  };

  // Função para adicionar/atualizar item do modal iFood
  const addItemFromModal = () => {
    if (!selectedItem) return;

    const orderItem = {
      ...selectedItem,
      extras: selectedExtras,
      quantity: itemQuantity,
      uniqueId: Date.now() + Math.random(),
    };

    if (editingOrderItem) {
      // Editando item existente
      setCurrentOrder(currentOrder.map(item => 
        item.uniqueId === editingOrderItem.uniqueId ? orderItem : item
      ));
    } else {
      // Novo item
      setCurrentOrder([...currentOrder, orderItem]);
    }

    closeItemModal();
  };

  const addToOrder = (item, extras = []) => {
    const orderItem = {
      ...item,
      extras,
      quantity: 1,
      uniqueId: Date.now() + Math.random()
    };
    setCurrentOrder([...currentOrder, orderItem]);
        
    // Limpar extras rápidos após adicionar
    setQuickExtras(prev => ({
      ...prev,
      [item.id]: []
    }));
  };

  const quickAddToOrder = (item) => {
    const selectedExtras = quickExtras[item.id] || [];
    addToOrder(item, selectedExtras);
  };

  const removeFromOrder = (uniqueId) => {
    setCurrentOrder(currentOrder.filter(item => item.uniqueId !== uniqueId));
  };

  const updateQuantity = (uniqueId, newQuantity) => {
    if (newQuantity === 0) {
      removeFromOrder(uniqueId);
    } else {
      setCurrentOrder(
        currentOrder.map(item =>
          item.uniqueId === uniqueId
            ? { ...item, quantity: newQuantity }
            : item
        )
      );
    }
  };

  const getTotalPrice = () => {
    return currentOrder.reduce((total, item) => {
      const extrasTotal = item.extras.reduce((sum, extra) => sum + extra.price, 0);
      return total + (item.price + extrasTotal) * item.quantity;
    }, 0);
  };

  const getTotalItems = () => {
    return currentOrder.reduce((total, item) => total + item.quantity, 0);
  };

  const getItemTotal = () => {
    if (!selectedItem) return 0;
    const extrasTotal = selectedExtras.reduce((sum, extra) => sum + extra.price, 0);
    return (selectedItem.price + extrasTotal) * itemQuantity;
  };

  const toggleCategory = (categoryId) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };

  const toggleQuickExtra = (itemId, extra) => {
    setQuickExtras(prev => {
      const currentExtras = prev[itemId] || [];
      const isSelected = currentExtras.some(e => e.id === extra.id);
            
      if (isSelected) {
        return {
          ...prev,
          [itemId]: currentExtras.filter(e => e.id !== extra.id)
        };
      } else {
        return {
          ...prev,
          [itemId]: [...currentExtras, extra]
        };
      }
    });
  };

  const toggleExtra = (extra) => {
    const isSelected = selectedExtras.some(e => e.id === extra.id);
    if (isSelected) {
      setSelectedExtras(selectedExtras.filter(e => e.id !== extra.id));
    } else {
      setSelectedExtras([...selectedExtras, extra]);
    }
  };

  const submitOrder = () => {
    if (selectedTable && currentOrder.length > 0) {
      Alert.alert(
        'Pedido Enviado',
        `Pedido enviado para Mesa ${selectedTable.number}!\nTotal: R$ ${getTotalPrice().toFixed(2)}`,
        [
          {
            text: 'OK',
            onPress: () => {
              setCurrentOrder([]);
              setActiveTab('tables');
              setShowOrderModal(false);
            },
          },
        ]
      );
    }
  };

  const renderTables = () => (
    <View style={styles.tablesGrid}>
      {tables.map((table) => (
        <TouchableOpacity
          key={table.id}
          style={[
            styles.tableCard,
            selectedTable?.id === table.id && styles.selectedTableCard,
            table.status === 'available' && styles.availableTable,
            table.status === 'occupied' && styles.occupiedTable,
            table.status === 'reserved' && styles.reservedTable,
          ]}
          onPress={() => {
            setSelectedTable(table);
            setActiveTab('menu');
          }}
        >
          <Text style={styles.tableNumber}>Mesa {table.number}</Text>
          <View style={[styles.statusBadge, styles[`${table.status}Badge`]]}>
            <Text style={styles.statusText}>
              {table.status === 'available' ? 'Disponível' :
                table.status === 'occupied' ? 'Ocupada' : 'Reservada'}
            </Text>
          </View>
          {table.guests > 0 && (
            <Text style={styles.guestsText}>{table.guests} pessoas</Text>
          )}
        </TouchableOpacity>
      ))}
    </View>
  );

  const renderMenu = () => {
    if (!selectedTable) {
      return (
        <View style={styles.noTableContainer}>
          <Text style={styles.noTableText}>Selecione uma mesa primeiro</Text>
          <TouchableOpacity
            style={styles.selectTableButton}
            onPress={() => setActiveTab('tables')}
          >
            <Text style={styles.selectTableButtonText}>Selecionar Mesa</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <ScrollView style={styles.menuContainer}>
        {categories.map((category) => (
          <View key={category.id} style={styles.categoryCard}>
            <TouchableOpacity
              style={styles.categoryHeader}
              onPress={() => toggleCategory(category.id)}
            >
              <View style={styles.categoryTitleContainer}>
                <Text style={styles.categoryIcon}>{category.icon}</Text>
                <Text style={styles.categoryTitle}>{category.name}</Text>
              </View>
              <Text style={styles.expandIcon}>
                {expandedCategories[category.id] ? '▼' : '▶'}
              </Text>
            </TouchableOpacity>
                        
            {expandedCategories[category.id] && (
              <View style={styles.categoryContent}>
                {menuItems
                  .filter(item => item.category === category.id)
                  .map(item => (
                    <View key={item.id} style={styles.menuItemCard}>
                      {/* Item Principal - CLICÁVEL PARA ABRIR MODAL iFood */}
                      <TouchableOpacity 
                        style={styles.menuItem}
                        onPress={() => openItemModal(item)}
                      >
                        <Image source={{ uri: item.image }} style={styles.menuItemImage} />
                        <View style={styles.menuItemInfo}>
                          <Text style={styles.menuItemName}>{item.name}</Text>
                          <Text style={styles.menuItemDescription}>{item.description}</Text>
                          <Text style={styles.menuItemPrice}>R$ {item.price.toFixed(2)}</Text>
                          {item.allExtras.length > 0 && (
                            <Text style={styles.menuItemExtrasAvailable}>+ Adicionais disponíveis</Text>
                          )}
                        </View>
                        <View style={styles.addIndicator}>
                          <Text style={styles.addIndicatorText}>+</Text>
                        </View>
                      </TouchableOpacity>

                      {/* Extras Rápidos - OPCIONAL */}
                      {item.quickExtras.length > 0 && (
                        <View style={styles.quickExtrasSection}>
                          <Text style={styles.quickExtrasTitle}>Adicionais Populares:</Text>
                          <View style={styles.quickExtrasContainer}>
                            {item.quickExtras.map(extra => {
                              const isSelected = (quickExtras[item.id] || []).some(e => e.id === extra.id);
                              return (
                                <TouchableOpacity
                                  key={extra.id}
                                  style={[
                                    styles.quickExtraChip,
                                    isSelected && styles.quickExtraChipSelected
                                  ]}
                                  onPress={() => toggleQuickExtra(item.id, extra)}
                                >
                                  <Text style={[
                                    styles.quickExtraChipText,
                                    isSelected && styles.quickExtraChipTextSelected
                                  ]}>
                                    {extra.name} (+R$ {extra.price.toFixed(2)})
                                  </Text>
                                </TouchableOpacity>
                              );
                            })}
                          </View>
                          
                          {/* Botão Rápido - OPCIONAL */}
                          
                        </View>
                      )}

                      {/* Total com extras */}
                      {(quickExtras[item.id] || []).length > 0 && (
                        <View style={styles.totalWithExtras}>
                          <Text style={styles.totalWithExtrasText}>
                            Total com extras: R$ {(
                              item.price + (quickExtras[item.id] || []).reduce((sum, e) => sum + e.price, 0)
                            ).toFixed(2)}
                          </Text>
                        </View>
                      )}
                    </View>
                  ))}
              </View>
            )}
          </View>
        ))}
      </ScrollView>
    );
  };

  const renderOrderBottom = () => {
    if (getTotalItems() === 0) return null;
    return (
      <TouchableOpacity
        style={styles.orderBottom}
        onPress={() => setShowOrderModal(true)}
      >
        <View style={styles.orderBottomContent}>
          <View style={styles.orderBottomLeft}>
            <Text style={styles.orderBottomIcon}>🛒</Text>
            <Text style={styles.orderBottomText}>
              {getTotalItems()} {getTotalItems() === 1 ? 'item' : 'itens'}
            </Text>
          </View>
          <Text style={styles.orderBottomPrice}>
            R$ {getTotalPrice().toFixed(2)}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  // MODAL iFood COMPLETO
  const renderItemModal = () => {
    if (!selectedItem) return null;

    return (
      <Modal
        visible={showItemModal}
        animationType="slide"
        onRequestClose={closeItemModal}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={closeItemModal}>
              <Text style={styles.modalCloseButton}>✕</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>{selectedItem.name}</Text>
            <View style={{ width: 24 }} />
          </View>
          
          <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
            {/* Imagem e Descrição */}
            <View style={styles.itemSection}>
              <Image source={{ uri: selectedItem.image }} style={styles.modalImage} />
              <Text style={styles.modalDescription}>{selectedItem.description}</Text>
              <Text style={styles.modalPrice}>R$ {selectedItem.price.toFixed(2)}</Text>
            </View>

            {/* Adicionais */}
            {selectedItem.allExtras.length > 0 && (
              <View style={styles.extrasSection}>
                <Text style={styles.extrasSectionTitle}>Adicionais</Text>
                {selectedItem.allExtras.map(extra => (
                  <TouchableOpacity
                    key={extra.id}
                    style={styles.extraItem}
                    onPress={() => toggleExtra(extra)}
                  >
                    <View style={styles.extraCheckbox}>
                      {selectedExtras.some(e => e.id === extra.id) && (
                        <Text style={styles.extraCheckmark}>✓</Text>
                      )}
                    </View>
                    <View style={styles.extraInfo}>
                      <Text style={styles.extraName}>{extra.name}</Text>
                      <Text style={styles.extraPrice}>
                        {extra.price > 0 ? `+R$ ${extra.price.toFixed(2)}` : 'Grátis'}
                      </Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {/* Quantidade */}
            <View style={styles.quantitySection}>
              <Text style={styles.quantitySectionTitle}>Quantidade</Text>
              <View style={styles.modalQuantityControls}>
                <TouchableOpacity
                  style={[styles.modalQuantityButton, itemQuantity <= 1 && styles.quantityButtonDisabled]}
                  onPress={() => setItemQuantity(Math.max(1, itemQuantity - 1))}
                  disabled={itemQuantity <= 1}
                >
                  <Text style={styles.modalQuantityButtonText}>-</Text>
                </TouchableOpacity>
                <Text style={styles.modalQuantityText}>{itemQuantity}</Text>
                <TouchableOpacity
                  style={styles.modalQuantityButton}
                  onPress={() => setItemQuantity(itemQuantity + 1)}
                >
                  <Text style={styles.modalQuantityButtonText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Resumo do Preço */}
            <View style={styles.priceResumeSection}>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Item ({itemQuantity}x)</Text>
                <Text style={styles.priceValue}>R$ {(selectedItem.price * itemQuantity).toFixed(2)}</Text>
              </View>
              {selectedExtras.length > 0 && (
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Adicionais ({itemQuantity}x)</Text>
                  <Text style={styles.priceValue}>
                    R$ {(selectedExtras.reduce((sum, e) => sum + e.price, 0) * itemQuantity).toFixed(2)}
                  </Text>
                </View>
              )}
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>R$ {getItemTotal().toFixed(2)}</Text>
              </View>
            </View>
          </ScrollView>
          
          {/* Botão de Adicionar */}
          <View style={styles.modalFooter}>
            <TouchableOpacity style={styles.addToOrderButton} onPress={addItemFromModal}>
              <Text style={styles.addToOrderButtonText}>
                {editingOrderItem ? 'Atualizar Item' : 'Adicionar à Comanda'} - R$ {getItemTotal().toFixed(2)}
              </Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    );
  };

  const renderOrderModal = () => (
    <Modal
      visible={showOrderModal}
      animationType="slide"
      onRequestClose={() => setShowOrderModal(false)}
    >
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => setShowOrderModal(false)}>
            <Text style={styles.modalCloseButton}>✕</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>Pedido Atual</Text>
          {selectedTable && (
            <View style={styles.tableBadge}>
              <Text style={styles.tableBadgeText}>Mesa {selectedTable.number}</Text>
            </View>
          )}
        </View>
                
        <ScrollView style={styles.orderModalContent}>
          {currentOrder.map(item => (
            <View key={item.uniqueId} style={styles.orderModalItem}>
              <TouchableOpacity 
                style={styles.orderModalItemContent}
                onPress={() => {
                  setShowOrderModal(false);
                  openItemModal(menuItems.find(mi => mi.id === item.id), item);
                }}
              >
                <Image source={{ uri: item.image }} style={styles.orderModalImage} />
                <View style={styles.orderModalItemInfo}>
                  <Text style={styles.orderModalItemName}>{item.name}</Text>
                  {item.extras.length > 0 && (
                    <Text style={styles.orderModalExtras}>
                      + {item.extras.map(e => e.name).join(', ')}
                    </Text>
                  )}
                  <Text style={styles.orderModalItemPrice}>
                    R$ {(item.price + item.extras.reduce((sum, e) => sum + e.price, 0)).toFixed(2)} cada
                  </Text>
                </View>
              </TouchableOpacity>
              <View style={styles.quantityControls}>
                <TouchableOpacity
                  style={styles.quantityButton}
                  onPress={() => updateQuantity(item.uniqueId, item.quantity - 1)}
                >
                  <Text style={styles.quantityButtonText}>-</Text>
                </TouchableOpacity>
                <Text style={styles.quantityText}>{item.quantity}</Text>
                <TouchableOpacity
                  style={styles.quantityButton}
                  onPress={() => updateQuantity(item.uniqueId, item.quantity + 1)}
                >
                  <Text style={styles.quantityButtonText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>
                
        <View style={styles.orderModalFooter}>
          <View style={styles.totalRow}>
            <Text style={styles.totalText}>Total:</Text>
            <Text style={styles.totalPrice}>R$ {getTotalPrice().toFixed(2)}</Text>
          </View>
          <TouchableOpacity
            style={[styles.submitButton, !selectedTable && styles.disabledButton]}
            onPress={submitOrder}
            disabled={!selectedTable}
          >
            <Text style={styles.submitButtonText}>✓ Enviar Pedido</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </Modal>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
            
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Pedidos Garçom</Text>
        {selectedTable && (
          <View style={styles.selectedTableBadge}>
            <Text style={styles.selectedTableText}>Mesa {selectedTable.number}</Text>
          </View>
        )}
      </View>

      {/* Tab Bar */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'tables' && styles.activeTabButton]}
          onPress={() => setActiveTab('tables')}
        >
          <Text style={[styles.tabButtonText, activeTab === 'tables' && styles.activeTabButtonText]}>
            👥 Mesas
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'menu' && styles.activeTabButton]}
          onPress={() => setActiveTab('menu')}
        >
          <Text style={[styles.tabButtonText, activeTab === 'menu' && styles.activeTabButtonText]}>
            📋 Menu
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <View style={styles.content}>
        {activeTab === 'tables' && renderTables()}
        {activeTab === 'menu' && renderMenu()}
      </View>

      {/* Order Bottom Bar */}
      {renderOrderBottom()}

      {/* Modals */}
      {renderItemModal()}
      {renderOrderModal()}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 16,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  selectedTableBadge: {
    backgroundColor: '#e3f2fd',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 16,
    marginTop: 8,
  },
  selectedTableText: {
    color: '#1976d2',
    fontWeight: '600',
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTabButton: {
    borderBottomWidth: 2,
    borderBottomColor: '#2196f3',
  },
  tabButtonText: {
    fontSize: 14,
    color: '#666',
  },
  activeTabButtonText: {
    color: '#2196f3',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 16,
  },
    
  // Tables
  tablesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  tableCard: {
    width: '48%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  selectedTableCard: {
    borderColor: '#2196f3',
    borderWidth: 2,
    backgroundColor: '#e3f2fd',
  },
  availableTable: {
    borderColor: '#4caf50',
  },
  occupiedTable: {
    backgroundColor: '#fff3e0',
    borderColor: '#ff9800',
  },
  reservedTable: {
    backgroundColor: '#ffebee',
    borderColor: '#f44336',
  },
  tableNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  availableBadge: {
    backgroundColor: '#4caf50',
  },
  occupiedBadge: {
    backgroundColor: '#ff9800',
  },
  reservedBadge: {
    backgroundColor: '#f44336',
  },
  statusText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  guestsText: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },

  // Menu
  noTableContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noTableText: {
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
  },
  selectTableButton: {
    backgroundColor: '#2196f3',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  selectTableButtonText: {
    color: '#ffffff',
    fontWeight: '600',
  },
  menuContainer: {
    flex: 1,
  },
  categoryCard: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    marginBottom: 12,
    overflow: 'hidden',
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f8f9fa',
  },
  categoryTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  expandIcon: {
    fontSize: 16,
    color: '#666',
  },
  categoryContent: {
    padding: 16,
  },
  menuItemCard: {
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    paddingBottom: 16,
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    backgroundColor: '#fafafa',
    borderRadius: 8,
    padding: 12,
  },
  menuItemImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  menuItemInfo: {
    flex: 1,
  },
  menuItemName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  menuItemDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  menuItemPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4caf50',
    marginBottom: 2,
  },
  menuItemExtrasAvailable: {
    fontSize: 10,
    color: '#2196f3',
    fontStyle: 'italic',
  },
  addIndicator: {
    backgroundColor: '#4caf50',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addIndicatorText: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  quickExtrasSection: {
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  quickExtrasTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
    marginBottom: 8,
  },
  quickExtrasContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 12,
  },
  quickExtraChip: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  quickExtraChipSelected: {
    backgroundColor: '#e3f2fd',
    borderColor: '#2196f3',
  },
  quickExtraChipText: {
    fontSize: 10,
    color: '#666',
  },
  quickExtraChipTextSelected: {
    color: '#2196f3',
    fontWeight: '600',
  },
  quickAddButton: {
    backgroundColor: '#4caf50',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  quickAddButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  totalWithExtras: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  totalWithExtrasText: {
    fontSize: 12,
    color: '#666',
    fontStyle: 'italic',
  },

  // Order Bottom
  orderBottom: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  orderBottomContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderBottomLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  orderBottomIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  orderBottomText: {
    fontSize: 16,
    fontWeight: '600',
  },
  orderBottomPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4caf50',
  },

  // Modal iFood
  modalContainer: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    backgroundColor: '#f8f9fa',
  },
  modalCloseButton: {
    fontSize: 24,
    color: '#666',
    width: 24,
    textAlign: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    flex: 1,
  },
  modalContent: {
    flex: 1,
  },
  itemSection: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  modalImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 16,
  },
  modalDescription: {
    fontSize: 16,
    color: '#666',
    marginBottom: 12,
    lineHeight: 22,
  },
  modalPrice: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4caf50',
  },
  extrasSection: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  extrasSectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  extraItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: '#fafafa',
  },
  extraCheckbox: {
    width: 24,
    height: 24,
    borderWidth: 2,
    borderColor: '#2196f3',
    borderRadius: 4,
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  extraCheckmark: {
    color: '#2196f3',
    fontWeight: 'bold',
    fontSize: 14,
  },
  extraInfo: {
    flex: 1,
  },
  extraName: {
    fontSize: 16,
    marginBottom: 4,
    color: '#333',
  },
  extraPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4caf50',
  },
  quantitySection: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    alignItems: 'center',
  },
  quantitySectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  modalQuantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  modalQuantityButton: {
    backgroundColor: '#2196f3',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityButtonDisabled: {
    backgroundColor: '#cccccc',
  },
  modalQuantityButtonText: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  modalQuantityText: {
    fontSize: 24,
    fontWeight: 'bold',
    minWidth: 40,
    textAlign: 'center',
    color: '#333',
  },
  priceResumeSection: {
    padding: 16,
    backgroundColor: '#f8f9fa',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  priceLabel: {
    fontSize: 14,
    color: '#666',
  },
  priceValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4caf50',
  },
  modalFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    backgroundColor: '#ffffff',
  },
  addToOrderButton: {
    backgroundColor: '#4caf50',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  addToOrderButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  // Order Modal
  orderModalContent: {
    flex: 1,
    padding: 16,
  },
  orderModalItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  orderModalItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  orderModalImage: {
    width: 50,
    height: 50,
    borderRadius: 8,
    marginRight: 12,
  },
  orderModalItemInfo: {
    flex: 1,
  },
  orderModalItemName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  orderModalExtras: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  orderModalItemPrice: {
    fontSize: 14,
    color: '#666',
  },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityButton: {
    backgroundColor: '#e0e0e0',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  quantityText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 16,
    minWidth: 24,
    textAlign: 'center',
  },
  orderModalFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4caf50',
  },
  submitButton: {
    backgroundColor: '#4caf50',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#cccccc',
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  tableBadge: {
    backgroundColor: '#e0e0e0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  tableBadgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
});

export default App;