// firebase.js
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAMvttH5p6sgNTkR1ZFpPSYIIcLLWD2a04",

  authDomain: "restaurante-6233b.firebaseapp.com",

  projectId: "restaurante-6233b",

  storageBucket: "restaurante-6233b.firebasestorage.app",

  messagingSenderId: "333059969531",

  appId: "1:333059969531:web:5635facf269aac23313b5e",

  measurementId: "G-3XBFWR5BVS"

};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
