const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors({
  origin: '*' 
}));
app.use(express.json());

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'admin_system3',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

app.get('/api', (req, res) => {
  res.json({
    message: 'API do Sistema de Restaurante',
    endpoints: {
      mesas: '/api/mesas',
      categories: '/api/categories',
      products: '/api/products'
    }
  });
});

app.get('/api/mesas', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM mesas');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar mesas' });
  }
});

app.put('/api/mesas/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  
  try {
    await pool.query('UPDATE mesas SET status = ? WHERE id = ?', [status, id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar status da mesa' });
  }
});

app.get('/api/categories', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar categorias' });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        p.id, 
        p.name, 
        CAST(p.price AS DECIMAL(10,2)) as price, 
        p.category_id,
        c.name as category_name,
        p.status
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.status = 'Ativo'
    `);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar produtos' });
  }
});

app.get('/api/products/by-category/:categoryId', async (req, res) => {
  const { categoryId } = req.params;
  
  try {
    const [rows] = await pool.query(`
      SELECT * FROM products 
      WHERE category_id = ? AND status = 'Ativo'
    `, [categoryId]);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar produtos por categoria' });
  }
});

app.post('/api/orders', async (req, res) => {
  const { mesaId, items } = req.body;
  
  try {
    // Inicia uma transação
    const conn = await pool.getConnection();
    await conn.beginTransaction();
    
    try {

      const totalOrderPrice = items.reduce((orderSum, item) => {
        const itemBasePrice = Number(item.price) || 0;
        const extrasTotal = (item.extras || []).reduce(
          (sum, extra) => sum + (Number(extra.price) || 0),
          0
        );
        const itemTotalPrice = (itemBasePrice + extrasTotal) * item.quantity;
        return orderSum + itemTotalPrice;
      }, 0);

      const [orderResult] = await conn.query(
        'INSERT INTO orders (status, total) VALUES (?, ?)',
        // Substitua a linha antiga pela nova variável totalOrderPrice
        ['open', totalOrderPrice.toFixed(2)] // Armazena o total CORRETO
      );
      
      const orderId = orderResult.insertId;

      for (const item of items) {

        const itemBasePrice = Number(item.price) || 0;
        const extrasTotal = (item.extras || []).reduce(
          (sum, extra) => sum + (Number(extra.price) || 0),
          0
        );
        const itemTotalPriceWithExtras = itemBasePrice + extrasTotal;
        const totalSalePrice = itemTotalPriceWithExtras * item.quantity;

        await conn.query(
          'INSERT INTO sales (product_id, product_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)',
          [item.productId, item.name, item.quantity,itemTotalPriceWithExtras.toFixed(2), // unit_price: Preço unitário (base + adicionais)
            totalSalePrice.toFixed(2)]
        );
      }
    
      await conn.query('UPDATE mesas SET status = ? WHERE id = ?', ['ocupada', mesaId]);
      
      await conn.commit();
      res.json({ success: true, orderId });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao criar pedido' });
  }
});

// Adicione esta nova rota no seu arquivo Node.js
// Exemplo de rota otimizada para buscar Produtos COM seus Adicionais
app.get('/api/products-with-addons', async (req, res) => {
    try {
        const query = `
            SELECT 
                p.id, p.name, p.price, p.status, p.category_id,
                ca.id AS addon_id, ca.name AS addon_name, ca.price AS addon_price
            FROM 
                products p
            LEFT JOIN 
                category_addons ca ON p.category_id = ca.category_id
            WHERE
                p.status = 'Ativo'
        `;
        
        const [results] = await pool.execute(query);

        // Processa os resultados para agrupar adicionais por produto
        const productsMap = {};

        results.forEach(row => {
            if (!productsMap[row.id]) {
                productsMap[row.id] = {
                    id: row.id,
                    name: row.name,
                    price: row.price,
                    status: row.status,
                    category_id: row.category_id,
                    // Inicializa a lista de extras
                    allExtras: [] 
                };
            }

            if (row.addon_id) {
                productsMap[row.id].allExtras.push({
                    id: row.addon_id,
                    name: row.addon_name,
                    price: Number(row.addon_price)
                });
            }
        });

        // Converte o mapa de volta para um array de produtos
        const processedProducts = Object.values(productsMap);

        res.json(processedProducts);
    } catch (err) {
        console.error('Erro ao buscar produtos com adicionais:', err);
        res.status(500).json({ error: 'Erro interno do servidor ao buscar produtos.' });
    }
});

// server.js - Adicione esta nova rota API:

// server.js

// Novo endpoint para buscar o pedido aberto de uma mesa
app.get('/api/orders/open/:tableId', async (req, res) => {
  const { tableId } = req.params;
  try {
    const query = `
        SELECT
            o.id AS order_id, o.status AS order_status, o.created_at, o.total,
            oi.id AS item_id, oi.product_id, oi.quantity, oi.price_at_order, oi.notes,
            p.name AS product_name, p.price AS product_base_price,
            oia.addon_id, oia.price_at_order AS addon_price_at_order, ca.name AS addon_name
        FROM orders o
        JOIN mesa_orders mo ON o.id = mo.order_id
        JOIN order_items oi ON o.id = oi.order_id
        JOIN products p ON oi.product_id = p.id
        LEFT JOIN order_item_addons oia ON oi.id = oia.order_item_id
        LEFT JOIN category_addons ca ON oia.addon_id = ca.id
        WHERE mo.mesa_id = ? AND o.status = 'open'
        ORDER BY oi.id, oia.addon_id;
    `;

    const [rows] = await pool.query(query, [tableId]);

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Nenhum pedido aberto encontrado para esta mesa.' });
    }

    // --- Agrupar os resultados para enviar ao cliente ---
    const order = {
      id: rows[0].order_id,
      status: rows[0].order_status,
      created_at: rows[0].created_at,
      total: parseFloat(rows[0].total),
      items: [],
    };

    const itemsMap = new Map();

    for (const row of rows) {
      if (!itemsMap.has(row.item_id)) {
        itemsMap.set(row.item_id, {
          id: row.item_id, // ID do item_pedido (order_items)
          product_id: row.product_id,
          name: row.product_name,
          price: parseFloat(row.price_at_order), // Preço unitário do produto na hora do pedido
          quantity: row.quantity,
          notes: row.notes,
          addons: [],
        });
      }

      if (row.addon_id) {
        const item = itemsMap.get(row.item_id);
        item.addons.push({
          id: row.addon_id,
          name: row.addon_name,
          price: parseFloat(row.addon_price_at_order), // Preço do adicional na hora do pedido
        });
      }
    }

    order.items = Array.from(itemsMap.values());

    res.json({ order });
  } catch (error) {
    console.error('Erro ao buscar pedido aberto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/mesas/:mesaId/close-order', async (req, res) => {
    const { mesaId } = req.params;
    const { paymentMethod } = req.body; // Recomendável passar o método de pagamento
    
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        // 1. Encontra o ID do pedido aberto
        const [mesaOrderRows] = await connection.execute(
            `SELECT mo.order_id FROM mesa_orders mo
             JOIN orders o ON mo.order_id = o.id
             WHERE mo.mesa_id = ? AND (o.status = 'open' OR o.status = 'sent_to_kitchen')`,
            [mesaId]
        );

        if (mesaOrderRows.length === 0) {
            await connection.rollback();
            return res.status(404).json({ error: 'Nenhum pedido aberto encontrado para esta mesa.' });
        }
        
        const orderId = mesaOrderRows[0].order_id;
        
        // 2. Fecha o pedido (atualiza status e método de pagamento)
        await connection.execute(
            `UPDATE orders SET status = 'closed', payment_method = ?, paid_at = NOW() WHERE id = ?`,
            [paymentMethod || 'Dinheiro', orderId]
        );

        // 3. Atualiza o status da mesa para 'available'
        await connection.execute(
            `UPDATE mesas SET status = 'available' WHERE id = ?`,
            [mesaId]
        );
        
        // 4. Remove a associação na tabela mesa_orders
        await connection.execute(
            `DELETE FROM mesa_orders WHERE mesa_id = ? AND order_id = ?`,
            [mesaId, orderId]
        );

        await connection.commit();
        res.json({ message: 'Mesa fechada e pedido finalizado com sucesso.', orderId: orderId });
    } catch (error) {
        await connection.rollback();
        console.error('Erro ao fechar o pedido/mesa:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao finalizar o pedido.' });
    } finally {
        connection.release();
    }
});

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});