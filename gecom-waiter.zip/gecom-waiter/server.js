const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors({
  origin: '*' 
}));
app.use(express.json());

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'admin_system3',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

app.get('/api', (req, res) => {
  res.json({
    message: 'API do Sistema de Restaurante',
    endpoints: {
      mesas: '/api/mesas',
      categories: '/api/categories',
      products: '/api/products'
    }
  });
});

app.get('/api/mesas', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM mesas');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar mesas' });
  }
});

app.put('/api/mesas/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  
  try {
    await pool.query('UPDATE mesas SET status = ? WHERE id = ?', [status, id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar status da mesa' });
  }
});

app.get('/api/categories', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar categorias' });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        p.id, 
        p.name, 
        CAST(p.price AS DECIMAL(10,2)) as price, 
        p.category_id,
        c.name as category_name,
        p.status
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.status = 'Ativo'
    `);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar produtos' });
  }
});

app.get('/api/products/by-category/:categoryId', async (req, res) => {
  const { categoryId } = req.params;
  
  try {
    const [rows] = await pool.query(`
      SELECT * FROM products 
      WHERE category_id = ? AND status = 'Ativo'
    `, [categoryId]);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao buscar produtos por categoria' });
  }
});

app.post('/api/orders', async (req, res) => {
  const { mesaId, items } = req.body;
  
  try {
    // Inicia uma transação
    const conn = await pool.getConnection();
    await conn.beginTransaction();
    
    try {

      const totalOrderPrice = items.reduce((orderSum, item) => {
        const itemBasePrice = Number(item.price) || 0;
        const extrasTotal = (item.extras || []).reduce(
          (sum, extra) => sum + (Number(extra.price) || 0),
          0
        );
        const itemTotalPrice = (itemBasePrice + extrasTotal) * item.quantity;
        return orderSum + itemTotalPrice;
      }, 0);

      const [orderResult] = await conn.query(
        'INSERT INTO orders (status, total) VALUES (?, ?)',
        // Substitua a linha antiga pela nova variável totalOrderPrice
        ['open', totalOrderPrice.toFixed(2)] // Armazena o total CORRETO
      );
      
      const orderId = orderResult.insertId;

      for (const item of items) {

        const itemBasePrice = Number(item.price) || 0;
        const extrasTotal = (item.extras || []).reduce(
          (sum, extra) => sum + (Number(extra.price) || 0),
          0
        );
        const itemTotalPriceWithExtras = itemBasePrice + extrasTotal;
        const totalSalePrice = itemTotalPriceWithExtras * item.quantity;

        await conn.query(
          'INSERT INTO sales (product_id, product_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)',
          [item.productId, item.name, item.quantity,itemTotalPriceWithExtras.toFixed(2), // unit_price: Preço unitário (base + adicionais)
            totalSalePrice.toFixed(2)]
        );
      }
    
      await conn.query('UPDATE mesas SET status = ? WHERE id = ?', ['ocupada', mesaId]);
      
      await conn.commit();
      res.json({ success: true, orderId });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao criar pedido' });
  }
});

// Adicione esta nova rota no seu arquivo Node.js
// Exemplo de rota otimizada para buscar Produtos COM seus Adicionais
app.get('/api/products-with-addons', async (req, res) => {
    try {
        const query = `
            SELECT 
                p.id, p.name, p.price, p.status, p.category_id,
                ca.id AS addon_id, ca.name AS addon_name, ca.price AS addon_price
            FROM 
                products p
            LEFT JOIN 
                category_addons ca ON p.category_id = ca.category_id
            WHERE
                p.status = 'Ativo'
        `;
        
        const [results] = await pool.execute(query);

        // Processa os resultados para agrupar adicionais por produto
        const productsMap = {};

        results.forEach(row => {
            if (!productsMap[row.id]) {
                productsMap[row.id] = {
                    id: row.id,
                    name: row.name,
                    price: row.price,
                    status: row.status,
                    category_id: row.category_id,
                    // Inicializa a lista de extras
                    allExtras: [] 
                };
            }

            if (row.addon_id) {
                productsMap[row.id].allExtras.push({
                    id: row.addon_id,
                    name: row.addon_name,
                    price: Number(row.addon_price)
                });
            }
        });

        // Converte o mapa de volta para um array de produtos
        const processedProducts = Object.values(productsMap);

        res.json(processedProducts);
    } catch (err) {
        console.error('Erro ao buscar produtos com adicionais:', err);
        res.status(500).json({ error: 'Erro interno do servidor ao buscar produtos.' });
    }
});
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});